package com.neo.cornerstone.management.admin.model.params;

import java.util.Date;

/**
 * Title:TMenu<br/>
 * Description:(菜单mapper参数对象)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class MenuParams extends BaseParams {
    private static final long serialVersionUID = 6220692696336910794L;
    /**(名称)*/
    private String name;
    /**(层级)*/
    private Integer level;
    /**(url)*/
    private String url;
    private String parameter;
    /**(父级)*/
    private Long parentId;
    /**(状态 1： 有效 0 ： 无效)*/
    private Integer state;
    /**()*/
    private Date createTime;
    /**()*/
    private Date modTime;

    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Integer getLevel(){
        return this.level;
    }
    public void setLevel(Integer level){
        this.level = level;
    }
    public String getUrl(){
        return this.url;
    }
    public void setUrl(String url){
        this.url = url;
    }
    public Long getParentId(){
        return this.parentId;
    }
    public void setParentId(Long parentId){
        this.parentId = parentId;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getModTime(){
        return this.modTime;
    }
    public void setModTime(Date modTime){
        this.modTime = modTime;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }
}