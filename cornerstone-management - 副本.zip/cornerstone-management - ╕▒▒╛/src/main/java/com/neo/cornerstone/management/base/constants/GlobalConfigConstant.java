package com.neo.cornerstone.management.base.constants;

/*******************************************************************************
 * Created on 2019/8/28 14:26
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public interface GlobalConfigConstant {

    public static final String MANAGEMENT_LOG_TOPIC = "Management-5007-Topic-Management-Log";
    public static final String OPERATION_LOG_TAG = "Management-5007-Tag-Operation-Log";
    public static final String BEHAVIOR_LOG_TAG = "Management-5007-Tag-Behavior-Log";

    public static final String ACCESS_TOKEN = "AccessToken";
    public static final String USERNAME = "username";
}
