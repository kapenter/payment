package com.neo.cornerstone.management.admin.model.ext;

import com.neo.cornerstone.management.admin.model.Menu;
import com.neo.cornerstone.management.admin.model.RoleMenu;

public class RoleMenuExt extends RoleMenu {
    private static final long serialVersionUID = -4988345442920734436L;

    private Menu menu;

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }
}
