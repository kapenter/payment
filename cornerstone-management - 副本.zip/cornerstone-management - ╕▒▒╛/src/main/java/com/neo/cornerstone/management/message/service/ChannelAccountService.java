package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.message.feign.ChannelAccountFeign;
import com.neo.cornerstone.message.dto.request.ChannelAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.ChannelAccountRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-28 13:54
 **/
@Service
public class ChannelAccountService implements  ChannelAccountFeign {

    @Autowired
    private ChannelAccountFeign channelAccountFeign;


    @Override
    public PageResponseDTO<ChannelAccountRespDTO> pageChannelAccounts(ChannelAccountQueryDTO channelAccountQueryDTO) {
        return channelAccountFeign.pageChannelAccounts(channelAccountQueryDTO);
    }

    @Override
    public OperationResponseDTO<Boolean> addChannelAccount(ChannelAccountRequestDTO channelAccountRequestDTO) {
        return channelAccountFeign.addChannelAccount(channelAccountRequestDTO);
    }

    @Override
    public OperationResponseDTO<Boolean> updateChannelAccount(ChannelAccountRequestDTO channelAccountRequestDTO) {
        return channelAccountFeign.updateChannelAccount(channelAccountRequestDTO);
    }
}
