package com.neo.cornerstone.management.merchant.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.merchant.constants.MerchantUrl;
import com.neo.cornerstone.management.merchant.service.MerchantAppClient;
import com.neo.cornerstone.management.merchant.util.ResponseTransferUtil;
import com.neo.cornerstone.merchant.serve.define.dto.MerchantAppDTO;
import com.neo.cornerstone.merchant.serve.define.dto.MerchantAppQueryParam;
import com.neo.cornerstone.merchant.serve.define.dto.PageResponseDTO;
import com.neo.cornerstone.merchant.serve.define.dto.ResponseDTO;
import com.neo.payment.exception.ValidateException;
import com.neo.payment.util.ValidateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;

import static com.neo.cornerstone.management.base.enums.GlobalReturnCode.ARGUMENT_MISSING;
import static com.neo.cornerstone.management.base.enums.GlobalReturnCode.KEY_EXPIRE_TIME_ERROR;

/**
 * @Description:商户账户
 * @Author: yanyiwei
 * @Date: 2019/08/26
 */
@Controller
public class MerchantAppController extends BaseController {

    @Autowired
    private MerchantAppClient merchantAppClient;

    /**
     * 功能描述: 商户账户分页
     * @param: [pageNum, pageSize, name]
     * @return:
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.PAGE_MERCHANT_APP)
    @ResponseBody
    public PageModel<MerchantAppDTO> pageMerchantApp(Integer pageNum, Integer pageSize, String name, String merchantId) {
        MerchantAppQueryParam pageQueryParam = new MerchantAppQueryParam(pageNum, pageSize, name, merchantId);
        PageResponseDTO<MerchantAppDTO> pageResponseDTO = merchantAppClient.pageMerchantApp(pageQueryParam);

        PageModel<MerchantAppDTO> objectPageModel = new PageModel<>();
        objectPageModel.setTotalRows(pageResponseDTO.getTotalRows());
        objectPageModel.setData(pageResponseDTO.getData());

        return ResponseUtils.buildSuccessPageResponse(objectPageModel);
    }

    /**
     * 功能描述:商户账户添加
     * @param: [merchantAppDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.ADD_MERCHANT_APP)
    @ResponseBody
    @OperationLog(operation = OperationModule.MERCHANT_APP_ADD, encrypt = true)
    public BaseResponse addMerchantApp(@RequestBody MerchantAppDTO merchantAppDTO) {
        try {
            logger.info("[商户账户添加]-参数:{}", merchantAppDTO);
            ValidateUtil.validate(merchantAppDTO);
            if (merchantAppDTO.getKeyExpireTime().compareTo(new Date()) < 0) {
                return ResponseUtils.buildFailureResponse(null, KEY_EXPIRE_TIME_ERROR.getCode(), KEY_EXPIRE_TIME_ERROR.getMessage());
            }
            ResponseDTO responseDTO = merchantAppClient.addMerchantApp(merchantAppDTO);
            logger.info("[商户账户添加]-结果:{}", responseDTO);
            return ResponseTransferUtil.transferResponse(responseDTO);
        } catch (ValidateException e) {
            logger.error("[商户账户添加]-参数校验错误", e);
            return ResponseUtils.buildFailureResponse(null, ARGUMENT_MISSING.getCode(), e.getMessage());
        } catch (Exception e) {
            logger.error("[商户账户添加]-异常", e);
            return ResponseUtils.buildFailureResponse(null);
        }
    }

    /**
     * 功能描述: 商户账户修改
     * @param: [merchantAppDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.UPDATE_MERCHANT_APP)
    @ResponseBody
    @OperationLog(operation = OperationModule.MERCHANT_APP_UPDATE, encrypt = true)
    public BaseResponse updateMerchantApp(@RequestBody MerchantAppDTO merchantAppDTO) {
        logger.info("[商户账户修改]-参数:{}", merchantAppDTO);
        ResponseDTO responseDTO = merchantAppClient.updateMerchantApp(merchantAppDTO);
        logger.info("[商户账户修改]-结果:{}", responseDTO);
        return ResponseTransferUtil.transferResponse(responseDTO);
    }
}
