package com.neo.cornerstone.management.admin.configuration.shiro;

import org.apache.shiro.authz.Permission;
import org.apache.shiro.authz.permission.PermissionResolver;

/**
 * 在permissionFilter 的时候，会通过PermissionResolver 把权限url转换为
 * permission对象。需要自定义permission，实现自定义的权限匹配规则
 */
public class MGTPermissionResolver implements PermissionResolver {

    @Override
    public Permission resolvePermission(String permissionStr) {
        return new MGTPermission(permissionStr);
    }
}
