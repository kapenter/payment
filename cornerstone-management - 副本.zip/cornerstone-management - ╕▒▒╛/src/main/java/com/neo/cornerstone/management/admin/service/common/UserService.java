package com.neo.cornerstone.management.admin.service.common;

import com.neo.cornerstone.management.admin.mapper.UserMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.User;
import com.neo.cornerstone.management.admin.model.ext.UserExt;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.UserParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;
import com.neo.cornerstone.management.base.dto.PageModel;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Title:TUserServiceImpl<br/>
 * Description:(用户SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("userService")
public class UserService extends MysqlBaseServiceImpl <User> {

    @Autowired
    private UserMapper userMapper;

    @Override
    public BaseMapper <User> getBaseMapper() {
        return userMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new UserParams();
    }

    @Override
    public User getObjectModel() {
        return new User();
    }


    public boolean removeOrg(Long orgId) {
        return userMapper.removeOrg(orgId) > 0;
    }

    public PageModel <UserExt> queryPageExt(BaseParams params) {
        if (params.getPageNum() < 0) {
            params.setPageNum(0);
        }

        PageModel<UserExt> pageModel = new PageModel<>();

        List <UserExt> resultList = userMapper.queryPageListExt(params);
        if (CollectionUtils.isNotEmpty(resultList)) {
            pageModel.setData(resultList);
            pageModel.setTotalRows(userMapper.queryPageCountListExt(params));
        }
        return pageModel;
    }
}