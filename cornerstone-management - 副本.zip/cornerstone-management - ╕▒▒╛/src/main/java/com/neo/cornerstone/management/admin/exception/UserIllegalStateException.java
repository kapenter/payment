package com.neo.cornerstone.management.admin.exception;

import org.apache.shiro.authc.AccountException;

/*******************************************************************************
 * Created on 2019/8/12 14:49
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/

/**
 * 用户状态异常
 */
public class UserIllegalStateException extends AccountException {
    private static final long serialVersionUID = 1473113826102043480L;

    public UserIllegalStateException(String message) {
        super(message);
    }
}
