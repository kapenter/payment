package com.neo.cornerstone.management.admin.configuration.shiro;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.code.kaptcha.Constants;
import com.neo.cornerstone.management.admin.enums.ErrorCode;
import com.neo.cornerstone.management.admin.exception.KaptchaException;
import com.neo.cornerstone.management.admin.util.RSAUtil;

/*******************************************************************************
 * Created on 2019/8/12 14:29
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class MGTAuthenticationFilter extends FormAuthenticationFilter {

    private static Logger logger = LoggerFactory.getLogger(MGTAuthenticationFilter.class);

    private String captcha;

    private String unLoginUrl;

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
        // 当重复调用登录post 请求时候，uper.isAccessAllowed 会返回已认证，请求
        // 会直接落到 login controller， 返回错误信息,
        // 当判断是在已登录情况下重复登录，则继续执行登录。在onAccessDenied -> executeLogin 放开，直接返回成功信息
        if (getSubject(request, response).isAuthenticated() && isLoginSubmission(request, response)
                && ((HttpServletRequest) request).getRequestURI().equals(getLoginUrl())) {
            return false;
        }
        return super.isAccessAllowed(request, response, mappedValue);
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        if (isLoginRequest(request, response)) {
            if (isLoginSubmission(request, response)) {
                logger.info("Login submission detected.  Attempting to execute login.");
                if (getSubject(request, response).isAuthenticated()) {
                    // 当是已登录状态下， 重复登录
                    return directLoginSuccess(request, response);
                } else {
                    return executeLogin(request, response);
                }
            } else {
                logger.info("forward to the login controller");
                return true;
            }
        } else {
            logger.trace("Attempting to access a path which requires authentication.  Forwarding to the "
                    + "Authentication url [" + getLoginUrl() + "]");
            saveRequestAndRedirectToLogin(request, response);
            return false;
        }
    }

    @Override
    protected void redirectToLogin(ServletRequest request, ServletResponse response) throws IOException {
        logger.info("请求 [{}] - 当前未登录", ((HttpServletRequest) request).getRequestURL());
        String unLoginUrl = getUnLoginUrl();
        try {
            request.getRequestDispatcher(unLoginUrl).forward(request, response);
        } catch (ServletException e) {
            logger.error("请求 [{}] - 当前未登录 - 跳转 [{}] - 异常", ((HttpServletRequest) request).getRequestURL(), unLoginUrl, e);
            throw  new RuntimeException("请求 [" + ((HttpServletRequest) request).getRequestURL()+ "] - 当前未登录 - 跳转 [" + unLoginUrl + "] - 异常");
        }
    }

    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) {
        AuthenticationToken token = super.createToken(request, response);
        if (null != token) {
            MGTUsernamePasswordToken mgtUsernamePasswordToken = new MGTUsernamePasswordToken(
                    ((UsernamePasswordToken) token).getUsername(),
                    ((UsernamePasswordToken) token).getPassword() != null
                            ? new String(((UsernamePasswordToken) token).getPassword())
                            : null,
                    ((UsernamePasswordToken) token).isRememberMe(), ((UsernamePasswordToken) token).getHost());
            String postCaptcha = WebUtils.getCleanParam(request, "kaptcha");
            Object kaptcha = getSubject(request, response).getSession()
                    .getAttribute(Constants.KAPTCHA_SESSION_KEY);
            mgtUsernamePasswordToken.setPostKaptcha(postCaptcha);
            mgtUsernamePasswordToken.setKaptcha(kaptcha);
            return mgtUsernamePasswordToken;
        }
        return token;
    }

    @Override
    protected AuthenticationToken createToken(String username, String password, boolean rememberMe, String host) {
        try {
            password = new String(RSAUtil.decryptDefault(password));
        } catch (Exception e) {
            throw new RuntimeException(" password decrypt error");
        }
        return super.createToken(username, password, rememberMe, host);
    }

    private boolean directLoginSuccess(ServletRequest request,
                                       ServletResponse response) throws Exception {
        Subject subject = getSubject(request, response);
        MGTUsernamePasswordToken token = new MGTUsernamePasswordToken();
        token.setUsername((String) subject.getPrincipal());
        return onLoginSuccess(token, subject, request, response);
    }

    @Override
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject, ServletRequest request,
            ServletResponse response) throws Exception {
        logger.info("用户[{}] - 请求[{}] 登录成功 ", token.getPrincipal(), ((HttpServletRequest) request).getRequestURL());
        request.getRequestDispatcher(getSuccessUrl()).forward(request, response);
        return false;
    }

    /**
     * 当post loginUrl时候会被shiro 拦截，当登录成功会直接跳转到 success,当登录失败会继续往前执行，
     * 到 loginUrl 的controller.
     * @param token
     * @param e
     * @param request
     * @param response
     * @return
     */
    @Override
    protected boolean onLoginFailure(AuthenticationToken token, AuthenticationException e, ServletRequest request,
            ServletResponse response) {
        logger.error("用户 [{}] - 登陆失败 - ", token, e);
        request.setAttribute("username", token.getPrincipal());
        return super.onLoginFailure(token, e, request, response);
    }

    public String getUnLoginUrl() {
        return unLoginUrl;
    }

    public void setUnLoginUrl(String unLoginUrl) {
        this.unLoginUrl = unLoginUrl;
    }
}
