package com.neo.cornerstone.management.message.consts;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-23 13:55
 **/
public interface MessageURL {

    /**
     * 获取message服务 商户应用信息
     */
    String MESSAGE_MERCHANT_APP_ACCOUNT_LIST = "/message/merchantAppAccount/list";

    String MESSAGE_MERCHANT_APP_ACCOUNT_LIST_ALL = "/message/merchantAppAccount/listAll";

    String MESSAGE_MERCHANT_APP_ACCOUNT_ADD = "/message/mchAppAccount/add";

    String MESSAGE_MERCHANT_APP_ACCOUNT_UPDATE = "/message/merchantAppAccount/update";

    String MERCHANT_APP_ACCOUNT_LIST = "/merchant/queryMerchantApp/list";


    /**
     * 获取message服务  渠道管理
     * */
    String MESSAGE_CHANNEL_INFO_LIST = "/message/channelInfo/list";

    String MESSAGE_CHANNEL_INFO_ALL_LIST = "/message/channelInfo/listAll";

    String MESSAGE_CHANNEL_INFO_ADD = "/message/channelInfo/add";

    String MESSAGE_CHANNEL_INFO_UPDATE = "/message/channelInfo/update";


    /**
     * 获取message服务  sms渠道账号表
     * */
    String MESSAGE_CHANNEL_ACCOUNT_LIST = "/message/channelAccount/list";

    String MESSAGE_CHANNEL_ACCOUNT_ADD = "/message/channelAccount/add";

    String MESSAGE_CHANNEL_ACCOUNT_UPDATE = "/message/channelAccount/update";



    /**
     * 获取message服务  sms路由配置
     * */
    String MESSAGE_CHANNEL_ACCOUNT_ROUTE_LIST = "/message/accountRoute/list";

    String MESSAGE_CHANNEL_ACCOUNT_ROUTE_ADD = "/message/accountRoute/add";

    String MESSAGE_CHANNEL_ACCOUNT_ROUTE_UPDATE = "/message/accountRoute/update";


    /**
     * 获取message服务  sms路由配置
     * */
    String MESSAGE_SEND_LOG_LIST = "/message/sendLog/list";



    //***********************************邮件管理模块***********************************************//
    /**
     * 获取message服务  sms渠道账号表
     * */
    String MESSAGE_MAIL_CHANNEL_ACCOUNT_LIST = "/message/mailAccount/list";

    String MESSAGE_MAIL_CHANNEL_ACCOUNT_ADD = "/message/mailAccount/add";

    String MESSAGE_MAIL_CHANNEL_ACCOUNT_UPDATE = "/message/mailAccount/update";



    /**
     * 添加渠道账户
     */
    String MESSAGE_MAIL_ROUTE_CONFIG_ADD = "/message/mailRouteConfig/add";

    /**
     * 渠道账户列表
     */
    String MESSAGE_MAIL_ROUTE_CONFIG_LIST = "/message/mailRouteConfig/list";

    /**
     * 渠道账户修改
     */
    String MESSAGE_MAIL_ROUTE_CONFIG_UPDATE = "/message/mailRouteConfig/update";


    /**
     * 邮件发送记录
     */
    String MESSAGE_MAIL_SEND_LOG_LIST = "/message/mailSendLog/list";

}
