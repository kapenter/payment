/*******************************************************************************
 * Create on 2019/9/2 17:39
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.fallback;

import com.neo.cornerstone.management.payment.feign.PaymentProtocolFeign;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.protocol.ProtocolRowDTO;
import com.neo.payment.dto.admin.protocol.QueryPageRequestDTO;
import com.neo.payment.dto.admin.protocol.UnbindRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Component
public class PaymentProtocolFallback implements PaymentProtocolFeign {
    private static Logger logger = LoggerFactory.getLogger(PaymentProtocolFallback.class);

    @Override
    public PageResponseDTO<ProtocolRowDTO> queryPage(QueryPageRequestDTO requestDTO) {
        logger.error("[分页查询支付协议] [fallback] 查询协议列表失败，调用远程服务失败");
        return PageResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<Long> unbind(UnbindRequestDTO requestDTO) {
        logger.error("[解绑支付协议] [fallback] 解绑支付协议失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

}
