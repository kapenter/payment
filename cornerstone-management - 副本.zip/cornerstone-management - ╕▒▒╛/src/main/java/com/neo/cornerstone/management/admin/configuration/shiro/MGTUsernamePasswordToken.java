package com.neo.cornerstone.management.admin.configuration.shiro;

import org.apache.shiro.authc.UsernamePasswordToken;

public class MGTUsernamePasswordToken extends UsernamePasswordToken {

    public MGTUsernamePasswordToken() {
    }

    public MGTUsernamePasswordToken(String username, String password, boolean rememberMe, String host) {
        super(username, password, rememberMe, host);
    }

    private String postKaptcha;
    private Object kaptcha;

    public String getPostKaptcha() {
        return postKaptcha;
    }

    public void setPostKaptcha(String postKaptcha) {
        this.postKaptcha = postKaptcha;
    }

    public Object getKaptcha() {
        return kaptcha;
    }

    public void setKaptcha(Object kaptcha) {
        this.kaptcha = kaptcha;
    }
}
