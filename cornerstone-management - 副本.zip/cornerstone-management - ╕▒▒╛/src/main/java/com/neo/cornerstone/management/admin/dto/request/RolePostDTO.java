package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

public class RolePostDTO extends BaseObject {
    private static final long serialVersionUID = -1202947323407795832L;
    @NotEmpty(message = "角色名称不能为空")
    @Length(max = 150, message = "角色名称长度不符")
    private String name;
    @NotNull(message = "状态不能为空")
    private Integer state;

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
