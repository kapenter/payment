package com.neo.cornerstone.management.admin.service;

import com.neo.cornerstone.management.admin.enums.ErrorCode;
import com.neo.cornerstone.management.base.exception.ParamsException;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.BaseModel;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.base.dto.PageModel;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public abstract class MysqlBaseServiceImpl<T extends BaseModel> {

    protected final transient Logger logger = LoggerFactory.getLogger(this.getClass());

    protected static final Integer MAX_PAGE_SIZE = 100;

    public Boolean deleteById(Long id) {
        if (null == id) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().deleteById(id) == 1;
    }

    public int deleteByCondition(BaseParams params) {
        if (null == params) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().deleteByCondition(params);
    }

    public T queryById(Long id) {
        if (null == id) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().queryById(id);
    }

    public T queryByCondition(BaseParams params) {
        if (null == params) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().queryByCondition(params);
    }

    public List<T> queryListByCondition(BaseParams params) {
        if (null == params) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().queryListByCondition(params);
    }

    public int queryCountByCondition(BaseParams params) {
        if (null == params) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().queryCountByCondition(params);
    }

    public PageModel <T> queryPage(BaseParams params) {
        if (params.getPageNum() < 0) {
            params.setPageNum(0);
        }

        PageModel<T> pageModel = new PageModel<>();

        List<T> resultList = getBaseMapper().queryPageList(params);
        if (CollectionUtils.isNotEmpty(resultList)) {
            pageModel.setData(resultList);
            pageModel.setTotalRows(getBaseMapper().queryPageCountList(params));
        }
        return pageModel;
    }

    public Long saveModel(T params) {
        if (null == params) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        if (getBaseMapper().saveModel(params) == 1) {
            return params.getId();
        }
        return null;
    }

    public int saveListModel(List<T> paramList) {
        if (CollectionUtils.isEmpty(paramList)) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().saveListModel(paramList);
    }

    public Boolean updateById(T params) {
        if (null == params) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().updateById(params) == 1;
    }

    public Boolean disableRecordById(Long id) {
        if (null == id) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().disableRecordById(id) == 1;
    }

    public Boolean enableRecordById(Long id) {
        if (null == id) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return getBaseMapper().enableRecordById(id) == 1;
    }

    public abstract BaseMapper <T> getBaseMapper();

    public abstract BaseParams getParamsDTO();

    public abstract T getObjectModel();
}
