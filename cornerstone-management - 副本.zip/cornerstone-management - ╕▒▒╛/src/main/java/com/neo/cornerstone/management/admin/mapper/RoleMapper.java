package com.neo.cornerstone.management.admin.mapper;

import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.Role;
import org.springframework.stereotype.Repository;

/**
 * Title:TRoleMapper<br/>
 * Description:(角色mapper接口)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public interface RoleMapper extends BaseMapper <Role> {

}
