package com.neo.cornerstone.management.admin.mapper;

import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.User;
import com.neo.cornerstone.management.admin.model.ext.UserExt;
import com.neo.cornerstone.management.admin.model.params.BaseParams;

import java.util.List;

/**
 * Title:TUserMapper<br/>
 * Description:(用户mapper接口)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public interface UserMapper extends BaseMapper <User> {

    int removeOrg(Long orgId);

    List <UserExt> queryPageListExt(BaseParams params);

    int queryPageCountListExt(BaseParams params);
}
