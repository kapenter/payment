package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.MerchantAppAccountFeign;
import com.neo.cornerstone.management.message.resp.BaseRespDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountRequestDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountUpdateDTO;
import com.neo.cornerstone.message.dto.response.MerchantAppAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 17:30
 **/
@Component
@Slf4j
public class MerchantAppAccountFallbackFactory implements FallbackFactory<MerchantAppAccountFeign> {



    @Override
    public MerchantAppAccountFeign create(Throwable throwable) {
        return new MerchantAppAccountFeign() {
            @Override
            public PageResponseDTO<MerchantAppAccountRespDTO> pageMerchantAppAccount(MerchantAppAccountQueryDTO merchantAppAccountQueryDTO) {
                log.error("[fallback]---[消息管理]---[应用账号]---[pageMerchantAppAccount]列表异常,msg:{},cause:",throwable.getMessage(),throwable);
                PageResponseDTO<MerchantAppAccountRespDTO> pageResponseDTO=new PageResponseDTO<>();
                pageResponseDTO.setReturnCode(BizCodeEnum.SMS_PAGE_MERCHANT_APP_ACCOUNT_FALLBACK_EXCEPTION.getCode());
                pageResponseDTO.setReturnMsg(BizCodeEnum.SMS_PAGE_MERCHANT_APP_ACCOUNT_FALLBACK_EXCEPTION.getMessage());
                return pageResponseDTO;
            }

            @Override
            public List<MerchantAppAccountRespDTO> allMerchantAppAccount() {
                log.error("[fallback]---[消息管理]---[应用账号]---[allMerchantAppAccount]列表异常,msg:{},cause:",throwable.getMessage(),throwable);
                return Collections.emptyList();
            }

            @Override
            public OperationResponseDTO<Boolean> createAppAccount(MerchantAppAccountRequestDTO merchantAppAccountRequestDTO) {
                log.error("[fallback]---[消息管理]---[应用账号]---[createAppAccount]新增异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.MAIL_ADD_ROUTE_CONFIG_FALLBACK_EXCEPTION);
            }

            @Override
            public OperationResponseDTO<Boolean> updateAppAccount(MerchantAppAccountUpdateDTO merchantAppAccountUpdateDTO) {
                log.error("[fallback]---[消息管理]---[应用账号]---[updateAppAccount]修改异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.MAIL_UPDATE_ROUTE_CONFIG_FALLBACK_EXCEPTION);
            }
        };
    }
}
