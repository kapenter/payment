package com.neo.cornerstone.management.admin.configuration.kaptcha;

import java.security.SecureRandom;

import com.google.code.kaptcha.text.TextProducer;
import com.google.code.kaptcha.util.Configurable;

/**
 * <p>Title:</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2018</p>
 *
 * @author Luo Shun
 */
public class MGTTextProducer extends Configurable implements TextProducer {
    private static final char[] ALPHABET = new char[] { 'E', 'F', 'K', 'N', 'R', 'X' };
    private static final SecureRandom rand = new SecureRandom();

    public MGTTextProducer() {
    }

    private static char[] shuffle(char[] arr) {
        for (int i = arr.length; i > 1; --i) {
            swap(arr, i - 1, rand.nextInt(i));
        }

        return arr;
    }

    private static void swap(char[] arr, int i, int j) {
        char tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }

    @Override public String getText() {
        int length = this.getConfig().getTextProducerCharLength();
        char[] chars = this.getConfig().getTextProducerCharString();
        char[] randomChars = new char[length];

        for (int i = 0; i < length; ++i) {
            randomChars[i] = chars[rand.nextInt(chars.length)];
        }

        return new String(shuffle(randomChars));
    }
}
