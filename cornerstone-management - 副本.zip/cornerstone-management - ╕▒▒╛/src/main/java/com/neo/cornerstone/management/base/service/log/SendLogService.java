package com.neo.cornerstone.management.base.service.log;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.client.producer.SendStatus;
import com.alibaba.rocketmq.common.message.Message;
import com.baomidou.mybatisplus.toolkit.IdWorker;
import com.neo.cornerstone.management.admin.exception.MqLogSendException;
import com.neo.cornerstone.management.base.constants.GlobalConfigConstant;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.enums.BehaviorResult;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.cornerstone.management.base.util.ContentUtil;
import com.neo.cornerstone.toolbox.utils.AES;
import com.neo.msplatform.framework.utils.rocketmq.service.RocketmqMessageService;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/*******************************************************************************
 * Created on 2019/8/28 14:15
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Service("sendLogService")
public class SendLogService extends BaseService {

    @Value("${logSecretKey}")
    private String logSecretKey;

    @Autowired
    private RocketmqMessageService rocketmqMessageService;

    public void sendOperationLog(OperationModule operationModule, BehaviorResult behaviorResult) {
        sendOperationLog(operationModule, behaviorResult, false);
    }

    public void sendOperationLog(OperationModule operationModule, BehaviorResult behaviorResult, boolean encrypt) {
        OperationLog operationLog = OperationLog.init(operationModule)
                .setOperationResult(behaviorResult.getCode());
        sendOperationLog(operationLog, encrypt);
    }

    public void sendOperationLog(OperationLog operationLog, OperationModule operationModule, BehaviorResult behaviorResult) {
        sendOperationLog(operationLog, operationModule, behaviorResult, false);
    }

    public void sendOperationLog(OperationLog operationLog, OperationModule operationModule,
            BehaviorResult behaviorResult, boolean encrypt) {
        operationLog = operationLog.setModuleType(operationModule.getModuleType())
                .setSubModuleType(operationModule.getSubModuleType())
                .setOperationContent(operationModule.getOperationContent()).setOperationResult(behaviorResult.getCode());
        sendOperationLog(operationLog, encrypt);
    }

    private OperationLog dealPrincipalInfo(OperationLog operationLog) {
        String username = null;
        try {
            username = (String) SecurityUtils.getSubject().getPrincipal();

        } catch (Exception e) {
            logger.warn("Operation Log 操作[{}] - [{}] - [{}] - 未获取登录用户信息", operationLog.getModuleType(),
                    operationLog.getSubModuleType(), operationLog.getOperationContent());
        }
        String bizId = null;
        try {
            Object preBizId = SecurityUtils.getSubject().getSession().getAttribute(GlobalConfigConstant.ACCESS_TOKEN);
            if (null != preBizId) {
                bizId = (String) preBizId;
            }
            if (null == bizId) {
                bizId = (String) SecurityUtils.getSubject().getSession().getId();
                bizId = bizId.substring(0, bizId.length() - 8);
            }
        } catch (Exception e) {
            logger.warn("Operation Log 操作[{}] - [{}] - [{}] - 获取session信息异常", operationLog.getModuleType(),
                    operationLog.getSubModuleType(), operationLog.getOperationContent());
        }
        Object preIp = ContentUtil.get(ContentUtil.REMOTE_IP);
        operationLog.setIp(preIp == null ? null : (String) preIp);
        operationLog.setUsername(username == null ? operationLog.getUsername(): username);
        operationLog.setBizId(bizId == null ? IdWorker.getId() + "" : bizId);
        return operationLog;
    }

    public void sendOperationLog(OperationLog operationLog, boolean encrypt) {

        if (encrypt) {
            if (null != operationLog.getOriginalSnapshot()) {
                operationLog.setOriginalSnapshot(AES.encryptToBase64(operationLog.getOriginalSnapshot(), logSecretKey));
            }
            if (null != operationLog.getSnapshot()) {
                operationLog.setSnapshot(AES.encryptToBase64(operationLog.getSnapshot(), logSecretKey));
            }
            if (null != operationLog.getOperationParams()) {
                operationLog.setOperationParams(AES.encryptToBase64(operationLog.getOperationParams(), logSecretKey));
            }
        }
        dealPrincipalInfo(operationLog);
        SendResult result = rocketmqMessageService.sendMessage(
                new Message(GlobalConfigConstant.MANAGEMENT_LOG_TOPIC, GlobalConfigConstant.OPERATION_LOG_TAG,
                        operationLog.getBizId(), JSON.toJSONString(operationLog).getBytes()));
        if (!SendStatus.SEND_OK.equals(result.getSendStatus())) {
            logger.error("Operation Log 发送mq 失败 [{}]", operationLog);
            throw new MqLogSendException("Operation Log send failure");
        }
        logger.info("Operation Log 发送mq 成功 [{}]", operationLog);
    }
}
