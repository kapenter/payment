//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.neo.cornerstone.management.base.exception;

import java.util.Date;

public interface BaseException {
    String getCode();

    String[] getArgs();

    void setTime(Date var1);

    Date getTime();

    void setClassName(String var1);

    String getClassName();

    void setMethodName(String var1);

    String getMethodName();

    void setParameters(String[] var1);

    String[] getParameters();

    void setHandled(boolean var1);

    boolean isHandled();

    String getMessage();

    void setI18nMessage(String var1);

    String getI18nMessage();
}
