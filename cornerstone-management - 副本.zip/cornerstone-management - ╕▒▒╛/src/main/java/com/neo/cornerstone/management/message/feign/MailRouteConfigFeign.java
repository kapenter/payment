package com.neo.cornerstone.management.message.feign;

import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.feign.FallbackFactory.MailRouteConfigFallbackFactory;
import com.neo.cornerstone.message.dto.request.MailAccountRouteConfigQueryDTO;
import com.neo.cornerstone.message.dto.request.MailRouteConfigRequestDTO;
import com.neo.cornerstone.message.dto.response.MailRouteConfigRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-28 14:06
 **/
@FeignClient(value = "springcloud-5101-message",fallbackFactory = MailRouteConfigFallbackFactory.class)
public interface MailRouteConfigFeign {

    @RequestMapping(value = MessageURL.MESSAGE_MAIL_ROUTE_CONFIG_LIST,method = RequestMethod.POST)
    PageResponseDTO<MailRouteConfigRespDTO> pageMailAccountRouteConfig(@RequestBody MailAccountRouteConfigQueryDTO mailAccountRouteConfigQueryDTO);

    @RequestMapping(value = MessageURL.MESSAGE_MAIL_ROUTE_CONFIG_ADD,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> addMailAccountRouteConfig(@RequestBody MailRouteConfigRequestDTO mailRouteConfigRequestDTO);

    @RequestMapping(value = MessageURL.MESSAGE_MAIL_ROUTE_CONFIG_UPDATE,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> updateMailAccountRouteConfig(@RequestBody MailRouteConfigRequestDTO mailRouteConfigRequestDTO);

}
