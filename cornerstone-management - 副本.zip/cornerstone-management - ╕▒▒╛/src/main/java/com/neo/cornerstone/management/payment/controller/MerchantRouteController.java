/*******************************************************************************
 * Create on 2019/9/2 17:45
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.controller;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.payment.constant.URL;
import com.neo.cornerstone.management.payment.service.MerchantRouteService;
import com.neo.cornerstone.management.payment.vo.route.QueryPageRequestVO;
import com.neo.payment.dto.admin.route.RouteConfigRowDTO;
import com.neo.payment.dto.admin.route.UpdateConfigRequestDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@RestController
public class MerchantRouteController {
    @Autowired
    private MerchantRouteService merchantRouteService;

    @RequestMapping(path = URL.QUERY_MERCHANT_ROUTE_CONFIG_PAGE_LIST)
    public PageModel<RouteConfigRowDTO> queryPage(@RequestBody QueryPageRequestVO requestVO) {
        return merchantRouteService.queryPage(requestVO);
    }

    @RequestMapping(path = URL.OPEN_MERCHANT_ROUTE_CONFIG)
    public BaseResponse<String> openConfig(@RequestBody List<Integer> list) {
        return merchantRouteService.openConfig(list);
    }

    @RequestMapping(path = URL.CLOSE_MERCHANT_ROUTE_CONFIG)
    public BaseResponse<String> closeConfig(@RequestBody List<Integer> list) {
        return merchantRouteService.closeConfig(list);
    }

    @RequestMapping(path = URL.MODIFY_MERCHANT_ROUTE_CONFIG)
    public BaseResponse<String> updateConfig(@RequestBody UpdateConfigRequestDTO requestDTO) {
        return merchantRouteService.updateConfig(requestDTO);
    }

    @RequestMapping(path = URL.FLUSH_ALL_MERCHANT_ROUTE_CONFIG)
    public BaseResponse<String> flushAll() {
        return merchantRouteService.flushAll();
    }

    @RequestMapping(path = URL.FLUSH_MERCHANT_ROUTE_CONFIG)
    public BaseResponse<String> flushCache(@RequestBody List<Integer> list) {
        return merchantRouteService.flushCache(list);
    }

}
