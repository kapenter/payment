package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.ChannelAccountFeign;
import com.neo.cornerstone.management.message.resp.BaseRespDTO;
import com.neo.cornerstone.message.dto.request.ChannelAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.ChannelAccountRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 16:08
 **/
@Component
@Slf4j
public class ChannelAccountFallbackFactory implements FallbackFactory<ChannelAccountFeign> {


    @Override
    public ChannelAccountFeign create(Throwable throwable) {
        return new ChannelAccountFeign(){

            @Override
            public PageResponseDTO<ChannelAccountRespDTO> pageChannelAccounts(ChannelAccountQueryDTO channelAccountQueryDTO) {
                log.error("[fallback]---[消息管理]---[短信管理]---[渠道账户]---[pageChannelAccounts]列表异常,msg:{},cause:" ,throwable.getMessage(),throwable);
                PageResponseDTO<ChannelAccountRespDTO> pageResponseDTO=new PageResponseDTO<>();
                pageResponseDTO.setReturnCode(BizCodeEnum.SMS_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION.getCode());
                pageResponseDTO.setReturnMsg(BizCodeEnum.SMS_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION.getMessage());
                return pageResponseDTO;
            }

            @Override
            public OperationResponseDTO<Boolean> addChannelAccount(ChannelAccountRequestDTO channelAccountRequestDTO) {
                log.error("[fallback]---[消息管理]---[短信管理]---[渠道账户]---[addChannelAccount]新增异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.SMS_ADD_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION);
            }

            @Override
            public OperationResponseDTO<Boolean> updateChannelAccount(ChannelAccountRequestDTO channelAccountRequestDTO) {
                log.error("[fallback]---[消息管理]---[短信管理]---[渠道账户]---[updateChannelAccount]修改异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.SMS_UPDATE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION);
            }
        };
    }



}
