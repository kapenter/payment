package com.neo.cornerstone.management.admin.service.biz;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.neo.cornerstone.management.admin.dto.request.MenuPostDTO;
import com.neo.cornerstone.management.admin.dto.request.MenuUpdateDTO;
import com.neo.cornerstone.management.admin.dto.response.MenuInfoDTO;
import com.neo.cornerstone.management.admin.enums.AdminReturnCode;
import com.neo.cornerstone.management.admin.enums.StateEnum;
import com.neo.cornerstone.management.admin.model.Menu;
import com.neo.cornerstone.management.admin.model.Permission;
import com.neo.cornerstone.management.admin.model.RoleMenu;
import com.neo.cornerstone.management.admin.model.RolePermission;
import com.neo.cornerstone.management.admin.model.params.MenuParams;
import com.neo.cornerstone.management.admin.model.params.PermissionParams;
import com.neo.cornerstone.management.admin.model.params.RoleMenuParams;
import com.neo.cornerstone.management.admin.model.params.RolePermissionParams;
import com.neo.cornerstone.management.admin.service.common.MenuService;
import com.neo.cornerstone.management.admin.service.common.PermissionService;
import com.neo.cornerstone.management.admin.service.common.RoleMenuService;
import com.neo.cornerstone.management.admin.service.common.RolePermissionService;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.enums.BehaviorResult;
import com.neo.cornerstone.management.base.exception.BizRuntimeException;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.cornerstone.management.base.service.log.SendLogService;

/*******************************************************************************
 * Created on 2019/7/25 16:04
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Service("menuBizService")
public class MenuBizService extends BaseService {

    @Autowired
    private MenuService menuService;
    @Autowired
    private PermissionService permissionService;
    @Autowired
    private RolePermissionService rolePermissionService;
    @Autowired
    private RoleMenuService roleMenuService;
    @Autowired
    private SendLogService sendLogService;

    /**
     * 更新菜单信息
     * @param id
     * @param menuUpdateDTO
     */
    public Boolean updateMenu(Long id, MenuUpdateDTO menuUpdateDTO) {
        Boolean result = false;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_MENU_UPDATE).setOperationParams("[" + id + "]-" + JSON.toJSONString(menuUpdateDTO));

        Menu menuData = null;
        Menu updateParams = null;
        try {
            menuData = menuService.queryById(id);
            if (menuData == null) {
                throw new BizRuntimeException(AdminReturnCode.MENU_NOT_EXISTS.getCode(), AdminReturnCode.MENU_NOT_EXISTS.getMessage());
            }

            MenuParams queryParam = new MenuParams();
            queryParam.setParentId(menuData.getParentId());
            queryParam.setName(menuUpdateDTO.getName());
            List <Menu> dataList = menuService.queryListByCondition(queryParam);
            if (CollectionUtils.isNotEmpty(dataList)) {
                if (dataList.size() > 1 || !dataList.get(0).getId().equals(menuData.getId())) {
                    throw new BizRuntimeException(AdminReturnCode.MENU_LEVEL_EXISTS.getCode(), AdminReturnCode.MENU_LEVEL_EXISTS.getMessage());
                }
            }

            updateParams = new Menu();
            updateParams.setId(id);
            updateParams.setName(menuUpdateDTO.getName());
            updateParams.setUrl(menuUpdateDTO.getUrl());
            updateParams.setParameter(menuUpdateDTO.getParameter());
            updateParams.setModTime(new Date());
            updateParams.setState(menuUpdateDTO.getState().equals(StateEnum.VALID.getCode()) ? StateEnum.VALID.getCode() : StateEnum.INVALID.getCode());
            result = menuService.updateById(updateParams);

            operationLog.setRemark(menuData.getName())
                    .setSnapshot(JSON.toJSONString(updateParams))
                    .setOriginalSnapshot(JSON.toJSONString(menuData))
                    .setOperationResult(result ? BehaviorResult.SUCCESS.getCode() : BehaviorResult.FAILURE.getCode());
        } catch (Exception e) {
            operationLog.setRemark(menuData == null ? "" : menuData.getName())
                    .setSnapshot(JSON.toJSONString(updateParams))
                    .setOriginalSnapshot(JSON.toJSONString(menuData))
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }

        return result;
    }

    /**
     * 删除
     * @param id
     * @return
     */
    public boolean deleteMenu(Long id) {
        Menu menuData = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_MENU_DELETE).setOperationParams(id + "");
        try {
            menuData = menuService.queryById(id);
            if (menuData == null) {
                throw new BizRuntimeException(AdminReturnCode.MENU_NOT_EXISTS.getCode(), AdminReturnCode.MENU_NOT_EXISTS.getMessage());
            }
            deleteMenuData(id);

            operationLog.setOriginalSnapshot(JSON.toJSONString(menuData))
                    .setRemark(menuData.getName())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
        } catch (Exception e) {
            operationLog.setOriginalSnapshot(JSON.toJSONString(menuData))
                    .setRemark(menuData != null ? menuData.getName() : null)
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }

        return true;
    }

    /**
     * 删除菜单关联的信息
     * @param id
     */
    private void deleteMenuData(Long id) {
        RoleMenuParams roleMenuParams = new RoleMenuParams();
        roleMenuParams.setMenuId(id);
        List <RoleMenu> roleMenuList = roleMenuService.queryListByCondition(roleMenuParams);
        if (CollectionUtils.isNotEmpty(roleMenuList)) {
            throw new BizRuntimeException(AdminReturnCode.MENU_REF_ROLE.getCode(), AdminReturnCode.MENU_REF_ROLE.getMessage());
        }

        // 菜单
        menuService.deleteById(id);
        // 菜单关联权限
        PermissionParams permissionParams = new PermissionParams();
        permissionParams.setMenuId(id);
        List<Permission> permissionDataList = permissionService.queryListByCondition(permissionParams);
        if (CollectionUtils.isNotEmpty(permissionDataList)) {
            for (Permission permission : permissionDataList) {
                // role permission
                RolePermissionParams rolePermissionParams = new RolePermissionParams();
                rolePermissionParams.setPermissionId(permission.getId());
                List <RolePermission> rolePermissionList = rolePermissionService
                        .queryListByCondition(rolePermissionParams);
                if (CollectionUtils.isNotEmpty(rolePermissionList)) {
                    throw new BizRuntimeException(AdminReturnCode.MENU_PERMISSION_REF_ROLE.getCode(), AdminReturnCode.MENU_PERMISSION_REF_ROLE.getMessage());
                }
                permissionService.deleteById(permission.getId());
            }
        }
        // role menu
       /* RoleMenuParams roleMenuParams = new RoleMenuParams();
        roleMenuParams.setMenuId(id);
        roleMenuService.deleteByCondition(roleMenuParams);*/

        MenuParams menuParams = new MenuParams();
        menuParams.setParentId(id);

        List<Menu> subMenuData = menuService.queryListByCondition(menuParams);
        if (CollectionUtils.isNotEmpty(subMenuData)) {
            for (Menu menu : subMenuData) {
                deleteMenuData(menu.getId());
            }
        }
    }

    /**
     * 添加
     * @param menuPostDTO
     * @return
     */
    public Long addSubMenu(MenuPostDTO menuPostDTO) {
        Menu menuParams = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_MENU_ADD).setOperationParams(JSON.toJSONString(menuPostDTO));
        try {
            // 校验
            Menu parentData = menuService.queryById(menuPostDTO.getParentId());
            if (parentData == null && menuPostDTO.getParentId() != 0) {
                throw new BizRuntimeException(AdminReturnCode.MENU_PARENT_ERROR.getCode(), AdminReturnCode.MENU_PARENT_ERROR.getMessage());
            }
            MenuParams queryParam = new MenuParams();
            queryParam.setParentId(menuPostDTO.getParentId());
            queryParam.setName(menuPostDTO.getName());
            List <Menu> dataList = menuService.queryListByCondition(queryParam);
            if (CollectionUtils.isNotEmpty(dataList)) {
                throw new BizRuntimeException(AdminReturnCode.MENU_LEVEL_EXISTS.getCode(), AdminReturnCode.MENU_LEVEL_EXISTS.getMessage());
            }

            // 添加
            menuParams = new Menu();
            menuParams.setParentId(menuPostDTO.getParentId());
            menuParams.setLevel(parentData == null ? 1 : parentData.getLevel() + 1);
            menuParams.setName(menuPostDTO.getName());
            menuParams.setUrl(menuPostDTO.getUrl());
            menuParams.setParameter(menuPostDTO.getParameter());
            menuParams.setParentId(parentData == null ? 0 : parentData.getId());
            menuParams.setState(menuPostDTO.getState().equals(StateEnum.VALID.getCode()) ? StateEnum.VALID.getCode() : StateEnum.INVALID.getCode());
            menuParams.setCreateTime(new Date());
            Long id = menuService.saveModel(menuParams);

            operationLog.setSnapshot(JSON.toJSONString(menuParams))
                    .setRemark(menuParams.getName())
                    .setOperationResult(id == null ? BehaviorResult.FAILURE.getCode() : BehaviorResult.SUCCESS.getCode());
            return id;
        } catch (Exception e) {
            operationLog.setSnapshot(JSON.toJSONString(menuParams))
                    .setRemark(menuPostDTO.getName())
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }

    /**
     * 查询与构建菜单信息
     * @return
     */
    public List<MenuInfoDTO> queryAllMenu() {
        return addRootMenu(queryAllMenuData());
    }

    /**
     * 添加菜单跟目录
     * @param menuInfoDTOList
     * @return
     */
    private List<MenuInfoDTO> addRootMenu(List<MenuInfoDTO> menuInfoDTOList) {
        // 根
        MenuInfoDTO root = new MenuInfoDTO();
        root.setId(0L);
        root.setLabel("菜单目录");
        root.setState(StateEnum.VALID.getCode());
        root.setUrl("root");
        root.setChildren(menuInfoDTOList);

        List<MenuInfoDTO> allList = new ArrayList<>();
        allList.add(root);
        return allList;
    }

    /**
     * 查询所有的菜单详细信息
     * @return
     */
    public List<MenuInfoDTO> queryAllMenuData() {
        MenuParams menuParams = new MenuParams();
        menuParams.setLevel(1);
        List<Menu> menuDataList = menuService.queryListByCondition(menuParams);
        List<MenuInfoDTO> menuInfoDTOList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(menuDataList)) {
            for (Menu menu : menuDataList) {
                MenuInfoDTO menuInfoDTO = dealMenuData(menu);
                menuInfoDTOList.add(menuInfoDTO);
            }
        }
        return menuInfoDTOList;
    }

    private MenuInfoDTO dealMenuData(Menu menu) {
        MenuInfoDTO menuInfo = new MenuInfoDTO();
        menuInfo.setId(menu.getId());
        menuInfo.setLevel(menu.getLevel());
        menuInfo.setLabel(menu.getName());
        menuInfo.setState(menu.getState());
        menuInfo.setParentId(menu.getParentId());
        menuInfo.setValue(menu.getId());
//        menuInfo.setDisabled(StateEnum.VALID.getCode().equals(menu.getState()) ? false : true);
        menuInfo.setUrl(menu.getUrl());
        menuInfo.setParameter(menu.getParameter());

        MenuParams menuParams = new MenuParams();
        menuParams.setParentId(menuInfo.getId());
        List<Menu> subMenuDataList = menuService.queryListByCondition(menuParams);
        if (CollectionUtils.isNotEmpty(subMenuDataList)) {
            List<MenuInfoDTO> subMenuInfoList = new ArrayList<>();
            for (Menu subMenu : subMenuDataList) {
                subMenuInfoList.add(dealMenuData(subMenu));
            }
            menuInfo.setChildren(subMenuInfoList);
        }
        return menuInfo;
    }
}
