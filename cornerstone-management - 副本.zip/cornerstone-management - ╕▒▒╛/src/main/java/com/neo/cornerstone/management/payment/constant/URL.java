/*******************************************************************************
 * Create on 2019/9/2 17:46
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.constant;

import com.neo.cornerstone.management.base.constants.BaseUrl;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
public interface URL {

    /**
     * 分页查询协议
     */
    String PAYMENT_PROTOCOL_PAGE_LIST = BaseUrl.ROOT_URL + "payment/protocol/page/list";
    /**
     * 解绑协议
     */
    String UNBIND_PAYMENT_PROTOCOL = BaseUrl.ROOT_URL + "payment/protocol/unbind";
    /**
     * 分页查询支付记录
     */
    String PAYMENT_RECORD_PAGE_LIST = BaseUrl.ROOT_URL + "payment/record/page/list";
    /**
     * 同步结果
     */
    String SYNC_PAYMENT_RECORD_RESULT = BaseUrl.ROOT_URL + "payment/record/sync";
    /**
     * 置为失败
     */
    String SET_PAYMENT_RECORD_FAIL = BaseUrl.ROOT_URL + "payment/record/set/fail";
    /**
     * 分页查询限额拆单原始记录
     */
    String QUERY_BEST_PAYMENT_RECORD_PAGE_LIST = BaseUrl.ROOT_URL + "payment/best/record/page/list";
    /**
     * 限额拆单原始记录同步结果
     */
    String SYNC_BEST_PAYMENT_RECORD_RESULT = BaseUrl.ROOT_URL + "payment/best/record/sync";
    /**
     * 限额拆单原始记录置为失败
     */
    String SET_BEST_PAYMENT_RECORD_FAIL = BaseUrl.ROOT_URL + "payment/best/record/set/fail";
    /**
     * 查询拆单记录
     */
    String QUERY_BEST_QUOTA_PAYMENT_RECORD_LIST = BaseUrl.ROOT_URL + "payment/best/quota/record/list";
    /**
     * 分页商户渠道配置
     */
    String QUERY_MERCHANT_CHANNEL_CONFIG_PAGE_LIST = BaseUrl.ROOT_URL + "payment/merchant/channel/config/page/list";
    /**
     * 开启商户渠道配置
     */
    String OPEN_MERCHANT_CHANNEL_CONFIG = BaseUrl.ROOT_URL + "payment/merchant/channel/config/open";
    /**
     * 禁用商户渠道配置
     */
    String CLOSE_MERCHANT_CHANNEL_CONFIG = BaseUrl.ROOT_URL + "payment/merchant/channel/config/close";
    /**
     * 分页商户路由配置
     */
    String QUERY_MERCHANT_ROUTE_CONFIG_PAGE_LIST = BaseUrl.ROOT_URL + "payment/merchant/route/config/page/list";
    /**
     * 开启商路由配置
     */
    String OPEN_MERCHANT_ROUTE_CONFIG = BaseUrl.ROOT_URL + "payment/merchant/route/config/open";
    /**
     * 禁用商户路由配置
     */
    String CLOSE_MERCHANT_ROUTE_CONFIG = BaseUrl.ROOT_URL + "payment/merchant/route/config/close";
    /**
     * 修改商户路由配置
     */
    String MODIFY_MERCHANT_ROUTE_CONFIG = BaseUrl.ROOT_URL + "payment/merchant/route/config/modify";
    /**
     * 刷新所有商户路由缓存
     */
    String FLUSH_ALL_MERCHANT_ROUTE_CONFIG = BaseUrl.ROOT_URL + "payment/merchant/route/config/flush/all";
    /**
     * 刷新商户路由缓存
     */
    String FLUSH_MERCHANT_ROUTE_CONFIG = BaseUrl.ROOT_URL + "payment/merchant/route/config/flush";
    /**
     * 分页查询商户交易通知
     */
    String QUERY_MERCHANT_NOTIFY_PAGE_LIST = BaseUrl.ROOT_URL + "payment/merchant/notify/page/list";
    /**
     * 查询商户通知记录
     */
    String QUERY_MERCHANT_NOTIFY_RECORD_LIST = BaseUrl.ROOT_URL + "payment/merchant/notify/record/list";
    /**
     * 发送商户通知
     */
    String SEND_MERCHANT_NOTIFY = BaseUrl.ROOT_URL + "payment/merchant/notify/send";

}
