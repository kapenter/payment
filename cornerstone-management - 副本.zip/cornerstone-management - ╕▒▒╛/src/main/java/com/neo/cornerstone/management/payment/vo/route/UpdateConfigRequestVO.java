/*******************************************************************************
 * Create on 2019/9/5 17:35
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.vo.route;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Setter
@Getter
@ToString
public class UpdateConfigRequestVO implements Serializable {
    private static final long serialVersionUID = 5053628614322699684L;

    private Integer id;
    private String appId;
    private String channelCode;
    private Integer bizType;
    private Integer payType;
    private String bankType;
    private String bankName;
    private String channelBankType;
    private BigDecimal singleQuota;
    private BigDecimal dayQuota;
    private BigDecimal monthQuota;
    private Integer priority;
    private Integer weight;
    private String feeScript;
    private Integer status;
    private Date startFixTime;
    private Date endFixTime;

}
