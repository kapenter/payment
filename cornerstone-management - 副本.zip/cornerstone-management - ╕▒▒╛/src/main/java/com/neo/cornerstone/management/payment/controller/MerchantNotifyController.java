/*******************************************************************************
 * Create on 2019/9/2 17:45
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.controller;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.payment.constant.URL;
import com.neo.cornerstone.management.payment.service.MerchantNotifyService;
import com.neo.cornerstone.management.payment.vo.best.QueryBestPageRequestVO;
import com.neo.cornerstone.management.payment.vo.notify.QueryTradePageRequestVO;
import com.neo.payment.dto.admin.notify.NotifyRecordRowDTO;
import com.neo.payment.dto.admin.notify.TradeNotifyRowDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@RestController
public class MerchantNotifyController {
    @Autowired
    private MerchantNotifyService merchantNotifyService;

    @RequestMapping(path = URL.QUERY_MERCHANT_NOTIFY_PAGE_LIST)
    public PageModel<TradeNotifyRowDTO> queryTradePage(@RequestBody QueryTradePageRequestVO requestVO) {
        return merchantNotifyService.queryTradePage(requestVO);
    }

    @RequestMapping(path = URL.SEND_MERCHANT_NOTIFY)
    public BaseResponse<String> sendNotify(@RequestParam String notifyOrder) {
        return merchantNotifyService.sendNotify(notifyOrder);
    }

    @RequestMapping(path = URL.QUERY_MERCHANT_NOTIFY_RECORD_LIST)
    public BaseResponse<List<NotifyRecordRowDTO>> queryRecordList(@RequestParam String notifyOrder) {
        return merchantNotifyService.queryRecordList(notifyOrder);
    }

}
