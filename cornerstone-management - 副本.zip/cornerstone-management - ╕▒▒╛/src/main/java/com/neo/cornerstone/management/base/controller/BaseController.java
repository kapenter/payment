package com.neo.cornerstone.management.base.controller;


import com.neo.cornerstone.management.admin.exception.MqLogSendException;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.enums.GlobalReturnStatus;
import com.neo.cornerstone.management.base.exception.BaseRuntimeException;
import com.neo.cornerstone.message.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/*******************************************************************************
 * Created on 2019/6/17 18:55
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@ControllerAdvice
@Component
public class BaseController {

    protected final transient Logger logger = LoggerFactory.getLogger(this.getClass());

    @ExceptionHandler
    @ResponseBody
    public BaseResponse handle(HttpServletResponse response, Exception e) throws IOException {

        BaseResponse respModel = new BaseResponse();
        respModel.setStatus(GlobalReturnStatus.FAILURE.getStatus());
        logger.error(" 异常 ", e);
        if (e instanceof MethodArgumentTypeMismatchException) {
            respModel.setReturnCode(GlobalReturnCode.TYPE_MISMATCH.getCode());
            respModel.setReturnMsg(GlobalReturnCode.TYPE_MISMATCH.getMessage());
        } else if (e instanceof HttpMessageNotReadableException) {
            // E.G POST 不传递post 数据
            respModel.setReturnCode(GlobalReturnCode.ARGUMENT_MISSING.getCode());
            respModel.setReturnMsg(GlobalReturnCode.ARGUMENT_MISSING.getMessage());
        } else if (e instanceof MethodArgumentNotValidException) {
            respModel.setReturnCode(GlobalReturnCode.PARAMS_ERROR.getCode());
            respModel.setReturnMsg(((MethodArgumentNotValidException) e).getBindingResult().getAllErrors().get(0).getDefaultMessage());
        }else if (e instanceof BusinessException){
            BusinessException be=(BusinessException)e;
            // 数据库记录重复
            respModel.setReturnCode(be.getBizCode().getCode());
            respModel.setReturnMsg(be.getBizCode().getMessage());
        } else if (e instanceof MqLogSendException) {
            respModel.setReturnCode(GlobalReturnCode.LOG_ERROR.getCode());
            respModel.setReturnMsg(GlobalReturnCode.LOG_ERROR.getMessage());
        } else if(e instanceof BaseRuntimeException) {
            respModel.setReturnCode(((BaseRuntimeException) e).getCode());
            respModel.setReturnMsg(((BaseRuntimeException) e).getMessage());
        } else {
            respModel.setReturnCode(GlobalReturnCode.SYSTEM_ERROR.getCode());
            respModel.setReturnMsg(GlobalReturnCode.SYSTEM_ERROR.getMessage());
        }

        return respModel;
    }

}
