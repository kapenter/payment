package com.neo.cornerstone.management.message.feign;

import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.feign.FallbackFactory.MerchantAppAccountFallbackFactory;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountRequestDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountUpdateDTO;
import com.neo.cornerstone.message.dto.response.MerchantAppAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-22 15:12
 **/
@FeignClient(value = "springcloud-5101-message",fallbackFactory = MerchantAppAccountFallbackFactory.class)
public interface MerchantAppAccountFeign {

    @RequestMapping(value = MessageURL.MESSAGE_MERCHANT_APP_ACCOUNT_LIST,method = RequestMethod.POST)
    PageResponseDTO<MerchantAppAccountRespDTO>  pageMerchantAppAccount(@RequestBody MerchantAppAccountQueryDTO merchantAppAccountQueryDTO);

    @RequestMapping(value = MessageURL.MESSAGE_MERCHANT_APP_ACCOUNT_LIST_ALL,method = RequestMethod.POST)
    List<MerchantAppAccountRespDTO> allMerchantAppAccount();

    @RequestMapping(value = MessageURL.MESSAGE_MERCHANT_APP_ACCOUNT_ADD,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> createAppAccount(@RequestBody MerchantAppAccountRequestDTO merchantAppAccountRequestDTO);

    @RequestMapping(value = MessageURL.MESSAGE_MERCHANT_APP_ACCOUNT_UPDATE,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> updateAppAccount(MerchantAppAccountUpdateDTO merchantAppAccountUpdateDTO);
}
