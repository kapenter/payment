package com.neo.cornerstone.management.admin.mapper;

import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.UserRole;
import com.neo.cornerstone.management.admin.model.ext.UserRoleExt;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Title:TUserRoleMapper<br/>
 * Description:(用户角色配置mapper接口)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public interface UserRoleMapper extends BaseMapper <UserRole> {

    List <UserRoleExt> queryByUserId(@Param("userId") Long userId);

    /**
     * 查询用户拥有角色对应的菜单
     * @param userId
     * @return
     */
    List <UserRoleExt> queryRoleMenuByUserId(@Param("userId") Long userId);

    /**
     * 查询用户拥有角色对应的权限
     * @param userId
     * @return
     */
    List <UserRoleExt> queryRolePermissionByUserId(@Param("userId") Long userId);


}
