package com.neo.cornerstone.management.message.consts;

/**
 * @program: loanmkt-product
 * @description:
 * @author: xn086532
 * @create: 2019-08-05 13:50
 **/
public enum BizCodeEnum {

    SERVICE_EXCEPTION("10003","服务异常[S]"),


    /**************************************消息管理******************************************/
    SMS_PAGE_CHANNEL_INFO_FALLBACK_EXCEPTION("51010007","[fallback]---[消息管理]---[渠道管理]列表异常"),
    SMS_ADD_CHANNEL_INFO_FALLBACK_EXCEPTION("51010008","[fallback]---[消息管理]---[渠道管理]新增异常"),
    SMS_UPDATE_CHANNEL_INFO_FALLBACK_EXCEPTION("51010009","[fallback]---[消息管理]---[渠道管理]修改异常"),

    SMS_PAGE_MERCHANT_APP_ACCOUNT_FALLBACK_EXCEPTION("51010017","[fallback]---[消息管理]---[渠道管理]列表异常"),
    SMS_ADD_MERCHANT_APP_ACCOUNT_FALLBACK_EXCEPTION("51010018","[fallback]---[消息管理]---[渠道管理]新增异常"),
    SMS_UPDATE_MERCHANT_APP_ACCOUNT_FALLBACK_EXCEPTION("51010019","[fallback]---[消息管理]---[渠道管理]修改异常"),

    /**************************************短信管理******************************************/
    SMS_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION("51010001","[fallback]---[消息管理]---[短信管理]---[渠道账户]列表异常"),
    SMS_ADD_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION("51010002","[fallback]---[消息管理]---[短信管理]---[渠道账户]新增异常"),
    SMS_UPDATE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION("51010003","[fallback]---[消息管理]---[短信管理]---[渠道账户]修改异常"),

    SMS_PAGE_CHANNEL_ACCOUNT_ROUTE_CONFIG_FALLBACK_EXCEPTION("51010004","[fallback]---[消息管理]---[短信管理]---[路由配置]列表异常"),
    SMS_ADD_CHANNEL_ACCOUNT_ROUTE_CONFIG_FALLBACK_EXCEPTION("51010005","[fallback]---[消息管理]---[短信管理]---[路由配置]新增异常"),
    SMS_UPDATE_CHANNEL_ACCOUNT_ROUTE_CONFIG_FALLBACK_EXCEPTION("51010006","[fallback]---[消息管理]---[短信管理]---[路由配置]修改异常"),


    SMS_PAGE_SEND_RECORD_FALLBACK_EXCEPTION("51010016","[fallback]---[消息管理]---[邮件管理]---[发送记录]列表异常"),
    /**************************************路由管理******************************************/
    MAIL_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION("51010010","[fallback]---[消息管理]---[邮件管理]---[渠道账户]列表异常"),
    MAIL_ADD_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION("51010011","[fallback]---[消息管理]---[邮件管理]---[渠道账户]新增异常"),
    MAIL_UPDATE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION("51010012","[fallback]---[消息管理]---[邮件管理]---[渠道账户]修改异常"),


    MAIL_PAGE_ROUTE_CONFIG_FALLBACK_EXCEPTION("51010013","[fallback]---[消息管理]---[邮件管理]---[路由配置]列表异常"),
    MAIL_ADD_ROUTE_CONFIG_FALLBACK_EXCEPTION("51010014","[fallback]---[消息管理]---[邮件管理]---[路由配置]新增异常"),
    MAIL_UPDATE_ROUTE_CONFIG_FALLBACK_EXCEPTION("51010015","[fallback]---[消息管理]---[邮件管理]---[路由配置]修改异常"),

    MAIL_PAGE_SEND_RECORD_FALLBACK_EXCEPTION("51010016","[fallback]---[消息管理]---[邮件管理]---[发送记录]列表异常"),



    ;

    private String code;
    private String message;
    BizCodeEnum(String code, String message){
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
