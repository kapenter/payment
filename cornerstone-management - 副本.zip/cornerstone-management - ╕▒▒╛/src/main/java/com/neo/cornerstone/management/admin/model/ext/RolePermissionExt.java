package com.neo.cornerstone.management.admin.model.ext;

import com.neo.cornerstone.management.admin.model.Permission;
import com.neo.cornerstone.management.admin.model.RolePermission;

/*******************************************************************************
 * Created on 2019/8/13 16:32
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class RolePermissionExt extends RolePermission {
    private static final long serialVersionUID = 2255927925935126109L;

    private Permission permission;

    public Permission getPermission() {
        return permission;
    }

    public void setPermission(Permission permission) {
        this.permission = permission;
    }
}
