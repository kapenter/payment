package com.neo.cornerstone.management.admin.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.List;

/*******************************************************************************
 * Created on 2019/7/25 16:09
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class MenuInfoDTO extends BaseObject {
    private static final long serialVersionUID = -7729722660336174032L;
    private Long id;
    /**(名称)*/
    private String label;
    /**(层级)*/
    private Integer level;
    /**(url)*/
    private String url;
    private String parameter;
    /**(状态 1： 有效 0 ： 无效)*/
    private Integer state;
    private List <MenuInfoDTO> children;
    private Long parentId;

    // 用于页面
    private boolean disabled = false;
    private Long value;

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List <MenuInfoDTO> getChildren() {
        return children;
    }

    public void setChildren(List <MenuInfoDTO> children) {
        this.children = children;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }
}
