package com.neo.cornerstone.management.admin.configuration.shiro;

import org.apache.shiro.authz.Permission;
import org.apache.shiro.authz.permission.WildcardPermission;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * 自定义 WildcardPermission 对象，自定义权限校验时候的implies方法规则
 */
public class MGTPermission extends WildcardPermission {

    private PathMatcher pathMatcher = new AntPathMatcher();

    private static final long serialVersionUID = 5730151974730297018L;

    public MGTPermission(String wildcardString) {
        super(wildcardString);
        //强制permission必须 大于 xx:xxx 格式
        if (this.getParts().size() < 2 ) {
            throw new RuntimeException("illegal permission [" + wildcardString + "]");
        }
    }

    @Override
    public boolean implies(Permission permission) {
        if (!(permission instanceof MGTPermission)) {
            return false;
        } else {
            MGTPermission mgtPermission = (MGTPermission)permission;
            List<Set<String>> otherParts = mgtPermission.getParts();
            int i = 0;

            for(Iterator iterator = otherParts.iterator(); iterator.hasNext(); ++i) {
                Set<String> otherPart = (Set)iterator.next();
                if (this.getParts().size() - 1 < i) {
                    // 当 当前权限只是待检验权限的一部分时，当前权限已经验证完
                    return true;
                }

                Set<String> part = (Set)this.getParts().get(i);
                // 判断是否是 *  或者是否相等， 或者是否满足表达式要求
                if (!part.contains("*") && !(part.containsAll(otherPart) || pathMatcher.match(part.toString(), otherPart.toString()))) {
                    return false;
                }
            }

            /**
             * 当 当前权限比待检验的权限大， 需要判断后续的权限是否是任意可通过
             * 否则表示当前待检验权限只包含部分要求的权限
             */
            while(i < this.getParts().size()) {
                Set<String> part = (Set)this.getParts().get(i);
                if (!part.contains("*")) {
                    return false;
                }

                ++i;
            }

            return true;
        }
    }
}
