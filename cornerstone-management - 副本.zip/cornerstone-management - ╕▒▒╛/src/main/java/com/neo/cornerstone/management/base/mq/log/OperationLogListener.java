package com.neo.cornerstone.management.base.mq.log;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.log.OperationLogService;
import com.neo.msplatform.framework.utils.rocketmq.listener.impl.RocketMqMessageListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 *
 */
@Component
public class OperationLogListener implements RocketMqMessageListener, ApplicationContextAware {

    protected static final Logger logger = LoggerFactory.getLogger(OperationLogListener.class);
    @Autowired
    private OperationLogService operationLogService;

    private ApplicationContext applicationContext;
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public boolean onMessage(List<MessageExt> messages, ConsumeConcurrentlyContext consumeConcurrentlyContext) {
        logger.info("MQ: Operation Log  ,message size:{}-----------", messages.size());
        if (messages.size() > 1) {
            logger.error("MQ: Operation Log , not support multi message");
            return false;
        }

        try {
            String messageBody = new String(messages.get(0).getBody(), "UTF-8");
            OperationLog operationLog = JSON.parseObject(messageBody, OperationLog.class);
            logger.info("MQ: Operation Log - 开始处理[{}]", operationLog);
            operationLogService.saveOperationLog(operationLog);
        } catch (UnsupportedEncodingException e) {
            logger.error("MQ: Operation Log , Save with error ", e);
            return false;
        }
        return true;
    }
}
