package com.alibaba.springcloudalibaba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudAlibabaApplicationTests {

    @Test
    void contextLoads() {
    }

}
