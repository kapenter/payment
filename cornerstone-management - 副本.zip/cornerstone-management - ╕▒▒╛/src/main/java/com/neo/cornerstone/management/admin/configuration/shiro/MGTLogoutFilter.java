package com.neo.cornerstone.management.admin.configuration.shiro;

import com.neo.cornerstone.management.base.constants.GlobalConfigConstant;
import org.apache.shiro.session.SessionException;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authc.LogoutFilter;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.util.Locale;

public class MGTLogoutFilter extends LogoutFilter {

    private Logger logger = LoggerFactory.getLogger(MGTLogoutFilter.class);


    @Override
    protected boolean preHandle(ServletRequest request, ServletResponse response) throws Exception {
        Subject subject = getSubject(request, response);
        Object prename = subject.getPrincipal();
        if (isPostOnlyLogout()) {
            if (!WebUtils.toHttp(request).getMethod().toUpperCase(Locale.ENGLISH).equals("POST")) {
                return onLogoutRequestNotAPost(request, response);
            }
        }

        String redirectUrl = getRedirectUrl(request, response, subject);
        //try/catch added for SHIRO-298:
        try {
            subject.logout();
        } catch (SessionException ise) {
            logger.debug("Encountered session exception during logout.  This can generally safely be ignored.", ise);
        }
        String username = prename == null ? null: (String) prename;
        // 确保logout controller 还可以获取到用户名
        request.setAttribute(GlobalConfigConstant.USERNAME, username);
        issueRedirect(request, response, redirectUrl);
        return false;
    }

    @Override
    protected void issueRedirect(ServletRequest request, ServletResponse response, String redirectUrl)
            throws Exception {
        request.getRequestDispatcher(getRedirectUrl()).forward(request, response);
    }
}
