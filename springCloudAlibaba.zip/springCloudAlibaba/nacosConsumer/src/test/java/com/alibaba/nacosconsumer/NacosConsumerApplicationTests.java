package com.alibaba.nacosconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NacosConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
