package com.neo.cornerstone.management.admin.model.params;

import java.util.Date;

/**
 * Title:TUser<br/>
 * Description:(用户mapper参数对象)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class UserParams extends BaseParams {
    private static final long serialVersionUID = 5580994113221971949L;
    /**(用户名)*/
    private String username;
    private String patternName;
    private String realName;
    private String email;
    private String mobile;
    /**(密码)*/
    private String pwd;
    /**(部门ID)*/
    private Long orgId;
    /**(帐号状态: 0: 无效1：有效 2：冻结)*/
    private Integer accountState;
    /**(密码状态: 0: 需要修改 1: 正常使用)*/
    private Integer pwdState;
    private Integer state;
    /**()*/
    private Date createTime;
    /**()*/
    private Date modTime;

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPatternName() {
        return patternName;
    }

    public void setPatternName(String patternName) {
        this.patternName = patternName;
    }

    public String getUsername(){
        return this.username;
    }
    public void setUsername(String username){
        this.username = username;
    }
    public String getPwd(){
        return this.pwd;
    }
    public void setPwd(String pwd){
        this.pwd = pwd;
    }
    public Long getOrgId(){
        return this.orgId;
    }
    public void setOrgId(Long orgId){
        this.orgId = orgId;
    }
    public Integer getAccountState(){
        return this.accountState;
    }
    public void setAccountState(Integer accountState){
        this.accountState = accountState;
    }
    public Integer getPwdState(){
        return this.pwdState;
    }
    public void setPwdState(Integer pwdState){
        this.pwdState = pwdState;
    }
    public Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getModTime(){
        return this.modTime;
    }
    public void setModTime(Date modTime){
        this.modTime = modTime;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}