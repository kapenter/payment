package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.ChannelAccountRouteConfigFeign;
import com.neo.cornerstone.management.message.resp.BaseRespDTO;
import com.neo.cornerstone.message.dto.request.AccountRouteQueryDTO;
import com.neo.cornerstone.message.dto.request.AccountRouteRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRouteConfigRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 16:08
 **/
@Component
@Slf4j
public class ChannelAccountRouteConfigFallbackFactory implements FallbackFactory<ChannelAccountRouteConfigFeign> {

    @Override
    public ChannelAccountRouteConfigFeign create(Throwable throwable) {

        return new  ChannelAccountRouteConfigFeign(){
            @Override
            public PageResponseDTO<ChannelAccountRouteConfigRespDTO> pageChannelAccountsRoute(AccountRouteQueryDTO accountRouteQueryDTO) {
                log.error("调用消息服务---[消息管理]---[短信管理]--[路由配置]异常[pageChannelAccountsRoute]列表异常,msg:{},cause:" ,throwable.getMessage(),throwable);
                PageResponseDTO<ChannelAccountRouteConfigRespDTO> pageResponseDTO=new PageResponseDTO<>();
                pageResponseDTO.setReturnCode(BizCodeEnum.SMS_PAGE_CHANNEL_ACCOUNT_ROUTE_CONFIG_FALLBACK_EXCEPTION.getCode());
                pageResponseDTO.setReturnMsg(BizCodeEnum.SMS_PAGE_CHANNEL_ACCOUNT_ROUTE_CONFIG_FALLBACK_EXCEPTION.getMessage());
                return pageResponseDTO;
            }
            @Override
            public OperationResponseDTO<Boolean> addChannelAccountRoute(AccountRouteRequestDTO accountRouteRequestDTO) {
                log.error("[fallback]---[消息管理]---[邮件管理]---[渠道账户]---[addChannelAccount]新增异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.MAIL_ADD_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION);
            }
            @Override
            public OperationResponseDTO<Boolean> updateChannelAccountRoute(AccountRouteRequestDTO accountRouteRequestDTO) {
                log.error("[fallback]---[消息管理]---[短信管理]---[路由配置]---[updateChannelAccountRoute]修改异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.SMS_UPDATE_CHANNEL_ACCOUNT_ROUTE_CONFIG_FALLBACK_EXCEPTION);
            }
        };
    }
}
