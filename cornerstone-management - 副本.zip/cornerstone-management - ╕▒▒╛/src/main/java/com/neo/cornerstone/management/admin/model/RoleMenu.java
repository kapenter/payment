package com.neo.cornerstone.management.admin.model;

import com.neo.cornerstone.management.base.dto.BaseObject;

/**
 * Title:TRoleMenu<br/>
 * Description:(角色菜单配置实体类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class RoleMenu extends BaseModel {
    private static final long serialVersionUID = -7890179070393693169L;
    /**(角色ID)*/
    private Long roleId;
    /**(菜单ID)*/
    private Long menuId;
    /**(状态1： 有效 0： 无效)*/
    private Integer state;
    /**()*/
    private java.util.Date createTime;
    /**()*/
    private java.util.Date modTime;

    public Long getRoleId(){
        return this.roleId;
    }
    public void setRoleId(Long roleId){
        this.roleId = roleId;
    }
    public Long getMenuId(){
        return this.menuId;
    }
    public void setMenuId(Long menuId){
        this.menuId = menuId;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public java.util.Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(java.util.Date createTime){
        this.createTime = createTime;
    }
    public java.util.Date getModTime(){
        return this.modTime;
    }
    public void setModTime(java.util.Date modTime){
        this.modTime = modTime;
    }


}