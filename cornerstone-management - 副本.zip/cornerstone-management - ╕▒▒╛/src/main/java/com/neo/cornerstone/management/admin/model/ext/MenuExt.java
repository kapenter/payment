package com.neo.cornerstone.management.admin.model.ext;

import com.neo.cornerstone.management.admin.model.Menu;
import com.neo.cornerstone.management.admin.model.Permission;

import java.util.List;

/*******************************************************************************
 * Created on 2019/7/30 17:57
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class MenuExt extends Menu {
    private static final long serialVersionUID = 2463657892022991458L;
    private List<Permission> permissionList;

    public List <Permission> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List <Permission> permissionList) {
        this.permissionList = permissionList;
    }
}
