package com.neo.cornerstone.management.base.util;

import java.util.HashMap;
import java.util.Map;

/*******************************************************************************
 * Created on 2019/8/29 17:04
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class ContentUtil {

    public static final String REMOTE_IP = "remote.ip";

    public static final ThreadLocal<Map<String, Object>> CONTENT = new InheritableThreadLocal<Map<String, Object>>() {
        @Override
        protected Map<String, Object> initialValue() {
            return new HashMap<String, Object>();
        }
    };

    public static Object get(String key) {
        return CONTENT.get().get(key);
    }

    public static Object remove(String key) {
        return CONTENT.get().remove(key);
    }

    public static void put(String key, Object value) {
        if (null == key){
            throw new IllegalArgumentException("Content key is null");
        }
        if (null == value) {
            CONTENT.get().remove(key);
        } else {
            CONTENT.get().put(key, value);
        }
    }
}
