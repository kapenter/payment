package com.neo.cornerstone.management.merchant.controller;

import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.merchant.constants.MerchantUrl;
import com.neo.cornerstone.management.merchant.service.MerchantInfoClient;
import com.neo.cornerstone.management.merchant.util.ResponseTransferUtil;
import com.neo.cornerstone.merchant.serve.define.constants.FeignResponseEnum;
import com.neo.cornerstone.merchant.serve.define.dto.MerchantInfoDTO;
import com.neo.cornerstone.merchant.serve.define.dto.MerchantInfoQueryParam;
import com.neo.cornerstone.merchant.serve.define.dto.PageResponseDTO;
import com.neo.cornerstone.merchant.serve.define.dto.ResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @Description:商户配置
 * @Author: yanyiwei
 * @Date: 2019/08/26
 */
@Controller
public class MerchantInfoController extends BaseController {

    @Autowired
    private MerchantInfoClient merchantInfoClient;

    /**
     * 功能描述:商户配置分页
     * @param: [pageNum, pageSize, name]
     * @return:
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.PAGE_MERCHANT_INFO)
    @ResponseBody
    public PageModel<MerchantInfoDTO> pageMerchantInfo(Integer pageNum, Integer pageSize, String name) {
        MerchantInfoQueryParam pageQueryParam = new MerchantInfoQueryParam(pageNum, pageSize, name);
        PageResponseDTO pageResponseDTO = merchantInfoClient.pageMerchantInfo(pageQueryParam);
        PageModel<MerchantInfoDTO> objectPageModel = new PageModel<>();
        objectPageModel.setTotalRows(pageResponseDTO.getTotalRows());
        objectPageModel.setData(pageResponseDTO.getData());
        return ResponseUtils.buildSuccessPageResponse(objectPageModel);
    }

    /**
     * 功能描述:获取所有商户配置列表
     * @param: []
     * @return:
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.GET_MERCHANT_INFO_LIST)
    @ResponseBody
    public BaseResponse<List<MerchantInfoDTO>> getMerchantInfoList() {
        List<MerchantInfoDTO> merchantInfoList = merchantInfoClient.getMerchantInfoList();
        return ResponseUtils.buildSuccessResponse(merchantInfoList);
    }


    /**
     * 功能描述: 商户配置添加
     * @param: [merchantInfoDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.ADD_MERCHANT_INFO)
    @ResponseBody
    public BaseResponse addMerchantInfo(@RequestBody MerchantInfoDTO merchantInfoDTO) {
        logger.info("[商户配置添加]-入参:{}", merchantInfoDTO);
        ResponseDTO responseDTO = merchantInfoClient.addMerchantInfo(merchantInfoDTO);
        logger.info("[商户配置添加]-结果:{}", responseDTO);
        return ResponseTransferUtil.transferResponse(responseDTO);
    }

    /**
     * 功能描述: 商户配置更新
     * @param: [merchantInfoDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.UPDATE_MERCHANT_INFO)
    @ResponseBody
    public BaseResponse updateMerchantInfo(@RequestBody MerchantInfoDTO merchantInfoDTO) {
        logger.info("[商户配置更新]-入参:{}", merchantInfoDTO);
        ResponseDTO responseDTO = merchantInfoClient.updateMerchantInfo(merchantInfoDTO);
        logger.info("[商户配置更新]-结果:{}", merchantInfoDTO);
        return ResponseTransferUtil.transferResponse(responseDTO);
    }
}
