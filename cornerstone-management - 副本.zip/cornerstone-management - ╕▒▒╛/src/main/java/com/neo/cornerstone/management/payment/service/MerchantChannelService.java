/*******************************************************************************
 * Create on 2019/9/2 17:23
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.service;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.enums.GlobalReturnStatus;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.payment.feign.MerchantChannelFeign;
import com.neo.cornerstone.management.payment.vo.merchant.QueryPageRequestVO;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.merchant.ChannelConfigRowDTO;
import com.neo.payment.dto.admin.merchant.QueryPageRequestDTO;
import com.neo.payment.util.ResponseDTOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Service
public class MerchantChannelService {
    private static Logger logger = LoggerFactory.getLogger(MerchantChannelService.class);

    @Autowired
    private MerchantChannelFeign merchantChannelFeign;

    public PageModel<ChannelConfigRowDTO> queryPage(QueryPageRequestVO requestVO) {
        QueryPageRequestDTO requestDTO = new QueryPageRequestDTO();
        BeanUtils.copyProperties(requestVO, requestDTO);
        PageResponseDTO<ChannelConfigRowDTO> responseDTO = merchantChannelFeign.queryPage(requestDTO);

        if (ResponseDTOUtils.isSuccess(responseDTO)) {
            PageModel<ChannelConfigRowDTO> pageModel = new PageModel<>();
            pageModel.setStatus(GlobalReturnStatus.USCCESS.getStatus());
            pageModel.setReturnCode(GlobalReturnCode.SUCCESS.getCode());
            pageModel.setReturnMsg(GlobalReturnCode.SUCCESS.getMessage());
            pageModel.setData(responseDTO.getData());
            pageModel.setTotalRows(responseDTO.getTotalCount());
            return pageModel;
        } else {
            PageModel<ChannelConfigRowDTO> pageModel = new PageModel<>();
            pageModel.setStatus(GlobalReturnStatus.FAILURE.getStatus());
            pageModel.setReturnCode(GlobalReturnCode.FAILURE.getCode());
            pageModel.setReturnMsg(responseDTO.getErrorMsg());
            pageModel.setData(responseDTO.getData());
            pageModel.setTotalRows(responseDTO.getTotalCount());
            return pageModel;
        }
    }

    public BaseResponse<String> openChannelConfig(Long id) {
        ResponseDTO<String> responseDTO = merchantChannelFeign.openChannelConfig(id);
        if (ResponseDTOUtils.isSuccess(responseDTO)) {
            return ResponseUtils.buildSuccessResponse(responseDTO.getBody());
        } else {
            BaseResponse<String> response = ResponseUtils.buildFailureResponse(null);
            response.setReturnMsg(responseDTO.getErrorMsg());
            return response;
        }
    }

    public BaseResponse<String> closeChannelConfig(Long id) {
        ResponseDTO<String> responseDTO = merchantChannelFeign.closeChannelConfig(id);
        if (ResponseDTOUtils.isSuccess(responseDTO)) {
            return ResponseUtils.buildSuccessResponse(responseDTO.getBody());
        } else {
            BaseResponse<String> response = ResponseUtils.buildFailureResponse(null);
            response.setReturnMsg(responseDTO.getErrorMsg());
            return response;
        }
    }

}
