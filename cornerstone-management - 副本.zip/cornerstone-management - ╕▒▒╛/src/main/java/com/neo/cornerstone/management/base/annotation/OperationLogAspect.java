package com.neo.cornerstone.management.base.annotation;

import com.alibaba.fastjson.JSON;
import com.neo.cornerstone.management.base.enums.OperationResult;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neo.cornerstone.management.base.service.log.SendLogService;

import java.lang.reflect.Method;

/**
 *
 */
@Aspect
@Service
public class OperationLogAspect {

    private static final Logger logger = LoggerFactory.getLogger(OperationLogAspect.class);
    @Autowired
    private SendLogService sendLogService;

    // Service层切点
    @Pointcut("@annotation(com.neo.cornerstone.management.base.annotation.OperationLog)")
    public void serviceAspect() {
    }

    /*
     * @Before("serviceAspect()") public void doBefore(JoinPoint joinPoint) {
     * logger.info(" SERVICE BEFORE LOGGING ............"); }
     */

    /*
     * @After("serviceAspect()") public void doAfter(JoinPoint joinPoint) {
     * logger.info(" SERVICE AFTER LOGGING ............"); }
     */

   /* @AfterReturning(pointcut = "serviceAspect()", returning = "returnValue")
    public void doAfterReturning(JoinPoint joinPoint, Object returnValue) {

    }
*/
    /*@AfterThrowing(pointcut = "serviceAspect()", throwing = "error")
    public void doAfterThrowing(JoinPoint joinPoint, Throwable error) {

    }*/

    @Around("serviceAspect()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
        Method method = ((MethodSignature)joinPoint.getSignature()).getMethod();
        OperationLog logAnnotation = method.getAnnotation(OperationLog.class);

        com.neo.cornerstone.management.base.model.OperationLog operationLog = com.neo.cornerstone.management.base.model.OperationLog
                .init(logAnnotation.operation());
        operationLog.setRemark(logAnnotation.remark());
        operationLog.setOperationResult(OperationResult.SUCCESS.getCode());
        Object result = null;
        try {
            Object[] values = joinPoint.getArgs();
            String[] parameters = ((MethodSignature)joinPoint.getSignature()).getParameterNames();
            String reqParams = "";
            for (int i = 0; i < parameters.length; i++) {
                reqParams = reqParams.concat(parameters[i]).concat(":").concat(JSON.toJSONString(values[i]));
                if (i != parameters.length - 1) {
                    reqParams = reqParams.concat(",");
                }
            }
            operationLog.setOperationParams(reqParams);
            result = joinPoint.proceed();
        } catch (Exception e) {
            operationLog.setError(e.getMessage());
            operationLog.setOperationResult(OperationResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, logAnnotation.encrypt());
        }
        return result;
    }
}
