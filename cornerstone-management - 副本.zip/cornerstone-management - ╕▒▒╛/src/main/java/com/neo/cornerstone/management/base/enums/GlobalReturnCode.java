package com.neo.cornerstone.management.base.enums;

/*******************************************************************************
 * Created on 2019/7/18 18:45
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public enum  GlobalReturnCode {
    SUCCESS("SUCCESS", "成功"),
    FAILURE("FAILURE", "失败"),
    USER_FORBIDDEN("USER_FORBIDDEN", "当前用户冻结状态"),
    LOGIN_FAILURE("LOGIN_FAILURE", "帐号或密码错误"),
    KAPTCHA_ERROR("KAPTCHA_ERROR", "验证码错误"),
    LOGIN_STATUS_OFF("LOGIN_STATUS_OFF", "未登录"),
    UN_AUTHORIZED("UN_AUTHORIZED", "无权限"),
    SYSTEM_ERROR("SYSTEM_ERROR", "系统异常"),
    PARAMS_ERROR("PARAMS_ERROR", "参数错误"),
    ADD_FAILURE("ADD_FAILURE", "添加失败"),
    DELETE_FAILURE("DELETE_FAILURE", "删除失败"),
    UPDATE_FAILURE("UPDATE_FAILURE", "更新失败"),
    TYPE_MISMATCH("TYPE_MISMATCH", "缺少必要参数"),
    ARGUMENT_MISSING("ARG_MISSING", "缺少必要参数"),
    KEY_EXPIRE_TIME_ERROR("KEY_EXPIRE_TIME_ERROR", "秘钥过期时间不能小于当前时间"),
    LOG_ERROR("LOG_ERROR", "操作日志异常"),
    ;

    private String code;

    private String message;

    private GlobalReturnCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public GlobalReturnCode getEnumByCode(String code) {
        for(GlobalReturnCode value : GlobalReturnCode.values()){
            if(value.getCode().equals(code)){
                return value;
            }
        }
        return null;
    }

}
