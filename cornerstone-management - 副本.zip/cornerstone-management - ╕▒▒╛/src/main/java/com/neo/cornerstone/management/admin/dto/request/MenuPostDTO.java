package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/*******************************************************************************
 * Created on 2019/7/26 11:06
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class MenuPostDTO  extends BaseObject {
    private static final long serialVersionUID = 3370274866281517146L;

    @NotNull(message = "父级关联菜单不能为空")
    private Long parentId;
    @NotEmpty(message = "菜单名称不能为空")
    @Length(max = 150, message = "菜单名称长度不符")
    private String name;
    @NotEmpty(message = "菜单URL不能为空")
    @Length(max = 200, message = "菜单URL不符")
    private String url;
    @NotEmpty(message = "路由参数不能为空")
    private String parameter;
    @NotNull(message = "状态不能为空")
    private Integer state;

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }
}
