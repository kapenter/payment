package com.neo.cornerstone.management.base.service;

import com.neo.cornerstone.management.merchant.service.MerchantAppClient;
import com.neo.cornerstone.merchant.serve.define.dto.MerchantAppDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/*******************************************************************************
 * Created on 2019/7/18 13:44
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class BaseService {

    protected final transient Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private MerchantAppClient merchantAppClient;

    /**
     * 功能描述: 获取商户列表
     * @param:
     * @return:
     * @author yanyiwei
     * @date 2019/8/28
     */
    public List<MerchantAppDTO> getMerchantAppList(){
        return merchantAppClient.getMerchantAppList();
    }

    /**
     * 功能描述: 根据merchantId获取商户账户详情
     * @param: merchantId
     * @return:
     * @author yanyiwei
     * @date 2019/8/28
     */
    public MerchantAppDTO getMerchantAppByMerchantId(String merchantId) {
        return merchantAppClient.getMerchantAppByMerchantId(merchantId);
    }

    /**
     * 功能描述: 根据appId获取商户账户详情
     * @param: appId
     * @return:
     * @author yanyiwei
     * @date 2019/8/28
     */
    public MerchantAppDTO getMerchantAppByAppId(String appId) {
        return merchantAppClient.getMerchantAppByAppId(appId);
    }
}
