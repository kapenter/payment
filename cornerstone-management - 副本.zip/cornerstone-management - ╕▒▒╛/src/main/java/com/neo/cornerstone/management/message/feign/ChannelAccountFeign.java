package com.neo.cornerstone.management.message.feign;

import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.feign.FallbackFactory.ChannelAccountFallbackFactory;
import com.neo.cornerstone.message.dto.request.ChannelAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.ChannelAccountRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-28 13:54
 **/
@FeignClient(value = "springcloud-5101-message",fallbackFactory = ChannelAccountFallbackFactory.class)
public interface ChannelAccountFeign {

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_LIST,method = RequestMethod.POST)
    PageResponseDTO<ChannelAccountRespDTO> pageChannelAccounts(@RequestBody ChannelAccountQueryDTO channelAccountQueryDTO);

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_ADD,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> addChannelAccount(@RequestBody ChannelAccountRequestDTO channelAccountRequestDTO);

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_UPDATE,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> updateChannelAccount(ChannelAccountRequestDTO channelAccountRequestDTO);
}
