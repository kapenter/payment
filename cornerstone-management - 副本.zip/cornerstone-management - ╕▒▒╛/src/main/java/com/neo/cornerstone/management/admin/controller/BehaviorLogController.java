package com.neo.cornerstone.management.admin.controller;

import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.model.BehaviorLog;
import com.neo.cornerstone.management.base.service.log.BehaviorLogService;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/*******************************************************************************
 * Created on 2019/9/16 15:20
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@RestController
public class BehaviorLogController extends BaseController {

    @Autowired
    private BehaviorLogService behaviorLogService;

    @RequestMapping(value = Url.QUERY_BEHAVIOR_LOG, method = RequestMethod.GET)
    public PageModel <BehaviorLog> queryUser(Integer pageNum, Integer pageSize, String bizId, String username) {
        pageNum = pageNum == null || pageNum < 0 ? 0 : pageNum;
        pageSize = pageSize == null || pageSize < 0 ? 10 : pageSize;

        PageModel<BehaviorLog> page = behaviorLogService.queryPage(pageNum, pageSize, bizId, username);
        return ResponseUtils.buildSuccessPageResponse(page);
    }
}
