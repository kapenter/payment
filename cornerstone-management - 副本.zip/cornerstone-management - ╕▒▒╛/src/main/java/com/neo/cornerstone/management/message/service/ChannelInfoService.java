package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.message.feign.ChannelInfoFeign;
import com.neo.cornerstone.message.dto.request.ChannelInfoQueryDTO;
import com.neo.cornerstone.message.dto.request.ChannelInfoRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelInfoRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-26 15:54
 **/
@Service
public class ChannelInfoService {


    @Autowired
    private ChannelInfoFeign channelInfoFeign;

    public PageResponseDTO<ChannelInfoRespDTO> pageChannelInfos(ChannelInfoQueryDTO channelInfoQueryDTO) {
      return  channelInfoFeign.pageChannelInfos(channelInfoQueryDTO);
    }

    public List<ChannelInfoRespDTO> allChannelInfos() {
        return  channelInfoFeign.allChannelInfos();
    }

    public OperationResponseDTO<Boolean> addChannelInfo(ChannelInfoRequestDTO channelInfoRequestDTO) {
        return  channelInfoFeign.addChannelInfo(channelInfoRequestDTO);
    }

    public OperationResponseDTO<Boolean> updateChannelInfo(ChannelInfoRequestDTO channelInfoRequestDTO) {
        return  channelInfoFeign.updateChannelInfo(channelInfoRequestDTO);
    }
}
