/*******************************************************************************
 * Created on 2018-02-24 17:27:32
 * Copyright (c) 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.message.consts;

/**
 * @author xn081877
 * @ClassName: ReturnCodeEnum
 * @Description:
 * @date 2019/6/18 19:15
 */
public enum ReturnCodeEnum {
    SUCCESS("000000","成功"),
    SYSTEM_ERROR("000001","系统异常"),
    FAIL("000002","失败"),
    INVALID_PARAM("010001","参数错误"),
    SIGN_FAIL("010002","签名错误")
    ;

    private String code;
    private String message;
    ReturnCodeEnum(String code, String message){
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }


}
