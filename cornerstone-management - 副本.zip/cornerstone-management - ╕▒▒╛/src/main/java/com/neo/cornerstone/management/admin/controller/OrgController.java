package com.neo.cornerstone.management.admin.controller;

import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.admin.dto.request.MenuPostDTO;
import com.neo.cornerstone.management.admin.dto.request.MenuUpdateDTO;
import com.neo.cornerstone.management.admin.dto.request.OrgPostDTO;
import com.neo.cornerstone.management.admin.dto.request.OrgUpdateDTO;
import com.neo.cornerstone.management.admin.dto.response.MenuInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.OrgInfoDTO;
import com.neo.cornerstone.management.admin.service.biz.MenuBizService;
import com.neo.cornerstone.management.admin.service.biz.OrgBizService;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.service.log.SendLogService;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/*******************************************************************************
 * Created on 2019/7/25 16:03
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@RestController
public class OrgController extends BaseController {

    @Autowired
    private OrgBizService orgBizService;


    /**
     * 查询所有组织部门用于展示
     * @return
     */
    @RequestMapping(value = Url.QUERY_ALL_ORG, method = RequestMethod.GET)
    public BaseResponse<List<OrgInfoDTO>> queryAllOrg() {
        List<OrgInfoDTO> orgData = orgBizService.queryAllOrg();
        return ResponseUtils.buildSuccessResponse(orgData);
    }

    /**
     * 添加部门与组织
     * @param orgPostDTO
     * @return
     */
    @RequestMapping(value = Url.ADD_SUB_ORG, method = RequestMethod.POST)
    public BaseResponse<Long> addSubOrg(@RequestBody @Valid OrgPostDTO orgPostDTO) {
        Long id = orgBizService.addSubOrg(orgPostDTO);
        if (id != null) {
            return ResponseUtils.buildSuccessResponse(id);
        } else {
            return ResponseUtils.buildFailureResponse(null);
        }
    }

    /**
     * 删除组织
     * @param id
     * @return
     */
    @RequestMapping(value = Url.DELETE_ORG, method = RequestMethod.POST)
    public BaseResponse<Boolean> deleteOrg(@PathVariable("id") Long id) {
        orgBizService.deleteOrg(id);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 更新组织与部门
     * @param id
     * @param orgUpdateDTO
     * @return
     */
    @RequestMapping(value = Url.UPDATE_ORG, method = RequestMethod.POST)
    public BaseResponse<Boolean> updateOrg(@PathVariable("id") Long id, @RequestBody @Valid OrgUpdateDTO orgUpdateDTO) {
        Boolean result = orgBizService.updateOrg(id, orgUpdateDTO);
        if (result) {
            return ResponseUtils.buildSuccessResponse(true);
        } else {
            return ResponseUtils.buildFailureResponse(false, GlobalReturnCode.UPDATE_FAILURE.getCode(), GlobalReturnCode.UPDATE_FAILURE.getMessage());
        }
    }
}
