/*******************************************************************************
 * Create on 2019/9/2 17:45
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.controller;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.payment.constant.URL;
import com.neo.cornerstone.management.payment.service.MerchantChannelService;
import com.neo.cornerstone.management.payment.vo.merchant.QueryPageRequestVO;
import com.neo.payment.dto.admin.merchant.ChannelConfigRowDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@RestController
public class MerchantChannelController {
    @Autowired
    private MerchantChannelService merchantChannelService;

    @RequestMapping(path = URL.QUERY_MERCHANT_CHANNEL_CONFIG_PAGE_LIST)
    public PageModel<ChannelConfigRowDTO> queryPage(@RequestBody QueryPageRequestVO requestVO) {
        return merchantChannelService.queryPage(requestVO);
    }

    @RequestMapping(path = URL.OPEN_MERCHANT_CHANNEL_CONFIG)
    public BaseResponse<String> openChannelConfig(@RequestParam Long id) {
        return merchantChannelService.openChannelConfig(id);
    }

    @RequestMapping(path = URL.CLOSE_MERCHANT_CHANNEL_CONFIG)
    public BaseResponse<String> closeChannelConfig(@RequestParam Long id) {
        return merchantChannelService.closeChannelConfig(id);
    }

}
