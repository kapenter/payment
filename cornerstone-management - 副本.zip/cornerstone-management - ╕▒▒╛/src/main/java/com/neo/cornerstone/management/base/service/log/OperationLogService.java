package com.neo.cornerstone.management.base.service.log;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.plugins.Page;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.msplatform.framework.mongodb.MongoService;

/*******************************************************************************
 * Created on 2019/8/26 18:26
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Service("operationLogService")
public class OperationLogService extends BaseService {

    @Autowired
    private MongoService mongoService;

    public void saveOperationLog(OperationLog operationLog) {
        mongoService.insert(operationLog);
    }

    /**
     *
     * @param pageNum
     * @param pageSize
     * @param bizId
     * @param username
     * @param moduleType
     * @param subModuleType
     * @return
     */
    public PageModel<OperationLog> queryPage(Integer pageNum, Integer pageSize, String bizId, String username,
            String moduleType, String subModuleType) {
        OperationLog params = new OperationLog();
        params.setUsername(username);
        params.setBizId(bizId);
        params.setModuleType(moduleType);
        params.setSubModuleType(subModuleType);
        Sort sort = new Sort(Sort.Direction.DESC, "createTime");
        Page<OperationLog> pageData = mongoService.selectPage(pageNum, pageSize, params, sort, OperationLog.class);
        PageModel<OperationLog> pageModel = new PageModel<>();
        if (pageData != null && CollectionUtils.isNotEmpty(pageData.getRecords())) {
            for (OperationLog operationLog : pageData.getRecords()) {
                operationLog.setOriginalSnapshot(null);
                operationLog.setSnapshot(null);
            }
            pageModel.setTotalRows(pageData.getTotal());
            pageModel.setData(pageData.getRecords());
        }
        return pageModel;
    }
}
