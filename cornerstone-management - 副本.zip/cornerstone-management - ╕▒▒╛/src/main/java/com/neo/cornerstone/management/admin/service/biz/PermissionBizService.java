package com.neo.cornerstone.management.admin.service.biz;

import com.alibaba.fastjson.JSON;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.admin.dto.request.PermissionPostDTO;
import com.neo.cornerstone.management.admin.dto.request.PermissionUpdateDTO;
import com.neo.cornerstone.management.admin.dto.response.MenuInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.PermissionInfoDTO;
import com.neo.cornerstone.management.admin.enums.AdminReturnCode;
import com.neo.cornerstone.management.admin.enums.StateEnum;
import com.neo.cornerstone.management.admin.model.Permission;
import com.neo.cornerstone.management.admin.model.RolePermission;
import com.neo.cornerstone.management.admin.model.ext.PermissionExt;
import com.neo.cornerstone.management.admin.model.params.PermissionParams;
import com.neo.cornerstone.management.admin.model.params.RolePermissionParams;
import com.neo.cornerstone.management.admin.service.common.PermissionService;
import com.neo.cornerstone.management.admin.service.common.RolePermissionService;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.BehaviorResult;
import com.neo.cornerstone.management.base.exception.BizRuntimeException;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.cornerstone.management.base.service.log.SendLogService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*******************************************************************************
 * Created on 2019/7/18 18:38
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 *****************************************************************************
 * @author xn082184*/
@Service("permissionBizService")
public class PermissionBizService extends BaseService {

    @Autowired
    private PermissionService permissionService;
    @Autowired
    private RolePermissionService rolePermissionService;
    @Autowired
    private MenuBizService menuBizService;
    @Autowired
    private SendLogService sendLogService;

    public List <MenuInfoDTO> queryMenu() {
        return menuBizService.queryAllMenuData();
    }

    /**
     * 更新权限
     * @param id
     * @param permissionUpdateDTO
     * @return
     */
    public Boolean updatePermission(Long id, PermissionUpdateDTO permissionUpdateDTO) {
        Permission permission = null;
        Permission updatePermission = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_PERMS_UPDATE).setOperationParams(id + JSON.toJSONString(permissionUpdateDTO));;
        try {
            permission = permissionService.queryById(id);
            if (permission == null) {
                throw new BizRuntimeException(AdminReturnCode.PERMISSION_NOT_EXISTS.getCode(), AdminReturnCode.PERMISSION_NOT_EXISTS.getMessage());
            }

            updatePermission = new Permission();
            updatePermission.setId(id);
            updatePermission.setType(permissionUpdateDTO.getType());
            updatePermission.setName(permissionUpdateDTO.getName());
            updatePermission.setPermission(permissionUpdateDTO.getPermission());
            updatePermission.setMenuId(permissionUpdateDTO.getMenuId());
            updatePermission.setModTime(new Date());
            updatePermission.setState(permissionUpdateDTO.getState().equals(StateEnum.VALID.getCode()) ? StateEnum.VALID.getCode(): StateEnum.INVALID.getCode());
            boolean result = permissionService.updateById(updatePermission);

            operationLog.setRemark(permission.getName())
                    .setSnapshot(JSON.toJSONString(updatePermission))
                    .setOriginalSnapshot(JSON.toJSONString(permission))
                    .setOperationResult(result ? BehaviorResult.SUCCESS.getCode() : BehaviorResult.FAILURE.getCode());
            return result;
        } catch (Exception e) {
            operationLog.setRemark(permission == null ? "" : permission.getName())
                    .setSnapshot(JSON.toJSONString(updatePermission))
                    .setOriginalSnapshot(JSON.toJSONString(permission))
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }

    /**
     * 删除权限
     * @param id
     * @return
     */
    public boolean deletePermission(Long id) {
        Permission permission = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_PERMS_DELETE).setOperationParams(id + "");
        try {
            permission = permissionService.queryById(id);
            if (permission == null) {
                throw new BizRuntimeException(AdminReturnCode.PERMISSION_NOT_EXISTS.getCode(), AdminReturnCode.PERMISSION_NOT_EXISTS.getMessage());
            }
            deletePermissionData(id);

            operationLog.setOriginalSnapshot(JSON.toJSONString(permission))
                    .setRemark(permission.getName())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
            return true;
        } catch (Exception e) {
            operationLog.setOriginalSnapshot(JSON.toJSONString(permission))
                    .setRemark(permission != null ? permission.getName() : null)
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }

    /**
     * 删除权限关联信息
     * @param id
     */
    private void deletePermissionData(Long id) {
        permissionService.deleteById(id);
        // role permission

        RolePermissionParams params = new RolePermissionParams();
        params.setPermissionId(id);
        //rolePermissionService.deleteByCondition(params);
        List <RolePermission> rolePermissionList = rolePermissionService.queryListByCondition(params);
        if (CollectionUtils.isNotEmpty(rolePermissionList)) {
            throw new BizRuntimeException(AdminReturnCode.PERMS_REF_ROLE.getCode(), AdminReturnCode.PERMS_REF_ROLE.getMessage());
        }
    }

    /**
     * 查询权限分页列表信息
     * @param pageNum
     * @param pageSize
     * @param name
     * @return
     */
    public PageModel<PermissionInfoDTO> queryPermission(Integer pageNum, Integer pageSize, String name, Long menuId) {
        PermissionParams request = new PermissionParams();
//        request.setName(name);
        request.setPatternName(name);
        request.setPageSize(pageSize);
        request.setPageNum(pageNum);
        request.setMenuId(menuId);
        PageModel<PermissionExt> permissionPage = permissionService.queryPageExt(request);

        PageModel<PermissionInfoDTO> responsePageData = new PageModel<>();
        responsePageData.setTotalRows(0);
        if (permissionPage != null && CollectionUtils.isNotEmpty(permissionPage.getData())) {
            responsePageData.setTotalRows(permissionPage.getTotalRows());
            List<PermissionInfoDTO> responseDataList = new ArrayList<>();
            for (PermissionExt permissionExt: permissionPage.getData()) {
                PermissionInfoDTO infoDTO = new PermissionInfoDTO();
                infoDTO.setType(permissionExt.getType());
                infoDTO.setState(permissionExt.getState());
                infoDTO.setPermission(permissionExt.getPermission());
                infoDTO.setName(permissionExt.getName());
                infoDTO.setMenuId(permissionExt.getMenuId());
                infoDTO.setId(permissionExt.getId());
                infoDTO.setMenuName(permissionExt.getMenuName());
                infoDTO.setCreateTime(permissionExt.getCreateTime());
                infoDTO.setModTime(permissionExt.getModTime());
                responseDataList.add(infoDTO);
            }
            responsePageData.setData(responseDataList);
        }
        return responsePageData;
    }

    /**
     * 添加
     * @param permissionPostDTO
     * @return
     */
    public Boolean addPermission(PermissionPostDTO permissionPostDTO) {
        Permission permission = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_PERMS_ADD).setOperationParams(JSON.toJSONString(permissionPostDTO));
        try {
            PermissionParams permissionParams = new PermissionParams();
            permissionParams.setName(permissionPostDTO.getName());
            List<Permission> permissionList = permissionService.queryListByCondition(permissionParams);
            if (CollectionUtils.isNotEmpty(permissionList)) {
                throw new BizRuntimeException(AdminReturnCode.PERMISSION_NAME_EXISTS.getCode(), AdminReturnCode.PERMISSION_NAME_EXISTS.getMessage());
            }
            permissionParams.setName(null);
            permissionParams.setPermission(permissionPostDTO.getPermission());
            permissionList = permissionService.queryListByCondition(permissionParams);
            if (CollectionUtils.isNotEmpty(permissionList)) {
                throw new BizRuntimeException(AdminReturnCode.PERMISSION_EXISTS.getCode(), AdminReturnCode.PERMISSION_EXISTS.getMessage());
            }

            permission = new Permission();
            permission.setName(permissionPostDTO.getName());
            permission.setCreateTime(new Date());
            permission.setMenuId(permissionPostDTO.getMenuId());
            permission.setPermission(permissionPostDTO.getPermission());
            permission.setState(StateEnum.VALID.getCode().equals(permissionPostDTO.getState())?StateEnum.VALID.getCode():StateEnum.INVALID.getCode());
            permission.setType(permissionPostDTO.getType());
            permissionService.saveModel(permission);

            operationLog.setSnapshot(JSON.toJSONString(permission))
                    .setRemark(permission.getName())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
            return true;
        } catch (Exception e) {
            operationLog.setSnapshot(JSON.toJSONString(permission))
                    .setRemark(permissionPostDTO.getName())
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }
}
