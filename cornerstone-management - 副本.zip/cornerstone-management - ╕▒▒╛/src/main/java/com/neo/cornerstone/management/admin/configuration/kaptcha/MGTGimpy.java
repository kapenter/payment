package com.neo.cornerstone.management.admin.configuration.kaptcha;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;

import com.google.code.kaptcha.GimpyEngine;
import com.google.code.kaptcha.NoiseProducer;
import com.google.code.kaptcha.util.Configurable;
import com.jhlabs.image.RippleFilter;
import com.jhlabs.image.ShadowFilter;

/**
 * <p>Title:</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2018</p>
 *
 * @author Luo Shun
 */
public class MGTGimpy extends Configurable implements GimpyEngine {

    public MGTGimpy() {
    }

    @Override
    public BufferedImage getDistortedImage(BufferedImage bufferedImage) {
        NoiseProducer noiseProducer = this.getConfig().getNoiseImpl();
        BufferedImage distortedImage = new BufferedImage(bufferedImage.getWidth(), bufferedImage.getHeight(), 2);
        Graphics2D graph = (Graphics2D) distortedImage.getGraphics();
        ShadowFilter shadowFilter = new ShadowFilter();
        shadowFilter.setRadius(0.8F);
        shadowFilter.setDistance(0.8F);
        shadowFilter.setOpacity(0.9F);
        RippleFilter rippleFilter = new RippleFilter();
        rippleFilter.setWaveType(0);
        rippleFilter.setXAmplitude(5.5F);
        rippleFilter.setYAmplitude(1.5F);
        rippleFilter.setXWavelength(17.5F);
        rippleFilter.setYWavelength(4.5F);
        rippleFilter.setEdgeAction(1);
        BufferedImage effectImage = rippleFilter.filter(bufferedImage, (BufferedImage) null);
        effectImage = shadowFilter.filter(effectImage, (BufferedImage) null);
        graph.drawImage(effectImage, 0, 0, (Color) null, (ImageObserver) null);
        graph.dispose();
        noiseProducer.makeNoise(distortedImage, 0.1F, 0.3F, 0.5F, 0.7F);
        return distortedImage;
    }
}
