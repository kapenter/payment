package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.cornerstone.management.message.feign.MerchantAppAccountFeign;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountRequestDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountUpdateDTO;
import com.neo.cornerstone.message.dto.response.MerchantAppAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-22 15:26
 **/
@Service
public class MerchantAppAccountService  extends BaseService{


    @Autowired
    private MerchantAppAccountFeign merchantAppAccountFeign;

    public PageResponseDTO<MerchantAppAccountRespDTO> pageMerchantAppAccount(MerchantAppAccountQueryDTO merchantAppAccountQueryDTO){
        return  merchantAppAccountFeign.pageMerchantAppAccount(merchantAppAccountQueryDTO);
    }


    public List<MerchantAppAccountRespDTO> allMerchantAppAccount(){
        return  merchantAppAccountFeign.allMerchantAppAccount();
    }


    public OperationResponseDTO<Boolean> addMerchantAppAccount(MerchantAppAccountRequestDTO merchantAppAccountRequestDTO){
        return  merchantAppAccountFeign.createAppAccount(merchantAppAccountRequestDTO);
    }

    public OperationResponseDTO<Boolean> updateMerchantAppAccount(MerchantAppAccountUpdateDTO merchantAppAccountUpdateDTO) {
        return  merchantAppAccountFeign.updateAppAccount(merchantAppAccountUpdateDTO);
    }
}
