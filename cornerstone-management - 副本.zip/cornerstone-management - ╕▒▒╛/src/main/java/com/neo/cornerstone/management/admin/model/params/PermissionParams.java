package com.neo.cornerstone.management.admin.model.params;

import java.util.Date;

/**
 * Title:TPermission<br/>
 * Description:(权限mapper参数对象)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class PermissionParams extends BaseParams {
    private static final long serialVersionUID = 40907220223476282L;
    /**(类型)*/
    private Integer type;
    /**(名称)*/
    private String name;
    private String patternName;
    /**(权限)*/
    private String permission;
    /**(关联菜单)*/
    private Long menuId;
    private Integer state;
    /**()*/
    private Date createTime;
    /**()*/
    private Date modTime;

    public String getPatternName() {
        return patternName;
    }

    public void setPatternName(String patternName) {
        this.patternName = patternName;
    }

    public Integer getType(){
        return this.type;
    }
    public void setType(Integer type){
        this.type = type;
    }
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getPermission(){
        return this.permission;
    }
    public void setPermission(String permission){
        this.permission = permission;
    }
    public Long getMenuId(){
        return this.menuId;
    }
    public void setMenuId(Long menuId){
        this.menuId = menuId;
    }
    public Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getModTime(){
        return this.modTime;
    }
    public void setModTime(Date modTime){
        this.modTime = modTime;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}