package com.neo.cornerstone.management.payment.feign;

import com.neo.cornerstone.management.payment.fallback.BestPaymentRecordFallback;
import com.neo.payment.constant.AdminURL;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.best.BestPaymentRowDTO;
import com.neo.payment.dto.admin.best.QueryBestPageRequestDTO;
import com.neo.payment.dto.admin.best.QuotaPaymentRowDTO;
import com.neo.payment.dto.admin.best.SetBestFailRequestDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * 限额拆单记录
 */
@FeignClient(value = "springcloud-5102-payment", fallback = BestPaymentRecordFallback.class)
public interface BestPaymentRecordFeign {

    @RequestMapping(value = AdminURL.QUERY_BEST_PAYMENT_RECORD_PAGE_LIST, method = RequestMethod.POST)
    PageResponseDTO<BestPaymentRowDTO> queryBestPage(@RequestBody QueryBestPageRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.SYNC_BEST_PAYMENT_RECORD_RESULT, method = RequestMethod.POST)
    ResponseDTO<String> syncBestResult(@RequestBody String platformOrder);

    @RequestMapping(value = AdminURL.SET_BEST_PAYMENT_RECORD_FAIL, method = RequestMethod.POST)
    ResponseDTO<String> setBestFail(@RequestBody SetBestFailRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.QUERY_BEST_QUOTA_PAYMENT_RECORD_LIST, method = RequestMethod.POST)
    ResponseDTO<List<QuotaPaymentRowDTO>> queryQuotaList(@RequestBody String tradeOrder);

}
