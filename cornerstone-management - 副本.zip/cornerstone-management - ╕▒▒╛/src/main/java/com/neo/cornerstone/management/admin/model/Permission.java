package com.neo.cornerstone.management.admin.model;

/**
 * Title:TPermission<br/>
 * Description:(权限实体类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class Permission extends BaseModel {
    private static final long serialVersionUID = 8746787491921740190L;
    /**(类型)*/
    private Integer type;
    /**(名称)*/
    private String name;
    /**(权限)*/
    private String permission;
    /**(关联菜单)*/
    private Long menuId;
    private Integer state;
    /**()*/
    private java.util.Date createTime;
    /**()*/
    private java.util.Date modTime;

    public Integer getType(){
        return this.type;
    }
    public void setType(Integer type){
        this.type = type;
    }
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getPermission(){
        return this.permission;
    }
    public void setPermission(String permission){
        this.permission = permission;
    }
    public Long getMenuId(){
        return this.menuId;
    }
    public void setMenuId(Long menuId){
        this.menuId = menuId;
    }
    public java.util.Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(java.util.Date createTime){
        this.createTime = createTime;
    }
    public java.util.Date getModTime(){
        return this.modTime;
    }
    public void setModTime(java.util.Date modTime){
        this.modTime = modTime;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

}