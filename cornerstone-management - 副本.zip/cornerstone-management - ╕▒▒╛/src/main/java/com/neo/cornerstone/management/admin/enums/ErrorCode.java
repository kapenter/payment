package com.neo.cornerstone.management.admin.enums;

/**
  * @ClassName ErrorCode
  * @Description ErrorCode
  * @Author xn024222
  * @Since 2019/1/2 18:57
  * @Version 1.0
  */
public enum ErrorCode {

    PARAMS_ERROR("PARAMS_ERROR", "参数异常"),
    PWD_NOT_EQUAL("PWD_NOT_EQUAL", "密码不一致"),
    KAPTCHA_ERROR("KAPTCHA_ERROR", "验证码错误")
    ;

    private String code;

    private String message;

    private ErrorCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public ErrorCode getEnumByCode(String code) {
        for(ErrorCode value : ErrorCode.values()){
            if(value.getCode().equals(code)){
                return value;
            }
        }
        return null;
    }


}
