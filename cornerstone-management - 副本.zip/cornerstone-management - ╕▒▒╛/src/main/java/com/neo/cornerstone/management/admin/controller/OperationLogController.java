package com.neo.cornerstone.management.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.log.OperationLogService;
import com.neo.cornerstone.management.base.util.ResponseUtils;

/*******************************************************************************
 * Created on 2019/9/5 10:24
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@RestController
public class OperationLogController extends BaseController {

    @Autowired
    private OperationLogService operationLogService;

    /**
     *
     * @param pageNum
     * @param pageSize
     * @param bizId
     * @param username
     * @param moduleType
     * @param subModuleType
     * @return
     */
    @RequestMapping(value = Url.QUERY_OPERATION_LOG, method = RequestMethod.GET)
    public PageModel<OperationLog> queryUser(Integer pageNum, Integer pageSize, String bizId, String username,
            String moduleType, String subModuleType) {
        pageNum = pageNum == null || pageNum < 0 ? 0 : pageNum;
        pageSize = pageSize == null || pageSize < 0 ? 10 : pageSize;

        PageModel<OperationLog> page = operationLogService.queryPage(pageNum, pageSize, bizId, username, moduleType, subModuleType);
        return ResponseUtils.buildSuccessPageResponse(page);
    }
}
