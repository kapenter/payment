package com.neo.cornerstone.management.message.feign;

import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.feign.FallbackFactory.MailSendRecordFallbackFactory;
import com.neo.cornerstone.message.dto.request.MailSendRecordQueryDTO;
import com.neo.cornerstone.message.dto.response.MailSendRecordRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-03 17:14
 **/
@FeignClient(value = "springcloud-5101-message",fallbackFactory = MailSendRecordFallbackFactory.class)
public interface MailSendRecordFeign {

    @RequestMapping(value = MessageURL.MESSAGE_MAIL_SEND_LOG_LIST,method = RequestMethod.POST)
    PageResponseDTO<MailSendRecordRespDTO> pageMailSendRecords(@RequestBody MailSendRecordQueryDTO mailSendRecordQueryDTO) ;
}
