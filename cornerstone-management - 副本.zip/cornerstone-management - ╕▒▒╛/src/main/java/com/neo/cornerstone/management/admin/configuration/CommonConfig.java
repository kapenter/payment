package com.neo.cornerstone.management.admin.configuration;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;

/*******************************************************************************
 * Created on 2019/9/18 11:44
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Configuration
public class CommonConfig {

    @Bean
    public FilterRegistrationBean filterRegistrationBean(){
        FilterRegistrationBean bean = new FilterRegistrationBean();
        bean.setFilter(contentFilter());
        bean.addUrlPatterns("/*");
        return bean;
    }

    @Bean
    public Filter contentFilter() {
        return new MGTContentFilter();
    }
}
