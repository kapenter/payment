package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.MailRouteConfigFeign;
import com.neo.cornerstone.management.message.resp.BaseRespDTO;
import com.neo.cornerstone.message.dto.request.MailAccountRouteConfigQueryDTO;
import com.neo.cornerstone.message.dto.request.MailRouteConfigRequestDTO;
import com.neo.cornerstone.message.dto.response.MailRouteConfigRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 16:08
 **/
@Component
@Slf4j
public class MailRouteConfigFallbackFactory implements FallbackFactory<MailRouteConfigFeign> {



    @Override
    public MailRouteConfigFeign create(Throwable throwable) {

        return new MailRouteConfigFeign() {
            @Override
            public PageResponseDTO<MailRouteConfigRespDTO> pageMailAccountRouteConfig(MailAccountRouteConfigQueryDTO mailAccountRouteConfigQueryDTO) {
                log.error("[fallback]---[消息管理]---[路由管理]---[路由配置]---[pageMailAccountRouteConfig]列表异常,msg:{},cause:",throwable.getMessage(),throwable);
                PageResponseDTO<MailRouteConfigRespDTO> pageResponseDTO=new PageResponseDTO<>();
                pageResponseDTO.setReturnCode(BizCodeEnum.MAIL_PAGE_ROUTE_CONFIG_FALLBACK_EXCEPTION.getCode());
                pageResponseDTO.setReturnMsg(BizCodeEnum.MAIL_PAGE_ROUTE_CONFIG_FALLBACK_EXCEPTION.getMessage());
                return pageResponseDTO;
            }

            @Override
            public OperationResponseDTO<Boolean> addMailAccountRouteConfig(MailRouteConfigRequestDTO mailRouteConfigRequestDTO) {
                log.error("[fallback]---[消息管理]---[路由管理]---[路由配置]---[addMailAccountRouteConfig]新增异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.MAIL_ADD_ROUTE_CONFIG_FALLBACK_EXCEPTION);
            }

            @Override
            public OperationResponseDTO<Boolean> updateMailAccountRouteConfig(MailRouteConfigRequestDTO mailRouteConfigRequestDTO) {
                log.error("[fallback]---[消息管理]---[路由管理]---[路由配置]---[updateMailAccountRouteConfig]修改异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.MAIL_UPDATE_ROUTE_CONFIG_FALLBACK_EXCEPTION);
            }
        };
    }
}
