package com.neo.cornerstone.management.payment.feign;

import com.neo.cornerstone.management.payment.fallback.PaymentRecordFallback;
import com.neo.payment.constant.AdminURL;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.payment.PaymentRowDTO;
import com.neo.payment.dto.admin.payment.QueryPageRequestDTO;
import com.neo.payment.dto.admin.payment.SetFailRequestDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 支付记录
 */
@FeignClient(value = "springcloud-5102-payment", fallback = PaymentRecordFallback.class)
public interface PaymentRecordFeign {

    @RequestMapping(value = AdminURL.QUERY_PAYMENT_RECORD_PAGE_LIST, method = RequestMethod.POST)
    PageResponseDTO<PaymentRowDTO> queryPage(@RequestBody QueryPageRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.SYNC_PAYMENT_RECORD_RESULT, method = RequestMethod.POST)
    ResponseDTO<String> syncResult(@RequestBody String platformOrder);

    @RequestMapping(value = AdminURL.SET_PAYMENT_RECORD_FAIL, method = RequestMethod.POST)
    ResponseDTO<String> setFail(@RequestBody SetFailRequestDTO requestDTO);

}
