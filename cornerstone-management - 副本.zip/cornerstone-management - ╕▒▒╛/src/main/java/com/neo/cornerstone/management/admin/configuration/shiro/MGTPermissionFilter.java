package com.neo.cornerstone.management.admin.configuration.shiro;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.StringUtils;
import org.apache.shiro.web.filter.authz.PermissionsAuthorizationFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neo.cornerstone.management.admin.enums.PermissionTypeEnum;
import org.springframework.web.util.UrlPathHelper;

/*******************************************************************************
 * Created on 2019/8/13 16:58
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class MGTPermissionFilter extends PermissionsAuthorizationFilter {

    public static Logger logger = LoggerFactory.getLogger(MGTPermissionFilter.class);

    // 权限验证  未登录
    private String unLoginUrl;

    /**
     * 参考 http://shiro.apache.org/java-authorization-guide.html
     * 统一处理，代替编程是权限 触发权限接触
     * @param request
     * @param response
     * @param mappedValue
     * @return
     * @throws IOException
     */
    @Override
    public boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue)
            throws IOException {
        Subject subject = this.getSubject(request, response);

        String requestPath = this.getPathWithinApplication(request);
        String requestURI = PermissionTypeEnum.URL.getPermissionType().concat(requestPath);
        UrlPathHelper urlPathHelper = new UrlPathHelper();
        /**
         * 因为没有采用编程式方式，所以mappedValue（待检查权限）为空。
         * 统一处理。
         */
        mappedValue = new String[] { requestURI };
        boolean isPermitted = super.isAccessAllowed(request, response, mappedValue);
        logger.info("用户[{}] - 访问资源[{}] - 权限[{}] - 验证结果[{}]", subject.getPrincipal(), requestPath, mappedValue,
                isPermitted);
        return isPermitted;
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws IOException {
        Subject subject = getSubject(request, response);
        // If the subject isn't identified, redirect to login URL
        if (subject.getPrincipal() == null) {
            saveRequestAndRedirectToLogin(request, response);
        } else {
            String unauthorizedUrl = getUnauthorizedUrl();
            if (StringUtils.hasText(unauthorizedUrl)) {
                try {
                    request.getRequestDispatcher(unauthorizedUrl).forward(request, response);
                } catch (ServletException e) {
                    logger.error(" permission denied , redirect unauthorizedUrl with error ");
                }
            } else {
                throw new RuntimeException(" permission access denied but found no url for unauthorized");
            }
        }
        return false;
    }

    @Override
    protected void redirectToLogin(ServletRequest request, ServletResponse response) throws IOException {
        logger.info("权限验证 - 请求 [{}] - 当前未登录", ((HttpServletRequest) request).getRequestURL());
        String unLoginUrl = getUnLoginUrl();
        try {
            request.getRequestDispatcher(unLoginUrl).forward(request, response);
        } catch (ServletException e) {
            logger.error("权限验证 - 请求 [{}] - 当前未登录 - 跳转 [{}] - 异常", ((HttpServletRequest) request).getRequestURL(), unLoginUrl, e);
            throw  new RuntimeException("权限验证 - 请求 [" + ((HttpServletRequest) request).getRequestURL()+ "] - 当前未登录 - 跳转 [" + unLoginUrl + "] - 异常");
        }
    }

    public String getUnLoginUrl() {
        return unLoginUrl;
    }

    public void setUnLoginUrl(String unLoginUrl) {
        this.unLoginUrl = unLoginUrl;
    }
}
