package com.neo.cornerstone.management.admin.service.common;

import com.neo.cornerstone.management.admin.mapper.RoleMenuMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.RoleMenu;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.RoleMenuParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Title:TRoleMenuServiceImpl<br/>
 * Description:(角色菜单配置SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("roleMenuService")
public class RoleMenuService extends MysqlBaseServiceImpl <RoleMenu> {


    @Autowired
    private RoleMenuMapper roleMenuMapper;

    @Override
    public BaseMapper <RoleMenu> getBaseMapper() {
        return roleMenuMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new RoleMenuParams();
    }

    @Override
    public RoleMenu getObjectModel() {
        return new RoleMenu();
    }


}