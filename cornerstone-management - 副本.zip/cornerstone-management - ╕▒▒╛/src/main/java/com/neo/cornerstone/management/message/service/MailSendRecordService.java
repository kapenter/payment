package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.message.feign.MailSendRecordFeign;
import com.neo.cornerstone.message.dto.request.MailSendRecordQueryDTO;
import com.neo.cornerstone.message.dto.response.MailSendRecordRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-03 17:17
 **/
@Service
public class MailSendRecordService  {

    @Autowired
    private  MailSendRecordFeign mailSendRecordFeign;


    public PageResponseDTO<MailSendRecordRespDTO> pageMailSendRecords(MailSendRecordQueryDTO mailSendRecordQueryDTO) {
        return mailSendRecordFeign.pageMailSendRecords(mailSendRecordQueryDTO);
    }
}
