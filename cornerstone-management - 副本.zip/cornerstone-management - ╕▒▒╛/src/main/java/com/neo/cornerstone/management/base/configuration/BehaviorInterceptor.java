package com.neo.cornerstone.management.base.configuration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.client.producer.SendStatus;
import com.alibaba.rocketmq.common.message.Message;
import com.neo.cornerstone.management.admin.exception.MqLogSendException;
import com.neo.cornerstone.management.base.constants.GlobalConfigConstant;
import com.neo.cornerstone.management.base.model.BehaviorLog;
import com.neo.cornerstone.management.base.util.ContentUtil;
import com.neo.cornerstone.management.base.util.IpUtils;
import com.neo.msplatform.framework.utils.rocketmq.service.RocketmqMessageService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import java.util.Date;

/*******************************************************************************
 * Created on 2019/9/16 10:03
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class BehaviorInterceptor implements HandlerInterceptor {

    private static final Logger logger = LoggerFactory.getLogger(BehaviorInterceptor.class);

    @Autowired
    private RocketmqMessageService rocketmqMessageService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        BehaviorLog behaviorLog = new BehaviorLog();
        String requestUrl = WebUtils.getPathWithinApplication(WebUtils.toHttp(request));
        behaviorLog.setUrl(requestUrl);
        behaviorLog.setCreateTime(new Date());
        String username = null;
        try {
            // 已登录或者未退出情况下
            username = (String) SecurityUtils.getSubject().getPrincipal();
        } catch (Exception e) {
        }
        if (null == username) {
            // 已退出 或者未登录
            try {
                username = (String) request.getAttribute(GlobalConfigConstant.USERNAME);
            } catch (Exception e1) {
                //
            }
        }
        if (null == username) {
            logger.warn("Behavior Log 操作[{}] - 未获取登录用户信息", requestUrl);
        }
        String bizId = null;
        Object preBizId = SecurityUtils.getSubject().getSession().getAttribute(GlobalConfigConstant.ACCESS_TOKEN);
        if (null != preBizId) {
            bizId = (String) preBizId;
        }
        if (null == bizId) {
            bizId = (String) SecurityUtils.getSubject().getSession().getId();
            bizId = bizId.substring(0, bizId.length() - 8);
        }
        String ip = IpUtils.getRemoteIpAddr((HttpServletRequest) request);

        behaviorLog.setBizId(bizId);
        behaviorLog.setUsername(username);
        behaviorLog.setIp(ip);

        SendResult result = rocketmqMessageService.sendMessage(
                new Message(GlobalConfigConstant.MANAGEMENT_LOG_TOPIC, GlobalConfigConstant.BEHAVIOR_LOG_TAG,
                        behaviorLog.getBizId(), JSON.toJSONString(behaviorLog).getBytes()));
        if (!SendStatus.SEND_OK.equals(result.getSendStatus())) {
            logger.error("Behavior Log 发送mq 失败 [{}]", behaviorLog);
            throw new MqLogSendException("Behavior Log send failure");
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {

    }
}
