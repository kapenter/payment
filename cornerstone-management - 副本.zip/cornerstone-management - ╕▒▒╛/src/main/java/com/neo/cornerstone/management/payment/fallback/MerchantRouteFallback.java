/*******************************************************************************
 * Create on 2019/9/2 17:39
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.fallback;

import com.neo.cornerstone.management.payment.feign.MerchantRouteFeign;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.route.QueryPageRequestDTO;
import com.neo.payment.dto.admin.route.RouteConfigRowDTO;
import com.neo.payment.dto.admin.route.UpdateConfigRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Component
public class MerchantRouteFallback implements MerchantRouteFeign {
    private static Logger logger = LoggerFactory.getLogger(MerchantRouteFallback.class);

    @Override
    public PageResponseDTO<RouteConfigRowDTO> queryPage(QueryPageRequestDTO requestDTO) {
        logger.error("[分页查询商户路由配置] [fallback] 查询商户路由配置列表失败，调用远程服务失败");
        return PageResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> updateConfig(UpdateConfigRequestDTO requestDTO) {
        logger.error("[修改商户路由配置] [fallback] 修改路由配置列表失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> openConfig(List<Integer> list) {
        logger.error("[开启商户路由配置] [fallback] 开启商户路由配置列表失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> closeConfig(List<Integer> list) {
        logger.error("[禁用商户路由配置] [fallback] 禁用商户路由配置列表失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> flushAll() {
        logger.error("[刷新所有商户路由配置] [fallback] 刷新商户路由配置列表失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> flushCache(List<Integer> list) {
        logger.error("[刷新商户路由配置] [fallback] 刷新商户路由配置列表失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }
}
