package com.neo.cornerstone.management.admin.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.List;
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class UserInfoDTO extends BaseObject {
    private static final long serialVersionUID = -5974027762186654894L;

    private String accessToken;
    private List<String> roles;
    private List<String> buttonPermission;
    private String name;
    private String email;
    private String mobile;
    private String username;
    private String avatar;
    private String introduction;
    private List<RouteConfigDTO> asyncRouter;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public List<RouteConfigDTO> getAsyncRouter() {
        return asyncRouter;
    }

    public void setAsyncRouter(List<RouteConfigDTO> asyncRouter) {
        this.asyncRouter = asyncRouter;
    }

    public List <String> getButtonPermission() {
        return buttonPermission;
    }

    public void setButtonPermission(List <String> buttonPermission) {
        this.buttonPermission = buttonPermission;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
