package com.neo.cornerstone.management.admin.model;

import com.neo.cornerstone.management.base.dto.BaseObject;

/**
 * Title:TOrganization<br/>
 * Description:(组织架构实体类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class Organization extends BaseModel {
    private static final long serialVersionUID = -7454552195074538640L;
    /**(名称)*/
    private String name;
    /**(父级)*/
    private Long parentId;
    /**(层级)*/
    private Integer level;
    /**(状态 1：有效 0： 无效)*/
    private Integer state;
    /**()*/
    private java.util.Date createTime;
    /**()*/
    private java.util.Date modTime;

    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Long getParentId(){
        return this.parentId;
    }
    public void setParentId(Long parentId){
        this.parentId = parentId;
    }
    public Integer getLevel(){
        return this.level;
    }
    public void setLevel(Integer level){
        this.level = level;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public java.util.Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(java.util.Date createTime){
        this.createTime = createTime;
    }
    public java.util.Date getModTime(){
        return this.modTime;
    }
    public void setModTime(java.util.Date modTime){
        this.modTime = modTime;
    }

    }