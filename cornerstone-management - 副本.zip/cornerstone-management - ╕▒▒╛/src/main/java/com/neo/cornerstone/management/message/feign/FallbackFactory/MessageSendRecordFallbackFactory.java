package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.MessageSendFeign;
import com.neo.cornerstone.message.dto.response.MessageSendLogRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 16:08
 **/
@Component
@Slf4j
public class MessageSendRecordFallbackFactory implements FallbackFactory<MessageSendFeign> {




    @Override
    public MessageSendFeign create(Throwable throwable) {
        return messageSendLogQueryPageDTO -> {
            log.error("[fallback]---[消息管理]---[短信管理]---[发送记录]---[pageMailSendRecords]列表异常,msg:{},cause:",throwable.getMessage(),throwable);
            PageResponseDTO<MessageSendLogRespDTO> pageResponseDTO=new PageResponseDTO<>();
            pageResponseDTO.setReturnCode(BizCodeEnum.SMS_PAGE_SEND_RECORD_FALLBACK_EXCEPTION.getCode());
            pageResponseDTO.setReturnMsg(BizCodeEnum.SMS_PAGE_SEND_RECORD_FALLBACK_EXCEPTION.getMessage());
            return pageResponseDTO;
        };
    }
}
