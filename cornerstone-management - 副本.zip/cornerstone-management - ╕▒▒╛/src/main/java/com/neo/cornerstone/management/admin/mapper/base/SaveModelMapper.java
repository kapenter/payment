package com.neo.cornerstone.management.admin.mapper.base;

import java.util.List;

public interface SaveModelMapper<T> {

    /**
     * 保存新记录
     *
     * @param model 记录数据
     * @return 受影响的记录数
     */
    Long saveModel(T model);

    /**
     * 保存新记录列表
     *
     * @param models 记录数据列表
     * @return 受影响的记录
     */
    int saveListModel(List <T> models);
}
