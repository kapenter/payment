package com.neo.cornerstone.management.base.constants;

public enum OperationModule {
    ADMIN_DEFAULT("ADMIN_DEFAULT", "ADMIN_DEFAULT", "操作日志"),
    ADMIN_LOG_OUT("Management", "认证", "退出登录"),
    ADMIN_LOG_IN_FAILURE("Management", "认证", "登录失败"),
    ADMIN_LOG_IN_SUCCESS("Management", "认证", "登录成功"),
    ADMIN_MENU_UPDATE("Management", "菜单管理", "更新菜单"),
    ADMIN_MENU_DELETE("Management", "菜单管理", "删除菜单"),
    ADMIN_MENU_ADD("Management", "菜单管理", "添加菜单"),
    ADMIN_ORG_UPDATE("Management", "组织架构管理", "更新组织架构"),
    ADMIN_ORG_DELETE("Management", "组织架构管理", "删除组织架构"),
    ADMIN_ORG_ADD("Management", "组织架构管理", "添加组织架构"),
    ADMIN_PERMS_UPDATE("Management", "权限管理", "更新权限"),
    ADMIN_PERMS_DELETE("Management", "权限管理", "删除权限"),
    ADMIN_PERMS_ADD("Management", "权限管理", "添加权限"),
    ADMIN_ROLE_UPDATE("Management", "角色管理", "更新角色"),
    ADMIN_ROLE_DELETE("Management", "角色管理", "删除角色"),
    ADMIN_ROLE_ADD("Management", "角色管理", "添加角色"),
    ADMIN_ROLE_AUTH("Management", "角色管理", "角色授权"),
    ADMIN_USER_PWD_MOD("Management", "用户管理", "修改密码"),
    ADMIN_USER_AUTH("Management", "用户管理", "授权角色"),
    ADMIN_USER_UPDATE("Management", "用户管理", "更新用户信息"),
    ADMIN_USER_ADD("Management", "用户管理", "添加用户"),
    ADMIN_USER_PWD_RESET("Management", "用户管理", "重置密码"),
    MERCHANT_APP_ADD("Merchant", "商户管理", "商户账户添加"),
    MERCHANT_APP_UPDATE("Merchant", "商户管理", "商户账户添加"),
    MERCHANT_BUSINESS_CONFIG_ADD("Merchant", "商户管理", "业务权限添加"),
    MERCHANT_BUSINESS_CONFIG_UPDATE("Merchant", "商户管理", "业务权限修改"),
    MERCHANT_AUTH_CONFIG_UPDATE("Merchant", "商户管理", "商户权限修改"),

    /**消息管理子目录**/
    MESSAGE_MERCHANT_APP_ACCOUNT_ADD("Message", "消息管理", "应用账号新增 "),
    MESSAGE_MERCHANT_APP_ACCOUNT_UPDATE("Message", "消息管理", "应用账号修改"),
    MESSAGE_MERCHANT_APP_ACCOUNT_LIST("Message", "消息管理", "应用账号查询"),
    MESSAGE_CHANNEL_INFO_ADD("Message", "消息管理", "渠道管理新增"),
    MESSAGE_CHANNEL_INFO_UPDATE("Message", "消息管理", "渠道管理修改"),
    MESSAGE_CHANNEL_INFO_LIST("Message", "消息管理", "渠道管理查询"),
    /**短信管理**/
    MESSAGE_CHANNEL_ACCOUNT_LIST("Message", "消息管理-短信管理", "渠道账户查询"),
    MESSAGE_CHANNEL_ACCOUNT_ADD("Message", "消息管理-短信管理", "渠道账户新增"),
    MESSAGE_CHANNEL_ACCOUNT_UPDATE("Message", "消息管理-短信管理", "渠道账户修改"),
    MESSAGE_CHANNEL_ACCOUNT_ROUTE_ADD("Message", "消息管理-短信管理", "路由配置新增"),
    MESSAGE_CHANNEL_ACCOUNT_ROUTE_UPDATE("Message", "消息管理-短信管理", "路由配置修改"),
    MESSAGE_CHANNEL_ACCOUNT_ROUTE_LIST("Message", "消息管理-短信管理", "路由配置查询"),
    MESSAGE_SEND_RECORD_LIST("Message", "消息管理-短信管理", "发送记录查询"),
    /**邮件管理**/
    MESSAGE_MAIL_CHANNEL_ACCOUNT_LIST("Message", "消息管理-邮件管理", "渠道账户查询"),
    MESSAGE_MAIL_CHANNEL_ACCOUNT_ADD("Message", "消息管理-邮件管理", "渠道账户新增"),
    MESSAGE_MAIL_CHANNEL_ACCOUNT_UPDATE("Message", "消息管理-邮件管理", "渠道账户修改"),
    MESSAGE_MAIL_ROUTE_CONFIG_LIST("Message", "消息管理-邮件管理", "路由配置查询"),
    MESSAGE_MAIL_ROUTE_CONFIG_ADD("Message", "消息管理-邮件管理", "路由配置新增"),
    MESSAGE_MAIL_ROUTE_CONFIG_UPDATE("Message", "消息管理-邮件管理", "路由配置修改"),
    MESSAGE_MAIL_SEND_RECORD_LIST("Message", "消息管理-邮件管理", "发送记录查询"),

    ;

    private String moduleType;
    private String subModuleType;
    private String operationContent;

    OperationModule(String moduleType, String subModuleType, String operationContent) {
        this.moduleType = moduleType;
        this.subModuleType = subModuleType;
        this.operationContent = operationContent;
    }

    public String getModuleType() {
        return moduleType;
    }

    public void setModuleType(String moduleType) {
        this.moduleType = moduleType;
    }

    public String getSubModuleType() {
        return subModuleType;
    }

    public void setSubModuleType(String subModuleType) {
        this.subModuleType = subModuleType;
    }

    public String getOperationContent() {
        return operationContent;
    }

    public void setOperationContent(String operationContent) {
        this.operationContent = operationContent;
    }
}
