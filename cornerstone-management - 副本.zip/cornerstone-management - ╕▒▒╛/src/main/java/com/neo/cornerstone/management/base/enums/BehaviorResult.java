package com.neo.cornerstone.management.base.enums;

/*******************************************************************************
 * Created on 2019/7/18 18:45
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public enum BehaviorResult {
    SUCCESS(1, "成功"),
    FAILURE(0, "失败"),
    ERROR(-1, "异常")
    ;

    private Integer code;

    private String message;

    private BehaviorResult(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public BehaviorResult getEnumByCode(Integer code) {
        for(BehaviorResult value : BehaviorResult.values()){
            if(value.getCode().equals(code)){
                return value;
            }
        }
        return null;
    }

}
