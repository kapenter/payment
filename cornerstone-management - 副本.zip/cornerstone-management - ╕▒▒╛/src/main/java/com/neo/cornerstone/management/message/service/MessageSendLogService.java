package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.message.feign.MessageSendFeign;
import com.neo.cornerstone.message.dto.request.MessageSendLogQueryPageDTO;
import com.neo.cornerstone.message.dto.response.MessageSendLogRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-02 17:14
 **/
@Service
public class MessageSendLogService  implements MessageSendFeign{

    @Autowired
    private  MessageSendFeign messageSendFeign;

    @Override
    public PageResponseDTO<MessageSendLogRespDTO> pageMessageSendLogs(MessageSendLogQueryPageDTO messageSendLogQueryPageDTO) {
        return messageSendFeign.pageMessageSendLogs(messageSendLogQueryPageDTO);
    }
}
