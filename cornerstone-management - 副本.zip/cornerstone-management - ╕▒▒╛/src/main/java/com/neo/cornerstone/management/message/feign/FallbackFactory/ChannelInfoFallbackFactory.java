package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.ChannelInfoFeign;
import com.neo.cornerstone.management.message.resp.BaseRespDTO;
import com.neo.cornerstone.message.dto.request.ChannelInfoQueryDTO;
import com.neo.cornerstone.message.dto.request.ChannelInfoRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelInfoRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 16:08
 **/
@Component
@Slf4j
public class ChannelInfoFallbackFactory implements FallbackFactory<ChannelInfoFeign> {


    @Override
    public ChannelInfoFeign create(Throwable throwable) {
        return new ChannelInfoFeign() {
            @Override
            public PageResponseDTO<ChannelInfoRespDTO> pageChannelInfos(ChannelInfoQueryDTO channelInfoQueryDTO) {
                log.error("[fallback]---[消息管理]---[渠道管理]---[pageChannelInfos]列表异常,msg:{},cause:" ,throwable.getMessage(),throwable);
                PageResponseDTO<ChannelInfoRespDTO> pageResponseDTO=new PageResponseDTO<>();
                pageResponseDTO.setReturnCode(BizCodeEnum.SMS_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION.getCode());
                pageResponseDTO.setReturnMsg(BizCodeEnum.SMS_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION.getMessage());
                return pageResponseDTO;
            }

            @Override
            public List<ChannelInfoRespDTO> allChannelInfos() {
                log.error("[fallback]---[消息管理]---[渠道管理]---[allChannelInfos]列表异常,msg:{},cause:",throwable.getMessage(),throwable);
                return Collections.emptyList();
            }

            @Override
            public OperationResponseDTO<Boolean> addChannelInfo(ChannelInfoRequestDTO channelInfoRequestDTO) {
                log.error("[fallback]---[消息管理]---[渠道管理]---[addChannelInfo]新增异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.SMS_ADD_CHANNEL_INFO_FALLBACK_EXCEPTION);
            }

            @Override
            public OperationResponseDTO<Boolean> updateChannelInfo(ChannelInfoRequestDTO channelInfoRequestDTO) {
                log.error("[fallback]---[消息管理]---[渠道管理]---[updateChannelInfo]修改异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.SMS_UPDATE_CHANNEL_INFO_FALLBACK_EXCEPTION);
            }
        };
    }
}
