package com.atguigu.springcloud.service;
/**
 * @author wsk
 * @date 2020/3/17 11:19
 */
public interface IMessageProvider {
    /**
     * 消息发送
     * @return
     */
    String send();
}