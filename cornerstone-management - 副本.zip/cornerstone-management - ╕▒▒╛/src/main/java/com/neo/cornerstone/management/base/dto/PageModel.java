package com.neo.cornerstone.management.base.dto;

import com.alibaba.fastjson.JSON;

import java.util.List;

/**
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2018</p>
 *
 * @author Luo Shun
 * @version v1.0 2018/02/27
 */
public class PageModel<T> extends BaseResponse<List<T>>{
    private Integer pageSize;
    private Integer pageNow;
    private Integer totalRows;

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNow() {
        return pageNow;
    }

    public void setPageNow(Integer pageNow) {
        this.pageNow = pageNow;
    }

    public Integer getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(Integer totalRows) {
        this.totalRows = totalRows;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
