package com.neo.cornerstone.management.admin.mapper.base;

public interface BaseMapper<T>
        extends DeleteModelMapper<T>, QueryModelMapper<T>, SaveModelMapper<T>, UpdateModelMapper<T> {

}
