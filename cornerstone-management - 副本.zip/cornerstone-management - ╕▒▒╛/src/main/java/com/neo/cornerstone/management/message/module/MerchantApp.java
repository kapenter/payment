package com.neo.cornerstone.management.message.module;

import lombok.Data;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-23 14:02
 **/
@Data
public class MerchantApp {

    private String appId ;

    private  String appName ;

    private String merchantId;

    public MerchantApp(String appId, String appName, String merchantId) {
        this.appId = appId;
        this.appName = appName;
        this.merchantId = merchantId;
    }

    public MerchantApp() {
    }
}
