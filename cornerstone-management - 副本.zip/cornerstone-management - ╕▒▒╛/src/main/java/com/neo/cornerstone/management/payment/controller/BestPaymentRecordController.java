/*******************************************************************************
 * Create on 2019/9/2 17:45
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.controller;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.payment.constant.URL;
import com.neo.cornerstone.management.payment.service.BestPaymentRecordService;
import com.neo.cornerstone.management.payment.vo.best.QueryBestPageRequestVO;
import com.neo.cornerstone.management.payment.vo.best.SetBestFailRequestVO;
import com.neo.payment.dto.admin.best.BestPaymentRowDTO;
import com.neo.payment.dto.admin.best.QuotaPaymentRowDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@RestController
public class BestPaymentRecordController {
    @Autowired
    private BestPaymentRecordService bestPaymentRecordService;

    @RequestMapping(path = URL.QUERY_BEST_PAYMENT_RECORD_PAGE_LIST)
    public PageModel<BestPaymentRowDTO> queryBestPage(@RequestBody QueryBestPageRequestVO requestVO) {
        return bestPaymentRecordService.queryBestPage(requestVO);
    }

    @RequestMapping(path = URL.SYNC_BEST_PAYMENT_RECORD_RESULT)
    public BaseResponse<String> syncBestResult(@RequestParam String platformOrder) {
        return bestPaymentRecordService.syncBestResult(platformOrder);
    }

    @RequestMapping(path = URL.SET_BEST_PAYMENT_RECORD_FAIL)
    public BaseResponse<String> setBestFail(@RequestBody SetBestFailRequestVO requestVO) {
        return bestPaymentRecordService.setBestFail(requestVO);
    }

    @RequestMapping(path = URL.QUERY_BEST_QUOTA_PAYMENT_RECORD_LIST)
    public BaseResponse<List<QuotaPaymentRowDTO>> queryQuotaList(@RequestParam String tradeOrder) {
        return bestPaymentRecordService.queryQuotaList(tradeOrder);
    }

}
