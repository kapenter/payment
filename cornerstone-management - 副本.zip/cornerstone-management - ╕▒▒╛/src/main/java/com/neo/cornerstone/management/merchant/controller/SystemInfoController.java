package com.neo.cornerstone.management.merchant.controller;

import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.merchant.constants.MerchantUrl;
import com.neo.cornerstone.management.merchant.service.SystemInfoClient;
import com.neo.cornerstone.management.merchant.util.ResponseTransferUtil;
import com.neo.cornerstone.merchant.serve.define.dto.PageResponseDTO;
import com.neo.cornerstone.merchant.serve.define.dto.ResponseDTO;
import com.neo.cornerstone.merchant.serve.define.dto.SystemInfoDTO;
import com.neo.cornerstone.merchant.serve.define.dto.SystemInfoQueryParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @Description:系统配置
 * @Author: yanyiwei
 * @Date: 2019/08/26
 */
@Controller
public class SystemInfoController extends BaseController {

    @Autowired
    private SystemInfoClient systemInfoClient;

    /**
     * 功能描述:系统配置分页
     * @param: [pageNum, pageSize, name]
     * @return:
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.PAGE_SYSTEM_INFO)
    @ResponseBody
    public PageModel<SystemInfoDTO> pageSystemInfo(Integer pageNum, Integer pageSize, String name) {
        SystemInfoQueryParam pageQueryParam = new SystemInfoQueryParam(pageNum, pageSize, name);
        PageResponseDTO<SystemInfoDTO> pageResponseDTO = systemInfoClient.pageSystemInfo(pageQueryParam);
        PageModel<SystemInfoDTO> objectPageModel = new PageModel<>();
        objectPageModel.setTotalRows(pageResponseDTO.getTotalRows());
        objectPageModel.setData(pageResponseDTO.getData());
        return ResponseUtils.buildSuccessPageResponse(objectPageModel);
    }

    /**
     * 功能描述:所有系统配置列表
     * @param: []
     * @return:
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.GET_SYSTEM_INFO_LIST)
    @ResponseBody
    public BaseResponse<List<SystemInfoDTO>> getMerchantInfoList() {
        List<SystemInfoDTO> systemInfoDTOList = systemInfoClient.getSystemInfoList();
        return ResponseUtils.buildSuccessResponse(systemInfoDTOList);
    }

    /**
     * 功能描述: 系统配置添加
     * @param: [systemInfoDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.ADD_SYSTEM_INFO)
    @ResponseBody
    public BaseResponse addSystemInfo(@RequestBody SystemInfoDTO systemInfoDTO) {
        logger.info("[系统配置添加]-入参:{}", systemInfoDTO);
        ResponseDTO responseDTO = systemInfoClient.addSystemInfo(systemInfoDTO);
        logger.info("[系统配置添加]-结果:{}", responseDTO);
        return ResponseTransferUtil.transferResponse(responseDTO);
    }

    /**
     * 功能描述: 系统配置更新
     * @param: [systemInfoDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.UPDATE_SYSTEM_INFO)
    @ResponseBody
    public BaseResponse updateSystemInfo(@RequestBody SystemInfoDTO systemInfoDTO) {
        logger.info("[系统配置修改]-入参:{}", systemInfoDTO);
        ResponseDTO responseDTO = systemInfoClient.updateSystemInfo(systemInfoDTO);
        logger.info("[系统配置修改]-结果:{}", responseDTO);
        return ResponseTransferUtil.transferResponse(responseDTO);
    }
}
