package com.neo.cornerstone.management.message.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.BaseUrl;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.service.ChannelInfoService;
import com.neo.cornerstone.management.message.service.MailChannelAccountService;
import com.neo.cornerstone.management.message.service.MailRouteConfigService;
import com.neo.cornerstone.management.message.service.MerchantAppAccountService;
import com.neo.cornerstone.message.dto.request.MailAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.MailAccountRequestDTO;
import com.neo.cornerstone.message.dto.response.*;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:   邮件管理--渠道账户模块
 * @author: xn086532
 * @create: 2019-09-03 16:26
 **/
@RestController
@RequestMapping(BaseUrl.ROOT_URL)
public class MailChannelAccountController {


    @Autowired
    private MailChannelAccountService mailChannelAccountService;

    @Autowired
    private MerchantAppAccountService merchantAppAccountService;

    @Autowired
    private ChannelInfoService channelInfoService;

    /**
     * 渠道管理列表查询
     * @param mailAccountQueryDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MAIL_CHANNEL_ACCOUNT_LIST, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MAIL_CHANNEL_ACCOUNT_LIST)
    public PageModel<ChannelAccountRespDTO> pageMailChannelInfos(@RequestBody @Validated MailAccountQueryDTO mailAccountQueryDTO) {
        PageModel<MailAccountRespDTO>  pageModel=new PageModel<>();
        PageResponseDTO<MailAccountRespDTO> channelAccountRespDTOPageResponseDTO = mailChannelAccountService.pageMailChannelAccounts(mailAccountQueryDTO);
        pageModel.setTotalRows(channelAccountRespDTOPageResponseDTO.getTotalRow());
        List<MailAccountRespDTO>  listAccountRoutes=channelAccountRespDTOPageResponseDTO.getData();
        List<ChannelInfoRespDTO> channels= channelInfoService.allChannelInfos();
        List<MerchantAppAccountRespDTO> merchantApps= merchantAppAccountService.allMerchantAppAccount();

        for (MailAccountRespDTO mailAccountRespDTO:listAccountRoutes){
            //设置channelName
            for (ChannelInfoRespDTO channelInfo:channels){
                if(mailAccountRespDTO.getChannelCode().equals(channelInfo.getChannelCode())){
                    mailAccountRespDTO.setChannelName(channelInfo.getChannelName());
                }
            }
            //设置应用账号名称
            for (MerchantAppAccountRespDTO merchantApp:merchantApps){
                if(mailAccountRespDTO.getAppAccNo().equals(merchantApp.getAppAccNo())){
                    mailAccountRespDTO.setAppAccName(merchantApp.getAppAccName());
                }
            }
        }
        pageModel.setData(listAccountRoutes);
        return ResponseUtils.buildSuccessPageResponse(pageModel);
    }

    /**
     * 新增渠道管理配置
     * @param mailChannelAccountRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MAIL_CHANNEL_ACCOUNT_ADD, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MAIL_CHANNEL_ACCOUNT_ADD)
    public BaseResponse<Boolean> addMailChannelAccount(@RequestBody @Validated MailAccountRequestDTO mailChannelAccountRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(mailChannelAccountService.addMailChannelAccount(mailChannelAccountRequestDTO));
    }


    /**
     * 修改道管理配置
     * @param mailChannelAccountRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MAIL_CHANNEL_ACCOUNT_UPDATE, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MAIL_CHANNEL_ACCOUNT_UPDATE)
    public BaseResponse<Boolean> updateMailChannelAccount(@RequestBody @Validated MailAccountRequestDTO mailChannelAccountRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(mailChannelAccountService.updateMailChannelAccount(mailChannelAccountRequestDTO));
    }
}
