/*******************************************************************************
 * Create on 2019/9/2 17:39
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.fallback;

import com.neo.cornerstone.management.payment.feign.PaymentRecordFeign;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.payment.PaymentRowDTO;
import com.neo.payment.dto.admin.payment.QueryPageRequestDTO;
import com.neo.payment.dto.admin.payment.SetFailRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Component
public class PaymentRecordFallback implements PaymentRecordFeign {
    private static Logger logger = LoggerFactory.getLogger(PaymentRecordFallback.class);

    @Override
    public PageResponseDTO<PaymentRowDTO> queryPage(QueryPageRequestDTO requestDTO) {
        logger.error("[分页查询支付记录] [fallback] 查询支付记录列表失败，调用远程服务失败");
        return PageResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> syncResult(String platformOrder) {
        logger.error("[同步支付结果] [fallback] 同步支付结果失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> setFail(SetFailRequestDTO requestDTO) {
        logger.error("[支付记录置为失败] [fallback] 交易操作失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

}
