package com.neo.cornerstone.management.admin.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.Date;
import java.util.List;

/*******************************************************************************
 * Created on 2019/7/30 11:42
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class UserTableDTO extends BaseObject {
    private static final long serialVersionUID = 3462118312201408786L;
    private Long id;
    /**(用户名)*/
    private String username;
    private String realName;
    private String email;
    private String mobile;
    /**(部门ID)*/
    private Long orgId;
    /**(帐号状态: 0: 无效1：有效 2：冻结)*/
    private Integer accountState;
    /**(密码状态: 0: 需要修改 1: 正常使用)*/
    private Integer pwdState;
    private Integer state;
    private String orgName;
    private List <String> roleList;
    private List<Long> roleIdList;
    private Date createTime;
    private Date modTime;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModTime() {
        return modTime;
    }

    public void setModTime(Date modTime) {
        this.modTime = modTime;
    }

    public List <Long> getRoleIdList() {
        return roleIdList;
    }

    public void setRoleIdList(List <Long> roleIdList) {
        this.roleIdList = roleIdList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public Integer getAccountState() {
        return accountState;
    }

    public void setAccountState(Integer accountState) {
        this.accountState = accountState;
    }

    public Integer getPwdState() {
        return pwdState;
    }

    public void setPwdState(Integer pwdState) {
        this.pwdState = pwdState;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public List <String> getRoleList() {
        return roleList;
    }

    public void setRoleList(List <String> roleList) {
        this.roleList = roleList;
    }
}
