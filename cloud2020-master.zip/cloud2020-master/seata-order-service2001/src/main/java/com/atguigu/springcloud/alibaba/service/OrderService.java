package com.atguigu.springcloud.alibaba.service;

import com.atguigu.springcloud.alibaba.domain.Order;

/**
 * @author wsk
 * @date 2020/3/25 20:58
 */
public interface OrderService {
    void create(Order order);


}
