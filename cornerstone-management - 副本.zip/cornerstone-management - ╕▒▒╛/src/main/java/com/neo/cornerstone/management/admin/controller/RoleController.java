package com.neo.cornerstone.management.admin.controller;

import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.admin.dto.request.PermissionPostDTO;
import com.neo.cornerstone.management.admin.dto.request.PermissionUpdateDTO;
import com.neo.cornerstone.management.admin.dto.request.RoleAuthDTO;
import com.neo.cornerstone.management.admin.dto.request.RolePostDTO;
import com.neo.cornerstone.management.admin.dto.response.PermissionInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.RoleInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.RolePermissionInfoDTO;
import com.neo.cornerstone.management.admin.service.biz.PermissionBizService;
import com.neo.cornerstone.management.admin.service.biz.RoleBizService;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/*******************************************************************************
 * Created on 2019/7/18 13:49
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@RestController
public class RoleController extends BaseController {

    @Autowired
    private RoleBizService roleBizService;

    /**
     * 角色权限编辑
     * @param roleAuthDTO
     * @return
     */
    @RequestMapping(value = Url.ROLE_AUTH, method = RequestMethod.POST)
    public BaseResponse<Boolean> userAuth(@PathVariable("id")Long roleId, @RequestBody @Valid RoleAuthDTO roleAuthDTO) {
        this.roleBizService.roleAuth(roleId, roleAuthDTO);
        return ResponseUtils.buildSuccessResponse(true);
    }



    /**
     *  查询角色分页列表
     * @param pageNum
     * @param pageSize
     * @param name
     * @return
     */
    @RequestMapping(value = Url.QUERY_ROLE, method = RequestMethod.GET)
    public PageModel<RoleInfoDTO> queryRoles(Integer pageNum, Integer pageSize, String name) {
        pageNum = pageNum == null || pageNum <0 ? 0 : pageNum;
        pageSize = pageSize == null || pageSize < 0 ? 10: pageSize;

        PageModel<RoleInfoDTO> rolePageData = roleBizService.queryRoles(pageNum, pageSize, name);
        return ResponseUtils.buildSuccessPageResponse(rolePageData);
    }

    /**
     * 查询所有菜单与角色信息 用于角色权限管理
     * @param roleId
     * @return
     */
    @RequestMapping(value = Url.QUERY_ROLE_PERMISSION, method = RequestMethod.GET)
    public BaseResponse<RolePermissionInfoDTO> queryRolePermission(@PathVariable("roleId") long roleId) {

        RolePermissionInfoDTO responseData = roleBizService.queryRolePermission(roleId);
        return ResponseUtils.buildSuccessResponse(responseData);
    }

    /**
     * 添加角色
     * @param rolePostDTO
     * @return
     */
    @RequestMapping(value = Url.ADD_ROLE, method = RequestMethod.POST)
    public BaseResponse<Boolean> addRole(@RequestBody @Valid RolePostDTO rolePostDTO) {
        this.roleBizService.addRole(rolePostDTO);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 删除角色
     * @param id
     * @return
     */
    @RequestMapping(value = Url.DELETE_ROLE, method = RequestMethod.POST)
    public BaseResponse<Boolean> deleteRole(@PathVariable("id") Long id) {
        roleBizService.deleteRole(id);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 更新角色
     * @param id
     * @param rolePostDTO
     * @return
     */
    @RequestMapping(value = Url.UPDATE_ROLE, method = RequestMethod.POST)
    public BaseResponse<Boolean> updateRole(@PathVariable("id") Long id, @RequestBody @Valid RolePostDTO rolePostDTO) {
        Boolean result = roleBizService.updateRole(id, rolePostDTO);

        if (result) {
            return ResponseUtils.buildSuccessResponse(true);
        } else {
            return ResponseUtils.buildFailureResponse(false, GlobalReturnCode.UPDATE_FAILURE.getCode(), GlobalReturnCode.UPDATE_FAILURE.getMessage());
        }
    }

}
