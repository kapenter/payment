package com.alibaba.nacos.nacosprovider7000;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NacosProvider7000ApplicationTests {

    @Test
    void contextLoads() {
    }

}
