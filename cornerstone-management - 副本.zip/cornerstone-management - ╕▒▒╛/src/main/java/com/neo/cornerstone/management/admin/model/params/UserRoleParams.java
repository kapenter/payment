package com.neo.cornerstone.management.admin.model.params;

import java.util.Date;

/**
 * Title:TUserRole<br/>
 * Description:(用户角色配置mapper参数对象)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class UserRoleParams extends BaseParams {
    private static final long serialVersionUID = 8508397665190889574L;
    /**(用户ID)*/
    private Long userId;
    /**(角色ID)*/
    private Long roleId;
    /**(状态0： 无效 1： 有效)*/
    private Integer state;
    /**()*/
    private Date createTime;
    /**()*/
    private Date modTime;

    public Long getUserId(){
        return this.userId;
    }
    public void setUserId(Long userId){
        this.userId = userId;
    }
    public Long getRoleId(){
        return this.roleId;
    }
    public void setRoleId(Long roleId){
        this.roleId = roleId;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getModTime(){
        return this.modTime;
    }
    public void setModTime(Date modTime){
        this.modTime = modTime;
    }

    @Override
    public String toString() {
        return "TUserRole[" +
        "id=" + id +
        ",userId=" + userId +
        ",roleId=" + roleId +
        ",state=" + state +
        ",createTime=" + createTime +
        ",modTime=" + modTime +
        ']';
    }

}