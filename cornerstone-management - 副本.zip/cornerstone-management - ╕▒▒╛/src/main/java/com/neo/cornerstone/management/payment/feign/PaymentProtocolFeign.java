package com.neo.cornerstone.management.payment.feign;

import com.neo.cornerstone.management.payment.fallback.PaymentProtocolFallback;
import com.neo.payment.constant.AdminURL;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.protocol.ProtocolRowDTO;
import com.neo.payment.dto.admin.protocol.QueryPageRequestDTO;
import com.neo.payment.dto.admin.protocol.UnbindRequestDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 支付协议
 */
@FeignClient(value = "springcloud-5102-payment", fallback = PaymentProtocolFallback.class)
public interface PaymentProtocolFeign {

    @RequestMapping(value = AdminURL.QUERY_PAYMENT_PROTOCOL_PAGE_LIST, method = RequestMethod.POST)
    PageResponseDTO<ProtocolRowDTO> queryPage(@RequestBody QueryPageRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.UNBIND_PAYMENT_PROTOCOL, method = RequestMethod.POST)
    ResponseDTO<Long> unbind(@RequestBody UnbindRequestDTO requestDTO);

}
