package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/*******************************************************************************
 * Created on 2019/7/24 15:35
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class UserPostDTO extends BaseObject {
    private static final long serialVersionUID = -8343071769445360729L;

    private String username;
    private String realName;
    private String email;
    private String mobile;
    @NotNull(message = "账户状态不能为空")
    private Integer accountState;
    @NotNull(message = "密码状态不能为空")
    private Integer pwdState;
    @NotNull(message = "组织不能为空")
    private Long orgId;

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public Integer getAccountState() {
        return accountState;
    }

    public void setAccountState(Integer accountState) {
        this.accountState = accountState;
    }

    public Integer getPwdState() {
        return pwdState;
    }

    public void setPwdState(Integer pwdState) {
        this.pwdState = pwdState;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
