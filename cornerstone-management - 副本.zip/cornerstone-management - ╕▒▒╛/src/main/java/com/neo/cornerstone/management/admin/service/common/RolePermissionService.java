package com.neo.cornerstone.management.admin.service.common;

import com.neo.cornerstone.management.admin.mapper.RolePermissionMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.RolePermission;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.RolePermissionParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Title:TRolePermissionServiceImpl<br/>
 * Description:(角色权限配置SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("rolePermissionService")
public class RolePermissionService extends MysqlBaseServiceImpl <RolePermission> {


    @Autowired
    private RolePermissionMapper rolePermissionMapper;

    @Override
    public BaseMapper <RolePermission> getBaseMapper() {
        return rolePermissionMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new RolePermissionParams();
    }

    @Override
    public RolePermission getObjectModel() {
        return new RolePermission();
    }

}