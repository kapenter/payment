package com.neo.cornerstone.management.admin.mapper.base;

import com.neo.cornerstone.management.admin.model.params.BaseParams;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface QueryModelMapper<T> {

    /**
     * 通过主键查询记录
     *
     * @param id 主键
     * @return 记录实体
     */
    T queryById(@Param("id") Long id);

    /**
     * 通过条件查询记录
     *
     * @param params 条件
     * @return 记录实体
     */
    T queryByCondition(BaseParams params);

    /**
     * 通过条件查询记录列表
     *
     * @param params 条件
     * @return 记录列表
     */
    List<T> queryListByCondition(BaseParams params);

    /**
     * 通过条件查询记录数
     *
     * @param params 条件
     * @return 记录数
     */
    int queryCountByCondition(BaseParams params);

    /**
     * 查询分页
     *
     * @param params
     * @return
     */
    List<T> queryPageList(BaseParams params);

    /**
     * 查询分页总数
     *
     * @param params
     * @return
     */
    int queryPageCountList(BaseParams params);
}
