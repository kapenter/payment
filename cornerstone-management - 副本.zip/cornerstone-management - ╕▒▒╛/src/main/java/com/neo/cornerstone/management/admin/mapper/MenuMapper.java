package com.neo.cornerstone.management.admin.mapper;

import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.Menu;
import com.neo.cornerstone.management.admin.model.ext.MenuExt;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Title:TMenuMapper<br/>
 * Description:(菜单mapper接口)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public interface MenuMapper extends BaseMapper <Menu> {

    List <MenuExt> queryListByConditionExt(BaseParams params);

}
