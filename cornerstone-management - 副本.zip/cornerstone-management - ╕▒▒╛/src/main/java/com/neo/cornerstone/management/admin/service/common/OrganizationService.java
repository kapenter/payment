package com.neo.cornerstone.management.admin.service.common;

import com.neo.cornerstone.management.admin.mapper.OrganizationMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.Organization;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.OrganizationParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Title:TOrganizationServiceImpl<br/>
 * Description:(组织架构SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("organizationService")
public class OrganizationService extends MysqlBaseServiceImpl <Organization> {

    private static final Logger logger = LoggerFactory.getLogger(OrganizationService.class);

    @Autowired
    private OrganizationMapper organizationMapper;

    @Override
    public BaseMapper <Organization> getBaseMapper() {
        return organizationMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new OrganizationParams();
    }

    @Override
    public Organization getObjectModel() {
        return new Organization();
    }

}