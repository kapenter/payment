package com.neo.cornerstone.management.admin.service.common;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.neo.cornerstone.management.admin.constants.GlobalConfig;
import com.neo.cornerstone.management.admin.enums.ErrorCode;
import com.neo.cornerstone.management.admin.exception.ParamsException;
import com.neo.cornerstone.management.admin.mapper.MenuMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.Menu;
import com.neo.cornerstone.management.admin.model.ext.MenuExt;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.MenuParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;

/**
 * Title:TMenuServiceImpl<br/>
 * Description:(菜单SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("menuService")
public class MenuService extends MysqlBaseServiceImpl <Menu> {

    private static final String PRE_MENU_KEY = "menu_";
    private static final String PRE_MENU_SINGLE = PRE_MENU_KEY + "single_";
    private static final String PRE_MENU_LISET = PRE_MENU_KEY + "list_";

    @Autowired
    private StringRedisTemplate clusterStringRedisTemplate;

    @Autowired
    private MenuMapper menuMapper;

    @Override
    public BaseMapper <Menu> getBaseMapper() {
        return menuMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new MenuParams();
    }

    @Override
    public Menu getObjectModel() {
        return new Menu();
    }

    public List <MenuExt> queryListByConditionExt(BaseParams params) {
        if (null == params) {
            throw new ParamsException(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMessage());
        }
        return menuMapper.queryListByConditionExt(params);
    }

    @Override
    public Menu queryById(Long id) {
        String redisData = clusterStringRedisTemplate.opsForValue().get(PRE_MENU_SINGLE + id);
        if (null != redisData) {
            return JSON.parseObject(redisData, Menu.class);
        }
        Menu menu = super.queryById(id);
        if (null != menu) {
            clusterStringRedisTemplate.opsForValue().set(PRE_MENU_SINGLE + id, JSON.toJSONString(menu),
                    GlobalConfig.commonRedisTime, TimeUnit.HOURS);
        }
        return menu;
    }

    @Override
    public Boolean deleteById(Long id) {
        clusterStringRedisTemplate.delete(PRE_MENU_SINGLE + id);
        clusterStringRedisTemplate.delete(PRE_MENU_LISET);
        return super.deleteById(id);
    }

    @Override
    public int deleteByCondition(BaseParams params) {
        clusterStringRedisTemplate.delete(PRE_MENU_KEY);
        return super.deleteByCondition(params);
    }

    @Override
    public Boolean updateById(Menu params) {
        clusterStringRedisTemplate.delete(PRE_MENU_SINGLE + params.getId());
        clusterStringRedisTemplate.delete(PRE_MENU_LISET);
        return super.updateById(params);
    }
}

