package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.List;

public class RolePermissionAuthDTO extends BaseObject {
    private static final long serialVersionUID = 5200915114875435651L;

    private Long id;

    private List<Long> permissionIdList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Long> getPermissionIdList() {
        return permissionIdList;
    }

    public void setPermissionIdList(List<Long> permissionIdList) {
        this.permissionIdList = permissionIdList;
    }
}
