//package com.alibaba.springcloudalibaba;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class SpringCloudAlibabaApplication {
//
//    public static void main(String[] args) {
//        SpringApplication.run(SpringCloudAlibabaApplication.class, args);
//    }
//
//}
