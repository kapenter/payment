package com.neo.cornerstone.management.admin.enums;

/*******************************************************************************
 * Created on 2019/7/18 18:45
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public enum AdminReturnCode {
    MENU_PARENT_ERROR("PARENT_MENU_NOT_EXISTS", "父级菜单不存在"),
    MENU_NOT_EXISTS("MENU_NOT_EXISTS", "菜单不存在"),
    MENU_REF_ROLE("MENU_REF_ROLE", "存在角色关联菜单"),
    MENU_LEVEL_EXISTS("MENU_LEVEL_EXISTS", "存在同级同名菜单"),
    MENU_PERMISSION_REF_ROLE("MENU_PERM_REF_ROLE", "存在角色关联菜单权限"),
    USER_NOT_EXISTS("USER_NOT_EXISTS", "用户不存在"),
    ORG_PARENT_ERROR("PARENT_ORG_NOT_EXISTS", "父级组织不存在"),
    ORG_NOT_EXISTS("ORG_NOT_EXISTS", "组织不存在"),
    ORG_LEVEL_EXISTS("ORG_LEVEL_EXISTS", "存在同级别名称"),
    ORG_ERROR("ORG_ERROR", "非部门组织"),
    ORG_REF_USER("ORG_REF_USER", "存在用户关联"),
    PERMISSION_NAME_EXISTS("PERMISSION_EXISTS", "权限名称已存在"),
    PERMISSION_EXISTS("PERMISSION_EXISTS", "权限已存在"),
    PERMS_REF_ROLE("PERMS_REF_ROLE", "存在角色关联权限"),
    PERMISSION_NOT_EXISTS("PERMISSION_NOT_EXISTS", "权限不存在"),
    ROLE_NAME_EXISTS("ROLE_EXISTS", "角色名称已存在"),
    ROLE_NOT_EXISTS("ROLE_NOT_EXISTS", "角色不存在"),
    ROLE_REF_USER("ROLE_REF_USER", "存在用户关联角色"),
    PWD_NOT_MATCH("PWD_NOT_MATCH", "密码格式不匹配[5-20]"),
    USERNAME_EXISTS("USERNAME_DUP", "用户名已存在"),
    ;

    private String code;

    private String message;

    private AdminReturnCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public AdminReturnCode getEnumByCode(String code) {
        for(AdminReturnCode value : AdminReturnCode.values()){
            if(value.getCode().equals(code)){
                return value;
            }
        }
        return null;
    }

}
