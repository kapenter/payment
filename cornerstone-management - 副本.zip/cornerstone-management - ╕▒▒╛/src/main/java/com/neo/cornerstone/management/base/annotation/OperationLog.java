package com.neo.cornerstone.management.base.annotation;

import com.neo.cornerstone.management.base.constants.OperationModule;

import java.lang.annotation.*;

/**
 *
 */
@Target({ ElementType.PARAMETER, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OperationLog {

    String remark() default "";

    /**
     * 相关参数是否加密存储
     * @return
     */
    boolean encrypt() default false;

    OperationModule operation() default OperationModule.ADMIN_DEFAULT;

}
