package com.neo.cornerstone.management.admin.model.params;

import java.util.Date;

/**
 * Title:TRolePermission<br/>
 * Description:(角色权限配置mapper参数对象)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class RolePermissionParams extends BaseParams {
    private static final long serialVersionUID = -138869464107955737L;
    /**(角色ID)*/
    private Long roleId;
    /**(权限ID)*/
    private Long permissionId;
    /**(状态 1： 有效 0：无效)*/
    private Integer state;
    /**()*/
    private Date createTime;
    /**()*/
    private Date modTime;

    public Long getRoleId(){
        return this.roleId;
    }
    public void setRoleId(Long roleId){
        this.roleId = roleId;
    }
    public Long getPermissionId(){
        return this.permissionId;
    }
    public void setPermissionId(Long permissionId){
        this.permissionId = permissionId;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getModTime(){
        return this.modTime;
    }
    public void setModTime(Date modTime){
        this.modTime = modTime;
    }



}