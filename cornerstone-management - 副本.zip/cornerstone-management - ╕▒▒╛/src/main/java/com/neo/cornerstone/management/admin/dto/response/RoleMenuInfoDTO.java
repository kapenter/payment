package com.neo.cornerstone.management.admin.dto.response;

import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.List;

/*******************************************************************************
 * Created on 2019/7/30 17:43
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class RoleMenuInfoDTO extends BaseObject {
    private static final long serialVersionUID = 4721361299757046498L;

    private Long id;
    /**(名称)*/
    private String label;
    private Long value;
    /**(状态 1： 有效 0 ： 无效)*/
    private Integer state;
    private List <RoleMenuInfoDTO> children;
    private Long parentId;
    private List<PermissionBoxDTO> permissionList;

    public List <PermissionBoxDTO> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List <PermissionBoxDTO> permissionList) {
        this.permissionList = permissionList;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public List <RoleMenuInfoDTO> getChildren() {
        return children;
    }

    public void setChildren(List <RoleMenuInfoDTO> children) {
        this.children = children;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }
}
