package com.alibaba.nacosconsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class HelloRestController {

    @Autowired
    private RestTemplate restTemplate;

    @RequestMapping("sayHello")
    public  String  sayHello(){
        return  restTemplate.getForObject("http://nacosProvider/sayHello",String.class);
    }




}
