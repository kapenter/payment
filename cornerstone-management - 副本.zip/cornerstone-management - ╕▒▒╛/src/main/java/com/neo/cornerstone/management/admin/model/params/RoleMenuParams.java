package com.neo.cornerstone.management.admin.model.params;

import java.util.Date;

/**
 * Title:TRoleMenu<br/>
 * Description:(角色菜单配置mapper参数对象)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class RoleMenuParams extends BaseParams {
    private static final long serialVersionUID = -538714942233229896L;
    /**(角色ID)*/
    private Long roleId;
    /**(菜单ID)*/
    private Long menuId;
    /**(状态1： 有效 0： 无效)*/
    private Integer state;
    /**()*/
    private Date createTime;
    /**()*/
    private Date modTime;

    public Long getRoleId(){
        return this.roleId;
    }
    public void setRoleId(Long roleId){
        this.roleId = roleId;
    }
    public Long getMenuId(){
        return this.menuId;
    }
    public void setMenuId(Long menuId){
        this.menuId = menuId;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getModTime(){
        return this.modTime;
    }
    public void setModTime(Date modTime){
        this.modTime = modTime;
    }


}