package com.neo.cornerstone.management.admin.service.common;

import com.neo.cornerstone.management.admin.mapper.UserRoleMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.UserRole;
import com.neo.cornerstone.management.admin.model.ext.UserRoleExt;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.UserRoleParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Title:TUserRoleServiceImpl<br/>
 * Description:(用户角色配置SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("userRoleService")
public class UserRoleService extends MysqlBaseServiceImpl <UserRole> {


    @Autowired
    private UserRoleMapper userRoleMapper;

    @Override
    public BaseMapper <UserRole> getBaseMapper() {
        return userRoleMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new UserRoleParams();
    }

    @Override
    public UserRole getObjectModel() {
        return new UserRole();
    }

    /**
     * 查询该用户角色对应的菜单
     * @param userId
     * @return
     */
    public List<UserRoleExt> queryRoleMenuByUserId(Long userId) {
        return userRoleMapper.queryRoleMenuByUserId(userId);
    }

    public List<UserRoleExt> queryRolePermissionByUserId(Long userId) {
        return userRoleMapper.queryRolePermissionByUserId(userId);
    }

    /**
     * 根据用户id 查询用户拥有的角色信息
     * @param userId
     * @return
     */
    public List <UserRoleExt> queryUserRoleByUserId(Long userId) {
        return userRoleMapper.queryByUserId(userId);
    }
}