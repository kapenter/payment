package com.neo.cornerstone.management.payment.feign;

import com.neo.cornerstone.management.payment.fallback.MerchantNotifyFallback;
import com.neo.payment.constant.AdminURL;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.notify.NotifyRecordRowDTO;
import com.neo.payment.dto.admin.notify.QueryTradePageRequestDTO;
import com.neo.payment.dto.admin.notify.TradeNotifyRowDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * 商户通知
 */
@FeignClient(value = "springcloud-5102-payment", fallback = MerchantNotifyFallback.class)
public interface MerchantNotifyFeign {

    @RequestMapping(value = AdminURL.QUERY_MERCHANT_NOTIFY_PAGE_LIST, method = RequestMethod.POST)
    PageResponseDTO<TradeNotifyRowDTO> queryTradePage(@RequestBody QueryTradePageRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.SEND_MERCHANT_NOTIFY, method = RequestMethod.POST)
    ResponseDTO<String> sendNotify(@RequestBody String notifyOrder);

    @RequestMapping(value = AdminURL.QUERY_MERCHANT_NOTIFY_RECORD_LIST, method = RequestMethod.POST)
    ResponseDTO<List<NotifyRecordRowDTO>> queryRecordList(@RequestBody String notifyOrder);

}
