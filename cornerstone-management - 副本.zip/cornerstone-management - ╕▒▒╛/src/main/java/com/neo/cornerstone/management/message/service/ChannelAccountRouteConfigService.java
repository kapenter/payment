package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.message.feign.ChannelAccountRouteConfigFeign;
import com.neo.cornerstone.message.dto.request.AccountRouteQueryDTO;
import com.neo.cornerstone.message.dto.request.AccountRouteRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRespDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRouteConfigRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-28 14:23
 **/
@Service
public class ChannelAccountRouteConfigService implements ChannelAccountRouteConfigFeign {

    @Autowired
    private ChannelAccountRouteConfigFeign channelAccountRouteConfigFeign;


    @Override
    public PageResponseDTO<ChannelAccountRouteConfigRespDTO> pageChannelAccountsRoute(AccountRouteQueryDTO accountRouteQueryDTO) {
        return channelAccountRouteConfigFeign.pageChannelAccountsRoute(accountRouteQueryDTO);
    }

    @Override
    public OperationResponseDTO<Boolean> addChannelAccountRoute(AccountRouteRequestDTO accountRouteRequestDTO) {
        return channelAccountRouteConfigFeign.addChannelAccountRoute(accountRouteRequestDTO);
    }

    @Override
    public OperationResponseDTO<Boolean> updateChannelAccountRoute(AccountRouteRequestDTO accountRouteRequestDTO) {
        return channelAccountRouteConfigFeign.updateChannelAccountRoute(accountRouteRequestDTO);
    }
}
