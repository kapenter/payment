package com.neo.cornerstone.management.message.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.BaseUrl;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.module.MerchantApp;
import com.neo.cornerstone.management.message.service.ChannelInfoService;
import com.neo.cornerstone.management.message.service.MerchantAppAccountService;
import com.neo.cornerstone.message.dto.request.ChannelInfoQueryDTO;
import com.neo.cornerstone.message.dto.request.ChannelInfoRequestDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountRequestDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountUpdateDTO;
import com.neo.cornerstone.message.dto.response.ChannelInfoRespDTO;
import com.neo.cornerstone.message.dto.response.MerchantAppAccountRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-22 14:32
 **/
@RestController
@RequestMapping(BaseUrl.ROOT_URL)
public class ChannelInfoController extends BaseController {

    @Autowired
    private ChannelInfoService channelInfoService;


    /**
     * 渠道管理列表查询
     * @param channelInfoQueryDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_INFO_LIST, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_CHANNEL_INFO_LIST)
    public PageModel<ChannelInfoRespDTO> pageChannelInfos(@RequestBody @Validated ChannelInfoQueryDTO channelInfoQueryDTO) {
        PageModel<ChannelInfoRespDTO>  pageModel=new PageModel<>();
        PageResponseDTO<ChannelInfoRespDTO> channelInfoRespDTOPageResponseDTO = channelInfoService.pageChannelInfos(channelInfoQueryDTO);
        pageModel.setTotalRows(channelInfoRespDTOPageResponseDTO.getTotalRow());
        pageModel.setData(channelInfoRespDTOPageResponseDTO.getData());
        return ResponseUtils.buildSuccessPageResponse(pageModel);
    }

    /**
     * 新增渠道管理配置
     * @param channelInfoRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_INFO_ADD, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_CHANNEL_INFO_ADD)
    public BaseResponse<Boolean> addChannelInfo(@RequestBody @Validated ChannelInfoRequestDTO channelInfoRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(channelInfoService.addChannelInfo(channelInfoRequestDTO));
    }



    /**
     * 修改道管理配置
     * @param channelInfoRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_INFO_UPDATE, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_CHANNEL_INFO_UPDATE)
    public BaseResponse<Boolean> updateChannelInfo(@RequestBody @Validated ChannelInfoRequestDTO channelInfoRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(channelInfoService.updateChannelInfo(channelInfoRequestDTO));
    }
}
