package com.neo.cornerstone.management.admin.controller;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import com.google.code.kaptcha.Producer;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.*;

import com.google.code.kaptcha.Constants;
import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.admin.dto.request.UserAuthDTO;
import com.neo.cornerstone.management.admin.dto.request.UserPostDTO;
import com.neo.cornerstone.management.admin.dto.request.UserPwdDTO;
import com.neo.cornerstone.management.admin.dto.response.OrgInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.RoleInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.UserInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.UserTableDTO;
import com.neo.cornerstone.management.admin.enums.AdminReturnCode;
import com.neo.cornerstone.management.admin.enums.ErrorCode;
import com.neo.cornerstone.management.admin.enums.PermissionTypeEnum;
import com.neo.cornerstone.management.admin.model.User;
import com.neo.cornerstone.management.admin.model.ext.UserRoleExt;
import com.neo.cornerstone.management.admin.service.biz.OrgBizService;
import com.neo.cornerstone.management.admin.service.biz.RoleBizService;
import com.neo.cornerstone.management.admin.service.biz.UserBizService;
import com.neo.cornerstone.management.admin.util.RSAUtil;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.exception.ParamsException;
import com.neo.cornerstone.management.base.util.ResponseUtils;

/*******************************************************************************
 * Created on 2019/7/18 13:49
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@RestController
public class UserController extends BaseController {

    @Autowired
    private UserBizService userBizService;
    @Autowired
    private OrgBizService orgBizService;
    @Autowired
    private RoleBizService roleBizService;
    @Autowired
    private Producer captchaProducer;

    @RequestMapping(value = Url.KAPTCHA_CODE, method = RequestMethod.GET)
    public void kaptcha(HttpServletRequest request, HttpServletResponse response) {
        String text = captchaProducer.createText();
        logger.info("[KAPTCHA 生成验证码 - [{}]]", text);
        BufferedImage image = captchaProducer.createImage(text);
        response.setDateHeader("Expires", 0);
        response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        response.addHeader("Cache-Control", "post-check=0, pre-check=0");
        response.setHeader("Pragma", "no-cache");
        response.setContentType("image/jpeg");
        request.getSession().setAttribute(Constants.KAPTCHA_SESSION_KEY, text);

        try {
            ServletOutputStream out = response.getOutputStream();
            ImageIO.write(image, "jpg", out);
            try {
                out.flush();
            } finally {
                out.close();
            }
        } catch (Exception e) {
            logger.error("[KAPTCHA 发送验证码异常 - [{]]]", e);
        }

    }


    /**
     * 用户修改密码
     *
     * @return
     */
    @RequestMapping(value = Url.USER_MOD_PWD, method = RequestMethod.POST)
    public BaseResponse <Boolean> pwdMod(@RequestBody @Valid UserPwdDTO userPwdDTO) throws Exception {
        String username = (String) SecurityUtils.getSubject().getPrincipal();
        logger.info("用户[{}] - 修改密码 - 开始 - info[{}]", username, userPwdDTO);
        String password = new String(RSAUtil.decryptDefault(userPwdDTO.getPassword()));
        String confirmPwd = new String(RSAUtil.decryptDefault(userPwdDTO.getConfirmPwd()));
        if (!password.equals(confirmPwd)) {
            throw new ParamsException(ErrorCode.PWD_NOT_EQUAL.getCode(), ErrorCode.PWD_NOT_EQUAL.getMessage(), null);
        }
        if (password.length() < 5 || password.length() > 20) {
            throw new ParamsException(AdminReturnCode.PWD_NOT_MATCH.getCode(), AdminReturnCode.PWD_NOT_MATCH.getMessage(), null);
        }
        userBizService.updatePwd(username, password);
        SecurityUtils.getSubject().logout();
        logger.info("用户[{}] - 修改密码 - 成功", username);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 用于用户管理页面 查询所有组织架构信息
     *
     * @return
     */
    @RequestMapping(value = Url.USER_QUERY_ORG, method = RequestMethod.GET)
    public BaseResponse<List<OrgInfoDTO>> queryUserOrg() {
        List<OrgInfoDTO> orgData = orgBizService.queryAllOrg();
        return ResponseUtils.buildSuccessResponse(orgData);
    }

    /**
     * 用户角色授权
     *
     * @param userAuthDTO
     * @return
     */
    @RequestMapping(value = Url.USER_AUTH, method = RequestMethod.POST)
    public BaseResponse<Boolean> userAuth(@RequestBody @Valid UserAuthDTO userAuthDTO) {
        this.userBizService.userAuth(userAuthDTO);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 用户用户管理页面 查询所有角色信息
     *
     * @return
     */
    @RequestMapping(value = Url.USER_QUERY_ROLES, method = RequestMethod.GET)
    public BaseResponse<List<RoleInfoDTO>> queryRoleList() {
        List<RoleInfoDTO> roleList = roleBizService.queryRoleListForSelect();
        return ResponseUtils.buildSuccessResponse(roleList);
    }

    /**
     * 查询用户分页列表信息
     *
     * @param pageNum
     * @param pageSize
     * @param username
     * @param orgId
     * @return
     */
    @RequestMapping(value = Url.QUERY_USER, method = RequestMethod.GET)
    public PageModel<UserTableDTO> queryUser(Integer pageNum, Integer pageSize, String username, Long orgId) {
        pageNum = pageNum == null || pageNum < 0 ? 0 : pageNum;
        pageSize = pageSize == null || pageSize < 0 ? 10 : pageSize;

        PageModel<UserTableDTO> userPageData = userBizService.queryUser(pageNum, pageSize, username, orgId);
        return ResponseUtils.buildSuccessPageResponse(userPageData);
    }

    /**
     * 更新用户信息
     *
     * @param id
     * @param userPostDTO
     * @return
     */
    @RequestMapping(value = Url.UPDATE_USER, method = RequestMethod.POST)
    public BaseResponse<Boolean> updateUser(@PathVariable("id") Long id, @RequestBody @Valid UserPostDTO userPostDTO) {
        Boolean result = userBizService.updateUser(id, userPostDTO);
        if (result) {
            return ResponseUtils.buildSuccessResponse(true);
        } else {
            return ResponseUtils.buildFailureResponse(false, GlobalReturnCode.UPDATE_FAILURE.getCode(),
                    GlobalReturnCode.UPDATE_FAILURE.getMessage());
        }
    }

    /**
     * 添加用户
     *
     * @param userPostDTO
     * @return
     */
    @RequestMapping(value = Url.ADD_USER, method = RequestMethod.POST)
    public BaseResponse<Boolean> createUser(@RequestBody @Valid UserPostDTO userPostDTO) {
        if (StringUtils.isBlank(userPostDTO.getUsername())) {
            throw new ParamsException(GlobalReturnCode.PARAMS_ERROR.getCode(), "登录名称不能为空");
        }
        if (userPostDTO.getUsername().length() < 5 || userPostDTO.getUsername().length() > 20) {
            throw new ParamsException(GlobalReturnCode.PARAMS_ERROR.getCode(), "用户名长度不符[5-20]");
        }
        try {
            this.userBizService.createUser(userPostDTO);
        } catch (DuplicateKeyException e) {
            throw new ParamsException(AdminReturnCode.USERNAME_EXISTS.getCode(), AdminReturnCode.USERNAME_EXISTS.getMessage());
        }

        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 密码重置
     * @return
     */
    @RequestMapping(value = Url.USER_RESET_PWD, method = RequestMethod.POST)
    public BaseResponse<Boolean> userPwdReset(@PathVariable("id") Long userId) {
        logger.info(" 用户[{}] - 重置密码 - 开始", userId);
        userBizService.userPwdReset(userId);
        logger.info(" 用户[{}] - 重置密码 - 结束 - 成功", userId);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 查询用户信息
     *
     * @return
     */
    @RequestMapping(value = Url.QUERY_USER_INFO, method = RequestMethod.GET)
    public BaseResponse<UserInfoDTO> getUserInfo() {
        String username = (String) SecurityUtils.getSubject().getPrincipal();
        User user = userBizService.queryUserByUsername(username);
        UserInfoDTO userInfoDTO = new UserInfoDTO();
        userInfoDTO.setUsername(user.getUsername());
        userInfoDTO.setName(user.getRealName());
        userInfoDTO.setEmail(user.getEmail());
        userInfoDTO.setMobile(user.getMobile());
        userInfoDTO.setAvatar(null);
        userInfoDTO.setIntroduction(null);

        List<UserRoleExt> userRoleExts = userBizService.queryUserRoleByUserId(user.getId());
        if (CollectionUtils.isNotEmpty(userRoleExts)) {
            List<String> roles = new ArrayList<>();
            for (UserRoleExt userRoleExt: userRoleExts) {
                roles.add(userRoleExt.getRoleName());
            }
            userInfoDTO.setRoles(roles);
        }
        Set<String> buttonPermission = userBizService
                .queryUserPermission(username, true, Arrays.asList(PermissionTypeEnum.BUTTON));
        userInfoDTO.setButtonPermission(new ArrayList<>(buttonPermission));

        userInfoDTO.setAsyncRouter(userBizService.queryMenuRouterList(user.getId()));
        return ResponseUtils.buildSuccessResponse(userInfoDTO);
    }
}
