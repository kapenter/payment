package com.neo.cornerstone.management.admin.enums;

/**
  * @ClassName ErrorCode
  * @Description ErrorCode
  * @Author xn024222
  * @Since 2019/1/2 18:57
  * @Version 1.0
  */
public enum AccountStateEnum {

    INVALID(0, "无效"),
    VALID(1, "有效"),
    FROZEN(2, "冻结")
    ;

    private Integer code;

    private String message;

    private AccountStateEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public AccountStateEnum getEnumByCode(Integer code) {
        for(AccountStateEnum value : AccountStateEnum.values()){
            if(value.getCode().equals(code)){
                return value;
            }
        }
        return null;
    }


}
