package com.neo.cornerstone.management.admin.mapper.base;

import com.neo.cornerstone.management.admin.model.params.BaseParams;
import org.apache.ibatis.annotations.Param;

public interface DeleteModelMapper<T> {

    int deleteById(@Param("id") Long id);

    /**
     * 根据主键删除记录
     *
     * @param id 主键
     * @return 受影响的记录数
     */
    int disableRecordById(@Param("id") Long id);

    /**
     * 根据条件删除记录
     *
     * @param params 条件
     * @return 受影响的记录数
     */
    int deleteByCondition(BaseParams params);

}
