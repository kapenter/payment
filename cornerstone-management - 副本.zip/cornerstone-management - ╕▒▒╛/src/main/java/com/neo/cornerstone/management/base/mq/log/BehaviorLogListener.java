package com.neo.cornerstone.management.base.mq.log;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.neo.cornerstone.management.base.model.BehaviorLog;
import com.neo.cornerstone.management.base.service.log.BehaviorLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.log.OperationLogService;
import com.neo.msplatform.framework.utils.rocketmq.listener.impl.RocketMqMessageListener;

/**
 *
 */
@Component
public class BehaviorLogListener implements RocketMqMessageListener, ApplicationContextAware {

    protected static final Logger logger = LoggerFactory.getLogger(BehaviorLogListener.class);
    @Autowired
    private BehaviorLogService behaviorLogService;

    private ApplicationContext applicationContext;
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public boolean onMessage(List<MessageExt> messages, ConsumeConcurrentlyContext consumeConcurrentlyContext) {
        logger.info("MQ: Behavior Log  ,message size:{}-----------", messages.size());
        if (messages.size() > 1) {
            logger.error("MQ: Behavior Log , not support multi message");
            return false;
        }

        try {
            String messageBody = new String(messages.get(0).getBody(), "UTF-8");
            BehaviorLog behaviorLog = JSON.parseObject(messageBody, BehaviorLog.class);
            logger.info("MQ: Behavior Log - 开始处理[{}]", behaviorLog);
            behaviorLogService.saveBehaviorLog(behaviorLog);
        } catch (UnsupportedEncodingException e) {
            logger.error("MQ: Behavior Log , Save with error ", e);
            return false;
        }
        return true;
    }
}
