package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.message.feign.MailChannelAccountFeign;
import com.neo.cornerstone.message.dto.request.MailAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.MailAccountRequestDTO;
import com.neo.cornerstone.message.dto.response.MailAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-03 16:31
 **/
@Service
public class MailChannelAccountService  {


    @Autowired
    private MailChannelAccountFeign mailChannelAccountFeign;


    public PageResponseDTO<MailAccountRespDTO> pageMailChannelAccounts(MailAccountQueryDTO mailAccountQueryDTO) {
        return mailChannelAccountFeign.pageMailChannelAccounts(mailAccountQueryDTO);
    }

    public OperationResponseDTO<Boolean> addMailChannelAccount(MailAccountRequestDTO mailAccountRequestDTO) {
        return mailChannelAccountFeign.addMailChannelAccount(mailAccountRequestDTO);
    }

    public OperationResponseDTO<Boolean> updateMailChannelAccount(MailAccountRequestDTO mailAccountRequestDTO) {
        return mailChannelAccountFeign.updateMailChannelAccount(mailAccountRequestDTO);
    }
}
