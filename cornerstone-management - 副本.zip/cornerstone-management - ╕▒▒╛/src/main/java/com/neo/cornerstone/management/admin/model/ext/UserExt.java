package com.neo.cornerstone.management.admin.model.ext;

import com.neo.cornerstone.management.admin.model.User;

import java.util.List;

/*******************************************************************************
 * Created on 2019/7/30 11:36
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class UserExt extends User {
    private static final long serialVersionUID = -604828936668232027L;
    private String orgName;

    List<UserRoleExt> roleList;

    public List <UserRoleExt> getRoleList() {
        return roleList;
    }

    public void setRoleList(List <UserRoleExt> roleList) {
        this.roleList = roleList;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
}
