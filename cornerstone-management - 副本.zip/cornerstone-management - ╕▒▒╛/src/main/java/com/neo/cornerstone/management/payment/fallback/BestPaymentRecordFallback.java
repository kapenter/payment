/*******************************************************************************
 * Create on 2019/9/2 17:39
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.fallback;

import com.neo.cornerstone.management.payment.feign.BestPaymentRecordFeign;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.best.BestPaymentRowDTO;
import com.neo.payment.dto.admin.best.QueryBestPageRequestDTO;
import com.neo.payment.dto.admin.best.QuotaPaymentRowDTO;
import com.neo.payment.dto.admin.best.SetBestFailRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Component
public class BestPaymentRecordFallback implements BestPaymentRecordFeign {
    private static Logger logger = LoggerFactory.getLogger(BestPaymentRecordFallback.class);

    @Override
    public PageResponseDTO<BestPaymentRowDTO> queryBestPage(QueryBestPageRequestDTO requestDTO) {
        logger.error("[分页查询限额拆单原始记录] [fallback] 查询限额拆单原始记录列表失败，调用远程服务失败");
        return PageResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> syncBestResult(String platformOrder) {
        logger.error("[同步限额拆单原始记录结果] [fallback] 同步限额拆单原始记录结果失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> setBestFail(SetBestFailRequestDTO requestDTO) {
        logger.error("[限额拆单原始记录置为失败] [fallback] 交易操作失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<List<QuotaPaymentRowDTO>> queryQuotaList(String tradeOrder) {
        logger.error("[查询限额拆单记录] [fallback] 查询拆单记录失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败", Collections.emptyList());
    }

}
