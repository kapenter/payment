package com.neo.cornerstone.management.admin.model;

import com.neo.cornerstone.management.base.dto.BaseObject;

/**
 * Title:TRole<br/>
 * Description:(角色实体类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class Role extends BaseModel {
    private static final long serialVersionUID = -2971015877032787558L;
    /**(名称)*/
    private String name;
    /**(状态1：有效 0 ： 无效)*/
    private Integer state;
    /**()*/
    private java.util.Date createTime;
    /**()*/
    private java.util.Date modTime;

    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public java.util.Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(java.util.Date createTime){
        this.createTime = createTime;
    }
    public java.util.Date getModTime(){
        return this.modTime;
    }
    public void setModTime(java.util.Date modTime){
        this.modTime = modTime;
    }

}