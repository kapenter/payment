package com.neo.cornerstone.management.merchant.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.merchant.constants.MerchantUrl;
import com.neo.cornerstone.management.merchant.service.BusinessConfigClient;
import com.neo.cornerstone.management.merchant.util.ResponseTransferUtil;
import com.neo.cornerstone.merchant.serve.define.dto.BusinessConfigDTO;
import com.neo.cornerstone.merchant.serve.define.dto.BusinessConfigQueryParam;
import com.neo.cornerstone.merchant.serve.define.dto.BusinessPermissionParam;
import com.neo.cornerstone.merchant.serve.define.dto.BusinessQueryParam;
import com.neo.cornerstone.merchant.serve.define.dto.PageResponseDTO;
import com.neo.cornerstone.merchant.serve.define.dto.ResponseDTO;
import com.neo.payment.exception.ValidateException;
import com.neo.payment.util.ValidateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

import static com.neo.cornerstone.management.base.enums.GlobalReturnCode.ARGUMENT_MISSING;

/**
 * @Description:业务权限
 * @Author: yanyiwei
 * @Date: 2019/08/26
 */
@Controller
public class BusinessConfigController extends BaseController {

    @Autowired
    private BusinessConfigClient businessConfigClient;

    /**
     * 功能描述: 业务权限分页
     * @param: [pageNum, pageSize, groupName, url]
     * @return:
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.PAGE_BUSINESS_CONFIG)
    @ResponseBody
    public PageModel<BusinessConfigDTO> pageBusinessConfig(Integer pageNum, Integer pageSize, String groupName, String url) {
        BusinessConfigQueryParam pageQueryParam = new BusinessConfigQueryParam(pageNum, pageSize, groupName, url);
        PageResponseDTO<BusinessConfigDTO> pageResponseDTO = businessConfigClient.pageBusinessConfig(pageQueryParam);
        PageModel<BusinessConfigDTO> objectPageModel = new PageModel<>();
        objectPageModel.setTotalRows(pageResponseDTO.getTotalRows());
        objectPageModel.setData(pageResponseDTO.getData());
        return ResponseUtils.buildSuccessPageResponse(objectPageModel);
    }

    /**
     * 功能描述:业务权限添加
     * @param: [businessConfigDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.ADD_BUSINESS_CONFIG)
    @ResponseBody
    @OperationLog(operation = OperationModule.MERCHANT_BUSINESS_CONFIG_ADD)
    public BaseResponse addBusinessConfig(@RequestBody BusinessConfigDTO businessConfigDTO) {
        try {
            logger.info("[添加业务权限]-参数:{}", businessConfigDTO);
            ValidateUtil.validate(businessConfigDTO);
            ResponseDTO responseDTO = businessConfigClient.addBusinessConfig(businessConfigDTO);
            return ResponseTransferUtil.transferResponse(responseDTO);
        } catch (ValidateException e) {
            logger.error("[添加业务权限]-参数校验错误", e);
            return ResponseUtils.buildFailureResponse(null, ARGUMENT_MISSING.getCode(), e.getMessage());
        } catch (Exception e) {
            logger.error("[添加业务权限]-异常", e);
            return ResponseUtils.buildFailureResponse(null);
        }
    }

    /**
     * 功能描述: 业务权限更新
     * @param: [businessConfigDTO]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.UPDATE_BUSINESS_CONFIG)
    @ResponseBody
    @OperationLog(operation = OperationModule.MERCHANT_BUSINESS_CONFIG_UPDATE)
    public BaseResponse updateBusinessConfig(@RequestBody BusinessConfigDTO businessConfigDTO) {
        logger.info("[业务权限更新]-参数:{}", businessConfigDTO);
        ResponseDTO responseDTO = businessConfigClient.updateBusinessConfig(businessConfigDTO);
        logger.info("[业务权限更新]-结果:{}", businessConfigDTO);
        return ResponseTransferUtil.transferResponse(responseDTO);
    }

    /**
     * 功能描述:获取商户业务权限列表
     * @param: [appId]
     * @return:
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.GET_BUSINESS_CONFIG_LIST)
    @ResponseBody
    public BaseResponse<List<BusinessConfigDTO>> getBusinessConfigList(@RequestParam("appId") String appId) {
        BusinessQueryParam businessQueryParam = new BusinessQueryParam();
        businessQueryParam.setAppId(appId);
        List<BusinessConfigDTO> merchantInfoList = businessConfigClient.getBusinessConfigList(businessQueryParam);
        return ResponseUtils.buildSuccessResponse(merchantInfoList);
    }

    /**
     * 功能描述:更新商户业务权限
     * @param: [businessPermissionParam]
     * @return: com.neo.cornerstone.management.base.dto.BaseResponse
     * @author yanyiwei
     * @date 2019/9/4
     */
    @RequestMapping(value = MerchantUrl.UPDATE_BUSINESS_PERMISSION)
    @ResponseBody
    @OperationLog(operation = OperationModule.MERCHANT_AUTH_CONFIG_UPDATE)
    public BaseResponse updateBusinessPermission(@RequestBody BusinessPermissionParam businessPermissionParam) {
        logger.info("[更新商户业务权限]-入参:{}", businessPermissionParam);
        businessConfigClient.updateBusinessPermission(businessPermissionParam);
        return ResponseUtils.buildSuccessResponse(null);
    }

}
