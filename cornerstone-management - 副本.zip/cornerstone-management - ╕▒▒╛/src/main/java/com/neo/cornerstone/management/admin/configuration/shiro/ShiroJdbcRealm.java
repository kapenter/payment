package com.neo.cornerstone.management.admin.configuration.shiro;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.neo.cornerstone.management.admin.enums.ErrorCode;
import com.neo.cornerstone.management.admin.exception.KaptchaException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import com.neo.cornerstone.management.admin.constants.GlobalConfig;
import com.neo.cornerstone.management.admin.enums.AccountStateEnum;
import com.neo.cornerstone.management.admin.enums.PermissionTypeEnum;
import com.neo.cornerstone.management.admin.enums.StateEnum;
import com.neo.cornerstone.management.admin.exception.UserIllegalStateException;
import com.neo.cornerstone.management.admin.model.User;
import com.neo.cornerstone.management.admin.model.ext.UserRoleExt;
import com.neo.cornerstone.management.admin.model.params.UserParams;
import com.neo.cornerstone.management.admin.service.biz.UserBizService;
import com.neo.cornerstone.management.admin.service.common.UserRoleService;
import com.neo.cornerstone.management.admin.service.common.UserService;

/*******************************************************************************
 * Created on 2019/8/9 16:31
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class ShiroJdbcRealm extends AuthorizingRealm {

    Logger logger = LoggerFactory.getLogger(ShiroJdbcRealm.class);

    @Lazy
    @Autowired
    private UserService userService;
    @Lazy
    @Autowired
    private UserRoleService userRoleService;
    @Lazy
    @Autowired
    private UserBizService userBizService;

    /**
     * 验证权限相关信息
     * @param principalCollection
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        String username = (String) SecurityUtils.getSubject().getPrincipal();
        logger.info("获取用户权限信息 - 开始 - 用户[{}]", username);
        UserParams userParams = new UserParams();
        userParams.setUsername(username);
        User user = userService.queryByCondition(userParams);
        Set<String> userRoleSet = queryUserRole(user.getId());
        Set<String> userPermissionSet = userBizService.queryUserPermission(username, false,
                Arrays.asList(PermissionTypeEnum.values()));

        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo(userRoleSet);
        info.setStringPermissions(userPermissionSet);
        logger.info("获取用户权限信息 - 结束 - 用户[{}]", username);
        return info;
    }

    private Set<String> queryUserRole(Long userId) {
        List<UserRoleExt> userRoleExtS = userRoleService.queryUserRoleByUserId(userId);
        Set<String> roleSet = new TreeSet<>();
        if (CollectionUtils.isNotEmpty(userRoleExtS)) {
            for (UserRoleExt userRoleExt : userRoleExtS) {
                roleSet.add(userRoleExt.getRoleName());
            }
        }
        return roleSet;
    }

    /**
     * 验证身份相关信息
     * @param authenticationToken
     * @return
     * @throws AuthenticationException
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken)
            throws AuthenticationException {
        MGTUsernamePasswordToken token = (MGTUsernamePasswordToken) authenticationToken;
        Object kaptcha = token.getKaptcha();
        String postCaptcha = token.getPostKaptcha();
        if (null == kaptcha) {
            throw new KaptchaException( ErrorCode.KAPTCHA_ERROR.getMessage());
        }
        if (!kaptcha.equals(postCaptcha)) {
            throw new KaptchaException( ErrorCode.KAPTCHA_ERROR.getMessage());
        }

        String username = (String) authenticationToken.getPrincipal();
        logger.info("获取用户认证信息 - 开始 - 用户[{}]", username);
        if (null == username) {
            throw new AccountException("null username not allowed");
        }

        UserParams userParams = new UserParams();
        userParams.setUsername(username);
        userParams.setState(StateEnum.VALID.getCode());
        User user = userService.queryByCondition(userParams);

        if (null == user || AccountStateEnum.INVALID.getCode().equals(user.getAccountState())) {
            throw new UnknownAccountException("can not found account for username[" + username + "]");
        }

        if (AccountStateEnum.FROZEN.getCode().equals(user.getAccountState())) {
            throw new UserIllegalStateException("当前账户为冻结状态 - 用户 [" + username + "]");
        }
        String pwd = user.getPwd();
        ByteSource salt = ByteSource.Util.bytes(username.substring(0, GlobalConfig.hashPreStringCount));
        SimpleAuthenticationInfo info = new SimpleAuthenticationInfo(username, pwd, salt, getName());
        logger.info("获取用户认证信息 - 结束 - 用户[{}] - 信息[{}]", username, info);
        return info;
    }

}
