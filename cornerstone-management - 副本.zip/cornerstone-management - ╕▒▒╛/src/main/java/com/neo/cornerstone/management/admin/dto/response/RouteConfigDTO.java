package com.neo.cornerstone.management.admin.dto.response;

import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.List;
public class RouteConfigDTO extends BaseObject {
    private static final long serialVersionUID = -4874215879713871382L;
    private String path;
    private String name;
    private String component;
    private String redirect;
    private String alias;
    private List<RouteConfigDTO> children;
    private RouteConfigMetaDTO meta;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public String getRedirect() {
        return redirect;
    }

    public void setRedirect(String redirect) {
        this.redirect = redirect;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public List<RouteConfigDTO> getChildren() {
        return children;
    }

    public void setChildren(List<RouteConfigDTO> children) {
        this.children = children;
    }

    public RouteConfigMetaDTO getMeta() {
        return meta;
    }

    public void setMeta(RouteConfigMetaDTO meta) {
        this.meta = meta;
    }
}
