package com.neo.cornerstone.management.message.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.BaseUrl;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.service.ChannelAccountRouteConfigService;
import com.neo.cornerstone.management.message.service.ChannelInfoService;
import com.neo.cornerstone.management.message.service.MerchantAppAccountService;
import com.neo.cornerstone.message.dto.request.AccountRouteQueryDTO;
import com.neo.cornerstone.message.dto.request.AccountRouteRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRouteConfigRespDTO;
import com.neo.cornerstone.message.dto.response.ChannelInfoRespDTO;
import com.neo.cornerstone.message.dto.response.MerchantAppAccountRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-28 14:00
 **/
@RestController
@RequestMapping(BaseUrl.ROOT_URL)
public class ChannelAccountRouteConfigController {

    @Autowired
    private ChannelAccountRouteConfigService  channelAccountRouteConfigService;

    @Autowired
    private ChannelInfoService channelInfoService;

    @Autowired
    private MerchantAppAccountService merchantAppAccountService;

    /**
     * 渠道管理列表查询
     * @param channelAccountRouteQueryDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_ROUTE_LIST, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_CHANNEL_ACCOUNT_ROUTE_LIST)
    public PageModel<ChannelAccountRouteConfigRespDTO> pageChannelInfos(@RequestBody @Validated AccountRouteQueryDTO channelAccountRouteQueryDTO) {
        PageModel<ChannelAccountRouteConfigRespDTO>  pageModel=new PageModel<>();
        PageResponseDTO<ChannelAccountRouteConfigRespDTO> channelAccountRespDTOPageResponseDTO = channelAccountRouteConfigService.pageChannelAccountsRoute(channelAccountRouteQueryDTO);
        pageModel.setTotalRows(channelAccountRespDTOPageResponseDTO.getTotalRow());
        List<ChannelAccountRouteConfigRespDTO> listConfig=channelAccountRespDTOPageResponseDTO.getData();
        List<ChannelInfoRespDTO> channels= channelInfoService.allChannelInfos();
        List<MerchantAppAccountRespDTO> merchantApps= merchantAppAccountService.allMerchantAppAccount();

        for (ChannelAccountRouteConfigRespDTO channelAccountRouteConfig:listConfig){
            //设置channelName
            for (ChannelInfoRespDTO  channelInfo:channels){
                if(channelAccountRouteConfig.getChannelCode().equals(channelInfo.getChannelCode())){
                    channelAccountRouteConfig.setChannelName(channelInfo.getChannelName());
                }
            }
            //设置应用账号名称
            for (MerchantAppAccountRespDTO merchantApp:merchantApps){
                if(channelAccountRouteConfig.getAppAccNo().equals(merchantApp.getAppAccNo())){
                    channelAccountRouteConfig.setAppAccName(merchantApp.getAppAccName());
                }
            }
        }
        pageModel.setData(listConfig);
        return ResponseUtils.buildSuccessPageResponse(pageModel);
    }

    /**
     * 新增渠道管理配置
     * @param channelAccountRouteRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_ROUTE_ADD, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_CHANNEL_ACCOUNT_ROUTE_ADD)
    public BaseResponse<Boolean> addChannelAccountRoute(@RequestBody @Validated AccountRouteRequestDTO channelAccountRouteRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(channelAccountRouteConfigService.addChannelAccountRoute(channelAccountRouteRequestDTO));
    }



    /**
     * 修改道管理配置
     * @param channelAccountRouteRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_ROUTE_UPDATE, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_CHANNEL_ACCOUNT_ROUTE_UPDATE)
    public BaseResponse<Boolean> updateChannelAccountRoute(@RequestBody @Validated AccountRouteRequestDTO channelAccountRouteRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(channelAccountRouteConfigService.updateChannelAccountRoute(channelAccountRouteRequestDTO));
    }
}
