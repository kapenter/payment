package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.MailChannelAccountFeign;
import com.neo.cornerstone.management.message.resp.BaseRespDTO;
import com.neo.cornerstone.message.dto.request.MailAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.MailAccountRequestDTO;
import com.neo.cornerstone.message.dto.response.MailAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 16:08
 **/
@Component
@Slf4j
public class MailChannelAccountFallbackFactory implements FallbackFactory<MailChannelAccountFeign> {


    @Override
    public MailChannelAccountFeign create(Throwable throwable) {
        return new MailChannelAccountFeign() {
            @Override
            public PageResponseDTO<MailAccountRespDTO> pageMailChannelAccounts(MailAccountQueryDTO mailAccountQueryDTO) {
                log.error("[fallback]---[消息管理]---[邮件管理]---[渠道账户]---[pageMailChannelAccounts]列表异常,msg:{},cause:",throwable.getMessage(),throwable);
                PageResponseDTO<MailAccountRespDTO> pageResponseDTO=new PageResponseDTO<>();
                pageResponseDTO.setReturnCode(BizCodeEnum.MAIL_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION.getCode());
                pageResponseDTO.setReturnMsg(BizCodeEnum.MAIL_PAGE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION.getMessage());
                return pageResponseDTO;
            }

            @Override
            public OperationResponseDTO<Boolean> addMailChannelAccount(MailAccountRequestDTO mailAccountRequestDTO) {
                log.error("[fallback]---[消息管理]---[邮件管理]---[渠道账户]---[addChannelAccount]新增异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.MAIL_ADD_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION);
            }

            @Override
            public OperationResponseDTO<Boolean> updateMailChannelAccount(MailAccountRequestDTO mailAccountRequestDTO) {
                log.error("[fallback]---[消息管理]---[邮件管理]---[渠道账户]---[updateMailChannelAccount]修改异常,msg:{},cause:",throwable.getMessage(),throwable);
                return BaseRespDTO.failureOperationRespDTO(BizCodeEnum.MAIL_UPDATE_CHANNEL_ACCOUNT_FALLBACK_EXCEPTION);
            }
        };
    }
}
