package com.neo.cornerstone.management.base.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

/*******************************************************************************
 * Created on 2019/7/18 13:48
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class BaseResponse<T> extends BaseObject {

    private Integer status;

    private String returnCode;

    private String returnMsg;

    private T data;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnMsg() {
        return returnMsg;
    }

    public void setReturnMsg(String returnMsg) {
        this.returnMsg = returnMsg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
