package com.neo.cornerstone.management.merchant.util;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.merchant.serve.define.constants.FeignResponseEnum;
import com.neo.cornerstone.merchant.serve.define.dto.ResponseDTO;

/**
 * @Description:
 * @Author: yanyiwei
 * @Date: 2019/09/10
 */
public class ResponseTransferUtil {

    public static BaseResponse transferResponse(ResponseDTO responseDTO) {
        if (responseDTO == null) {
            return ResponseUtils.buildFailureResponse(null);
        }
        if (responseDTO.getCode().equals(FeignResponseEnum.SUCCESS.code())) {
            return ResponseUtils.buildSuccessResponse(null);
        } else {
            return ResponseUtils.buildFailureResponse(responseDTO.getData(), responseDTO.getCode(), responseDTO.getMsg());
        }
    }
}
