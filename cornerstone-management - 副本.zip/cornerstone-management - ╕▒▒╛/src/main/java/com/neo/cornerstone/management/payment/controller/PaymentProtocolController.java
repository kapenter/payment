/*******************************************************************************
 * Create on 2019/9/2 17:45
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.controller;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.payment.constant.URL;
import com.neo.cornerstone.management.payment.service.PaymentProtocolService;
import com.neo.cornerstone.management.payment.vo.protocol.QueryPageRequestVO;
import com.neo.cornerstone.management.payment.vo.protocol.UnbindRequestVO;
import com.neo.payment.dto.admin.protocol.ProtocolRowDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@RestController
public class PaymentProtocolController {
    @Autowired
    private PaymentProtocolService paymentProtocolService;

    @RequestMapping(path = URL.PAYMENT_PROTOCOL_PAGE_LIST)
    public PageModel<ProtocolRowDTO> queryPage(@RequestBody QueryPageRequestVO requestVO) {
        return paymentProtocolService.queryPage(requestVO);
    }

    @RequestMapping(path = URL.UNBIND_PAYMENT_PROTOCOL)
    public BaseResponse<Long> unbind(@RequestBody UnbindRequestVO requestVO) {
        return paymentProtocolService.unbind(requestVO);
    }

}
