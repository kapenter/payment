package com.neo.cornerstone.management.admin.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.List;

/*******************************************************************************
 * Created on 2019/7/30 17:48
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class RolePermissionInfoDTO extends BaseObject {
    private static final long serialVersionUID = 4721361299757046498L;
    private List<Long> permissionList;
        private List<RoleMenuInfoDTO> roleMenu;

    public List <Long> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List <Long> permissionList) {
        this.permissionList = permissionList;
    }

    public List <RoleMenuInfoDTO> getRoleMenu() {
        return roleMenu;
    }

    public void setRoleMenu(List <RoleMenuInfoDTO> roleMenu) {
        this.roleMenu = roleMenu;
    }
}
