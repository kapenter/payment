package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;

import javax.validation.constraints.NotNull;
import java.util.List;

/*******************************************************************************
 * Created on 2019/7/30 15:31
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class UserAuthDTO extends BaseObject {
    private static final long serialVersionUID = 3693608007164506862L;

    @NotNull(message = "授权用户不能为空")
    private Long id;
    private List <Long> roles;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List <Long> getRoles() {
        return roles;
    }

    public void setRoles(List <Long> roles) {
        this.roles = roles;
    }
}
