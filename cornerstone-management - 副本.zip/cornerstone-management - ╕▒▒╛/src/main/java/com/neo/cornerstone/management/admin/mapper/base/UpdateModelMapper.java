package com.neo.cornerstone.management.admin.mapper.base;

import org.apache.ibatis.annotations.Param;

public interface UpdateModelMapper<T> {

    /**
     * 通过主键更新数据【必须设置主键】
     *
     * @param model 更新数据
     * @return 受影响的记录数
     */
    int updateById(T model);

    // /**
    // * 通过条件更新数据
    // * @param model
    // * @return
    // */
    // int updateMany(T model);

    /**
     * 根据主键使记录无效
     *
     * @param id 主键
     * @return 受影响的记录数
     */
    int disableRecordById(@Param("id") Long id);

    /**
     * 根据主键恢复记录有效
     *
     * @param id 主键
     * @return 受影响的记录数
     */
    int enableRecordById(@Param("id") Long id);

}
