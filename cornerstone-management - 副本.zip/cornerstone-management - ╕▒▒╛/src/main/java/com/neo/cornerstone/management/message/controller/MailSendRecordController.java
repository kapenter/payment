package com.neo.cornerstone.management.message.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.BaseUrl;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.service.MailSendRecordService;
import com.neo.cornerstone.message.dto.request.MailSendRecordQueryDTO;
import com.neo.cornerstone.message.dto.response.MailSendRecordRespDTO;
import com.neo.cornerstone.message.dto.response.MessageSendLogRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-03 17:14
 **/
@RestController
@RequestMapping(BaseUrl.ROOT_URL)
public class MailSendRecordController {



    @Autowired
    private MailSendRecordService mailSendRecordService;

    /**
     * 渠道管理列表查询
     * @param mailSendRecordQueryDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MAIL_SEND_LOG_LIST, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MAIL_SEND_RECORD_LIST)
    public PageModel<MessageSendLogRespDTO> pageMailSendRecords(@RequestBody @Validated MailSendRecordQueryDTO mailSendRecordQueryDTO) {
        PageModel<MailSendRecordRespDTO>  pageModel=new PageModel<>();
        PageResponseDTO<MailSendRecordRespDTO> messageSendLogRespDTOPageResponseDTO = mailSendRecordService.pageMailSendRecords(mailSendRecordQueryDTO);
        pageModel.setTotalRows(messageSendLogRespDTOPageResponseDTO.getTotalRow());
        pageModel.setData(messageSendLogRespDTOPageResponseDTO.getData());
        return ResponseUtils.buildSuccessPageResponse(pageModel);
    }


}
