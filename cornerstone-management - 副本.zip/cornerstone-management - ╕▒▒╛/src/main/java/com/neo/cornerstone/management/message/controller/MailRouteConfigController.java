package com.neo.cornerstone.management.message.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.BaseUrl;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.service.ChannelInfoService;
import com.neo.cornerstone.management.message.service.MailRouteConfigService;
import com.neo.cornerstone.management.message.service.MerchantAppAccountService;
import com.neo.cornerstone.message.dto.request.MailAccountRouteConfigQueryDTO;
import com.neo.cornerstone.message.dto.request.MailRouteConfigRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelInfoRespDTO;
import com.neo.cornerstone.message.dto.response.MailRouteConfigRespDTO;
import com.neo.cornerstone.message.dto.response.MerchantAppAccountRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-03 16:36
 **/
@RestController
@RequestMapping(BaseUrl.ROOT_URL)
public class MailRouteConfigController {


    @Autowired
    private ChannelInfoService channelInfoService;

    @Autowired
    private MerchantAppAccountService merchantAppAccountService;
    @Autowired
    private MailRouteConfigService mailRouteConfigService;

    /**
     * 渠道管理列表查询
     * @param mailAccountRouteConfigQueryDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MAIL_ROUTE_CONFIG_LIST, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MAIL_ROUTE_CONFIG_LIST)
    public PageModel<MailRouteConfigRespDTO> pageChannelInfos(@RequestBody @Validated MailAccountRouteConfigQueryDTO mailAccountRouteConfigQueryDTO) {
        PageModel<MailRouteConfigRespDTO>  pageModel=new PageModel<>();
        PageResponseDTO<MailRouteConfigRespDTO> channelAccountRespDTOPageResponseDTO = mailRouteConfigService.pageMailAccountRouteConfig(mailAccountRouteConfigQueryDTO);

        List<MailRouteConfigRespDTO> listConfig=channelAccountRespDTOPageResponseDTO.getData();
        List<ChannelInfoRespDTO> channels= channelInfoService.allChannelInfos();
        List<MerchantAppAccountRespDTO> merchantApps= merchantAppAccountService.allMerchantAppAccount();

        for (MailRouteConfigRespDTO mailRouteConfigRespDTO:listConfig){
            //设置channelName
            for (ChannelInfoRespDTO  channelInfo:channels){
                if(mailRouteConfigRespDTO.getChannelCode().equals(channelInfo.getChannelCode())){
                    mailRouteConfigRespDTO.setChannelName(channelInfo.getChannelName());
                }
            }
            //设置应用账号名称
            for (MerchantAppAccountRespDTO merchantApp:merchantApps){
                if(mailRouteConfigRespDTO.getAppAccNo().equals(merchantApp.getAppAccNo())){
                    mailRouteConfigRespDTO.setAppAccName(merchantApp.getAppAccName());
                }
            }
        }
        pageModel.setTotalRows(channelAccountRespDTOPageResponseDTO.getTotalRow());
        pageModel.setData(channelAccountRespDTOPageResponseDTO.getData());
        return ResponseUtils.buildSuccessPageResponse(pageModel);
    }

    /**
     * 新增渠道管理配置
     * @param mailRouteConfigRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MAIL_ROUTE_CONFIG_ADD, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MAIL_ROUTE_CONFIG_ADD)
    public BaseResponse<Boolean> addMailAccountRouteConfig(@RequestBody @Validated MailRouteConfigRequestDTO mailRouteConfigRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(mailRouteConfigService.addMailAccountRouteConfig(mailRouteConfigRequestDTO));
    }



    /**
     * 修改道管理配置
     * @param mailRouteConfigRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MAIL_ROUTE_CONFIG_UPDATE, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MAIL_ROUTE_CONFIG_UPDATE)
    public BaseResponse<Boolean> updateMailAccountRouteConfig(@RequestBody @Validated MailRouteConfigRequestDTO mailRouteConfigRequestDTO) {
        return ResponseUtils.getBooleanBaseResponse(mailRouteConfigService.updateMailAccountRouteConfig(mailRouteConfigRequestDTO));
    }


}
