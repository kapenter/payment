package com.neo.cornerstone.management.admin.controller;

import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.admin.dto.response.UserInfoDTO;
import com.neo.cornerstone.management.admin.exception.KaptchaException;
import com.neo.cornerstone.management.admin.exception.UserIllegalStateException;
import com.neo.cornerstone.management.base.constants.GlobalConfigConstant;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.enums.BehaviorResult;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.log.SendLogService;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.UUID;

@RestController
public class FilterController extends BaseController {

    @Autowired
    private SendLogService sendLogService;

    @RequestMapping(value = Url.USER_LOGOUT_SUCCESS)
    public BaseResponse logoutSuccess(HttpServletRequest request) {
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_LOG_OUT)
                .setOperationResult(BehaviorResult.SUCCESS.getCode());
        operationLog.setUsername((String) request.getAttribute(GlobalConfigConstant.USERNAME));
        request.removeAttribute(GlobalConfigConstant.USERNAME);
        request.getSession().removeAttribute(GlobalConfigConstant.ACCESS_TOKEN);
        sendLogService.sendOperationLog(operationLog, false);
        return ResponseUtils.buildSuccessResponse(null);
    }

    /**
     * 未登录
     * @return
     */
    @RequestMapping(value = Url.USER_LOGIN_OFF)
    public BaseResponse loginStatusOff() {
        return ResponseUtils.buildSuccessResponse(null, GlobalReturnCode.LOGIN_STATUS_OFF.getCode(),
                GlobalReturnCode.LOGIN_STATUS_OFF.getMessage());
    }

    /**
     *   * 当post loginUrl时候会被shiro 拦截，当登录成功会直接跳转到 success,当登录失败会继续往前执行，
     *      * 到 loginUrl 的controller.
     * @param request
     * @return
     */
    @RequestMapping(value = Url.USER_LOGIN)
    public BaseResponse loginFailure(HttpServletRequest request) {
        // 参考 FormAuthenticationFilter setFailureAttribute();
        String errorClassName = (String) request.getAttribute("shiroLoginFailure");
        Object username = request.getAttribute("username");
        OperationLog operationLog = OperationLog.init().setError(errorClassName);
        operationLog.setUsername(username == null ? null: (String) username);
        try {
            if (UserIllegalStateException.class.getName().equals(errorClassName)) {
                operationLog.setRemark("当前用户冻结状态");
                return ResponseUtils.buildSuccessResponse(null, GlobalReturnCode.USER_FORBIDDEN.getCode(), GlobalReturnCode.USER_FORBIDDEN.getMessage());
            } else if (KaptchaException.class.getName().equals(errorClassName)) {
                operationLog.setRemark("验证码错误");
                return ResponseUtils.buildSuccessResponse(null, GlobalReturnCode.KAPTCHA_ERROR.getCode(), GlobalReturnCode.KAPTCHA_ERROR.getMessage());
            } else {
                operationLog.setRemark("帐号或密码错误");
                return ResponseUtils.buildSuccessResponse(null, GlobalReturnCode.LOGIN_FAILURE.getCode(), GlobalReturnCode.LOGIN_FAILURE.getMessage());
            }
        } finally {
            sendLogService.sendOperationLog(operationLog, OperationModule.ADMIN_LOG_IN_FAILURE, BehaviorResult.ERROR);
        }
    }

    /**
     *  用户登录成功
     * @param request
     * @return
     */
    @RequestMapping(value = Url.USER_LOGIN_SUCCESS)
    //public BaseResponse<UserInfoDTO> logInSuccess(@RequestBody @Valid UserLoginDTO userLoginDTO, HttpServletRequest request) {
    public BaseResponse<UserInfoDTO> logInSuccess(HttpServletRequest request) {
        UserInfoDTO userInfoDTO = new UserInfoDTO();
        String token = UUID.randomUUID().toString();
        userInfoDTO.setAccessToken(token);
        request.getSession().setAttribute(GlobalConfigConstant.ACCESS_TOKEN,token);
        request.setAttribute(GlobalConfigConstant.USERNAME, SecurityUtils.getSubject().getPrincipal());
        OperationLog operationLog = OperationLog.init().setRemark(userInfoDTO.getAccessToken());
        sendLogService.sendOperationLog(operationLog, OperationModule.ADMIN_LOG_IN_SUCCESS, BehaviorResult.SUCCESS);
        return ResponseUtils.buildSuccessResponse(userInfoDTO);
    }

    /**
     * shiro 认证无权限
     * @return
     */
    @RequestMapping(value = Url.SHIRO_NO_AUTH)
    public BaseResponse noAuth() {
        return ResponseUtils.buildSuccessResponse(null, GlobalReturnCode.UN_AUTHORIZED.getCode(),
                GlobalReturnCode.UN_AUTHORIZED.getMessage());
    }

}
