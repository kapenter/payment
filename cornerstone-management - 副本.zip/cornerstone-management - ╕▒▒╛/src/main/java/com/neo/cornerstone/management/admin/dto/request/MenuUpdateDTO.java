package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

public class MenuUpdateDTO extends BaseObject {
    private static final long serialVersionUID = 2095664271400759514L;

    @NotEmpty(message = "菜单名称不能为空")
    @Length(max = 150, message = "菜单名称长度不符")
    private String name;
    @NotEmpty(message = "菜单URL不能为空")
    @Length(max = 200, message = "菜单URL不符")
    private String url;
    @NotEmpty(message = "路由参数不能为空")
    private String parameter;
    @NotNull(message = "状态不能为空")
    private Integer state;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }
}
