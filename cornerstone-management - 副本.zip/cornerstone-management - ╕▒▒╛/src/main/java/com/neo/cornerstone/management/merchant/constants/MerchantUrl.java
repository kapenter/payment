package com.neo.cornerstone.management.merchant.constants;

import com.neo.cornerstone.management.base.constants.BaseUrl;

/*******************************************************************************
 * Created on 2019/7/18 13:52
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public interface MerchantUrl {

    /**商户管理**/
    String PAGE_MERCHANT_INFO = BaseUrl.ROOT_URL + "merchant/pageMerchantInfo";
    String GET_MERCHANT_INFO_LIST = BaseUrl.ROOT_URL + "merchant/getMerchantInfoList";
    String ADD_MERCHANT_INFO = BaseUrl.ROOT_URL + "merchant/addMerchantInfo";
    String UPDATE_MERCHANT_INFO = BaseUrl.ROOT_URL + "merchant/updateMerchantInfo";

    /**商户账户**/
    String PAGE_MERCHANT_APP = BaseUrl.ROOT_URL + "merchant/pageMerchantApp";
    String ADD_MERCHANT_APP = BaseUrl.ROOT_URL + "merchant/addMerchantApp";
    String UPDATE_MERCHANT_APP = BaseUrl.ROOT_URL + "merchant/updateMerchantApp";

    /**系统配置**/
    String PAGE_SYSTEM_INFO = BaseUrl.ROOT_URL + "merchant/pageSystemInfo";
    String GET_SYSTEM_INFO_LIST = BaseUrl.ROOT_URL + "merchant/getSystemInfoList";
    String ADD_SYSTEM_INFO = BaseUrl.ROOT_URL + "merchant/addSystemInfo";
    String UPDATE_SYSTEM_INFO = BaseUrl.ROOT_URL + "merchant/updateSystemInfo";

    /**业务权限**/
    String PAGE_BUSINESS_CONFIG = BaseUrl.ROOT_URL + "merchant/pageBusinessConfig";
    String GET_BUSINESS_CONFIG_LIST = BaseUrl.ROOT_URL + "merchant/getBusinessConfigList";
    String ADD_BUSINESS_CONFIG = BaseUrl.ROOT_URL + "merchant/addBusinessConfig";
    String UPDATE_BUSINESS_CONFIG = BaseUrl.ROOT_URL + "merchant/updateBusinessConfig";
    String UPDATE_BUSINESS_PERMISSION = BaseUrl.ROOT_URL + "merchant/updateBusinessPermission";

    /**商户权限**/
    String PAGE_APP_AUTH_CONFIG = BaseUrl.ROOT_URL + "merchant/pageAppAuthConfig";
    String ADD_APP_AUTH_CONFIG = BaseUrl.ROOT_URL + "merchant/addAppAuthConfig";
    String UPDATE_APP_AUTH_CONFIG = BaseUrl.ROOT_URL + "merchant/updateAppAuthConfig";

}


