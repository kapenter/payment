package com.neo.cornerstone.management.base.util;

import javax.servlet.http.HttpServletRequest;

/*******************************************************************************
 * Created on 2019/7/2 15:54
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class IpUtils {

    public static String getRemoteIpAddr(HttpServletRequest request) {

        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null) {
            String[] arr$ = ip.split(",");
            int len$ = arr$.length;
            for(int i$ = 0; i$ < len$; ++i$) {
                String _ip = arr$[i$];
                if (_ip != null && !"unknown".equalsIgnoreCase(_ip)) {
                    ip = _ip;
                    break;
                }
            }
        } else {
            ip = "unknown";
        }
        return ip;
    }
}
