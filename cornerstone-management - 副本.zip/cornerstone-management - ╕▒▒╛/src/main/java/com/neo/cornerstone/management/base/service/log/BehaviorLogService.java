package com.neo.cornerstone.management.base.service.log;

import com.baomidou.mybatisplus.plugins.Page;
import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.admin.model.Menu;
import com.neo.cornerstone.management.admin.model.Permission;
import com.neo.cornerstone.management.admin.service.common.MenuService;
import com.neo.cornerstone.management.admin.service.common.PermissionService;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.model.BehaviorLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.msplatform.framework.mongodb.MongoService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*******************************************************************************
 * Created on 2019/8/26 18:25
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Service("behaviorLogService")
public class BehaviorLogService extends BaseService {

    @Autowired
    private MongoService mongoService;
    @Autowired
    private PermissionService permissionService;
    @Autowired
    private MenuService menuService;

    private PathMatcher pathMatcher = new AntPathMatcher();

    private Map<String, String> otherPermissionMap;

    @PostConstruct
    public void init() {
        otherPermissionMap = new HashMap <>();
        otherPermissionMap.put(Url.KAPTCHA_CODE, "获取验证码");
        otherPermissionMap.put(Url.USER_LOGIN, "请求登录");
        otherPermissionMap.put(Url.USER_LOGIN_SUCCESS, "登录成功");
        otherPermissionMap.put(Url.USER_LOGOUT, "退出登录");
        otherPermissionMap.put(Url.USER_MOD_PWD, "用户修改密码");
        otherPermissionMap.put(Url.QUERY_USER_INFO, "查询用户信息");
        otherPermissionMap.put(Url.USER_LOGOUT_SUCCESS, "退出登录成功");
        otherPermissionMap.put(Url.USER_LOGIN_OFF, "未登录");
    }

    public void saveBehaviorLog(BehaviorLog behaviorLog) {

        Permission matchedPermission = null;
        List <Permission> permissionList = permissionService.queryAllPermissionByCache();
        if (CollectionUtils.isNotEmpty(permissionList)) {
            for (Permission permission: permissionList) {
                if (pathMatcher.match(permission.getPermission(), behaviorLog.getUrl())) {
                    matchedPermission = permission;
                    break;
                }
            }
        }
        if (matchedPermission != null) {
            behaviorLog.setOperationContent(matchedPermission.getName());
            Menu menu = menuService.queryById(matchedPermission.getMenuId());
            if (null != menu) {
                behaviorLog.setSubMenuType(menu.getName());
                behaviorLog.setMenuType(dealMenuData("[" + menu.getName() + "]", menu.getParentId()));
            }
        } else {
            behaviorLog.setRemark(otherPermissionMap.get(behaviorLog.getUrl()));
        }
        if (StringUtils.isBlank(behaviorLog.getUsername())) {
            behaviorLog.setUsername("未登录");
        }
        mongoService.insert(behaviorLog);
    }

    private String dealMenuData(String menuData, Long menuId) {
        Menu menu = menuService.queryById(menuId);
        if (null != menu) {
            menuData = "[" + menu.getName() + "]" + menuData;
            if (menu.getParentId() != null && menu.getParentId() != 0) {
                menuData = dealMenuData(menuData, menu.getParentId());
            }
        }
        return menuData;
    }

    /**
     *
     * @param pageNum
     * @param pageSize
     * @param bizId
     * @param username
     * @return
     */
    public PageModel <BehaviorLog> queryPage(Integer pageNum, Integer pageSize, String bizId, String username) {
        BehaviorLog params = new BehaviorLog();
        params.setUsername(username);
        params.setBizId(bizId);
        Sort sort = new Sort(Sort.Direction.DESC, "createTime");
        Page <BehaviorLog> pageData = mongoService.selectPage(pageNum, pageSize, params, sort, BehaviorLog.class);
        PageModel<BehaviorLog> pageModel = new PageModel<>();
        if (pageData != null && CollectionUtils.isNotEmpty(pageData.getRecords())) {
            pageModel.setTotalRows(pageData.getTotal());
            pageModel.setData(pageData.getRecords());
        }
        return pageModel;
    }

}
