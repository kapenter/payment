package com.neo.cornerstone.management.admin.configuration.shiro;

import com.neo.cornerstone.management.admin.constants.GlobalConfig;
import com.neo.cornerstone.management.admin.constants.Url;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authz.permission.PermissionResolver;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;
import java.util.HashMap;
import java.util.Map;

/*******************************************************************************
 * Created on 2019/8/9 16:30
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Configuration
public class ShiroConfig {

    @Bean(name = "shiroFilter")
    public ShiroFilterFactoryBean shiroFilter(SecurityManager securityManager) {
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        Map <String, Filter> shiroFilter = shiroFilterFactoryBean.getFilters();
        shiroFilter.put("authc", formAuthenticationFilter());
        shiroFilter.put("perms", permissionsAuthorizationFilter());
        shiroFilter.put("logout", logoutFilter());

        shiroFilterFactoryBean.setSecurityManager(securityManager);
        shiroFilterFactoryBean.setLoginUrl(Url.USER_LOGIN);
        shiroFilterFactoryBean.setSuccessUrl(Url.USER_LOGIN_SUCCESS);
        shiroFilterFactoryBean.setUnauthorizedUrl(Url.SHIRO_NO_AUTH);
        Map <String, String> filterChainDefinitionMap = new HashMap <>();
        // Url配置需要按顺序
        // authc:认证通过才可以访问; anon:可以匿名访
        filterChainDefinitionMap.put(Url.USER_LOGOUT, "logout");
        filterChainDefinitionMap.put(Url.USER_LOGIN_SUCCESS, "authc");
        filterChainDefinitionMap.put(Url.USER_MOD_PWD, "authc");
        filterChainDefinitionMap.put(Url.USER_LOGIN, "authc");
        filterChainDefinitionMap.put(Url.QUERY_USER_INFO, "authc");
        filterChainDefinitionMap.put(Url.SHIRO_NO_AUTH, "anon");
        filterChainDefinitionMap.put(Url.KAPTCHA_CODE, "anon");
        filterChainDefinitionMap.put(Url.USER_LOGOUT_SUCCESS, "anon");
        filterChainDefinitionMap.put(Url.USER_LOGIN_OFF, "anon");
        filterChainDefinitionMap.put("/**", "authc,perms");


        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
        return shiroFilterFactoryBean;
    }

    public MGTLogoutFilter logoutFilter() {
        MGTLogoutFilter logoutFilter = new MGTLogoutFilter();
        logoutFilter.setRedirectUrl(Url.USER_LOGOUT_SUCCESS);
        return logoutFilter;
    }

    /**
     * 不能使用 @Bean  会导致 FilterChain 链路混乱，重复验证
     * @return
     */
    public MGTPermissionFilter permissionsAuthorizationFilter() {
        MGTPermissionFilter permissionsAuthorizationFilter = new MGTPermissionFilter();
        permissionsAuthorizationFilter.setUnLoginUrl(Url.USER_LOGIN_OFF);
        return permissionsAuthorizationFilter;
    }

    /**
     * 不能使用 @Bean  会导致 FilterChain 链路混乱，重复验证
     * @return
     */
    public MGTAuthenticationFilter formAuthenticationFilter() {
        MGTAuthenticationFilter formAuthenticationFilter = new MGTAuthenticationFilter();
        formAuthenticationFilter.setUnLoginUrl(Url.USER_LOGIN_OFF);
        return formAuthenticationFilter;
    }

    @Bean
    public SecurityManager securityManager() {
        DefaultWebSecurityManager defaultSecurityManager = new DefaultWebSecurityManager();
        defaultSecurityManager.setRealm(jdbcRealm());
        return defaultSecurityManager;
    }
    @Bean
    public ShiroJdbcRealm jdbcRealm() {
        ShiroJdbcRealm jdbcRealm = new ShiroJdbcRealm();
        jdbcRealm.setCredentialsMatcher(hashedCredentialsMatcher());
        jdbcRealm.setPermissionResolver(permissionResolver());
        return jdbcRealm;
    }

    @Bean
    public PermissionResolver permissionResolver() {
        return new MGTPermissionResolver();
    }

    @Bean
    public HashedCredentialsMatcher hashedCredentialsMatcher() {
        MGTHashedCredentialsMatcher matcher = new MGTHashedCredentialsMatcher();
        matcher.setHashAlgorithmName(GlobalConfig.hashAlgorithmName);
        matcher.setHashIterations(GlobalConfig.hashIterations);
        matcher.setStoredCredentialsHexEncoded(true);
        return matcher;
    }

}
