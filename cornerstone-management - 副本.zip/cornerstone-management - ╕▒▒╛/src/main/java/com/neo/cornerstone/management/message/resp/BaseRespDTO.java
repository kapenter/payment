package com.neo.cornerstone.management.message.resp;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import lombok.Data;

/**
 * @program: loanmkt-product
 * @description:
 * @author: xn086532
 * @create: 2019-07-24 14:39
 **/

@Data
public class BaseRespDTO {

    public static OperationResponseDTO<Boolean> failureOperationRespDTO(BizCodeEnum bizCodeEnum){
        OperationResponseDTO<Boolean> operationResponseDTO=new OperationResponseDTO<>();
        operationResponseDTO.setReturnCode(bizCodeEnum.getCode());
        operationResponseDTO.setReturnMsg(bizCodeEnum.getMessage());
        operationResponseDTO.setData(false);
        return operationResponseDTO;
    }

}
