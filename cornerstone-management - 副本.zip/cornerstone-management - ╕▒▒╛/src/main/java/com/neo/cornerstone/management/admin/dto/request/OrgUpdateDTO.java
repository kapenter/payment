package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

public class OrgUpdateDTO extends BaseObject {
    private static final long serialVersionUID = 2095664271400759514L;

    @NotEmpty(message = "组织名称不能为空")
    @Length(max = 150, message = "组织名称长度不符")
    private String name;
    @NotNull(message = "状态不能为空")
    private Integer state;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}
