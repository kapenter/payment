/*******************************************************************************
 * Create on 2019/9/9 15:31
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.vo.notify;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Setter
@Getter
@ToString
public class QueryTradePageRequestVO implements Serializable {
    private static final long serialVersionUID = 3867115199106348765L;

    private String appId;
    private String tradeOrder;
    private String platformOrder;
    private Integer tradeType;
    private Integer tradeState;

    private int pageNum;
    private int pageSize;
    private int totalCount;

}
