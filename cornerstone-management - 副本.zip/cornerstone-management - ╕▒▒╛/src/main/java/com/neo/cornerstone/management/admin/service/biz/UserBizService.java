package com.neo.cornerstone.management.admin.service.biz;

import com.alibaba.fastjson.JSON;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.admin.dto.request.UserAuthDTO;
import com.neo.cornerstone.management.admin.dto.request.UserPostDTO;
import com.neo.cornerstone.management.admin.dto.response.RouteConfigDTO;
import com.neo.cornerstone.management.admin.dto.response.UserTableDTO;
import com.neo.cornerstone.management.admin.enums.AccountPwdStateEnum;
import com.neo.cornerstone.management.admin.enums.AdminReturnCode;
import com.neo.cornerstone.management.admin.enums.PermissionTypeEnum;
import com.neo.cornerstone.management.admin.enums.StateEnum;
import com.neo.cornerstone.management.admin.model.*;
import com.neo.cornerstone.management.admin.model.ext.RoleMenuExt;
import com.neo.cornerstone.management.admin.model.ext.RolePermissionExt;
import com.neo.cornerstone.management.admin.model.ext.UserExt;
import com.neo.cornerstone.management.admin.model.ext.UserRoleExt;
import com.neo.cornerstone.management.admin.model.params.OrganizationParams;
import com.neo.cornerstone.management.admin.model.params.UserParams;
import com.neo.cornerstone.management.admin.model.params.UserRoleParams;
import com.neo.cornerstone.management.admin.service.common.OrganizationService;
import com.neo.cornerstone.management.admin.service.common.RoleService;
import com.neo.cornerstone.management.admin.service.common.UserRoleService;
import com.neo.cornerstone.management.admin.service.common.UserService;
import com.neo.cornerstone.management.admin.util.PwdUtil;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.BehaviorResult;
import com.neo.cornerstone.management.base.exception.BizRuntimeException;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.cornerstone.management.base.service.log.SendLogService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/*******************************************************************************
 * Created on 2019/7/18 18:38
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 *****************************************************************************
 * @author xn082184*/
@Service("userBizService")
public class UserBizService extends BaseService {

    @Autowired
    private UserService userService;
    @Autowired
    private OrganizationService organizationService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private UserRoleService userRoleService;
    @Autowired
    private UserBizService userBizService;
    @Autowired
    private SendLogService sendLogService;

    public void updatePwd(String username, String password) {
        User user = null;
        User updateUser = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_USER_PWD_MOD).setOperationParams(username);
        try {
            UserParams userParams = new UserParams();
            userParams.setUsername(username);
            user = userService.queryByCondition(userParams);

            updateUser = new User();
            updateUser.setPwd(PwdUtil.encryptPwd(username, password));
            updateUser.setPwdState(AccountPwdStateEnum.NORMAL.getCode());
            updateUser.setModTime(new Date());
            updateUser.setId(user.getId());
            userService.updateById(updateUser);

            operationLog.setRemark(username)
                    .setSnapshot(JSON.toJSONString(updateUser))
                    .setOriginalSnapshot(JSON.toJSONString(user))
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
        } catch (Exception e) {
            operationLog.setRemark(username)
                    .setSnapshot(JSON.toJSONString(updateUser))
                    .setOriginalSnapshot(JSON.toJSONString(user))
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, true);
        }

    }

    /**
     * 通过用户查询角色信息
     * @param userId
     * @return
     */
    public List<UserRoleExt> queryUserRoleByUserId(Long userId) {
        UserRoleParams userRoleParams = new UserRoleParams();
        userRoleParams.setUserId(userId);
        List<UserRoleExt> userRoleExts = userRoleService.queryUserRoleByUserId(userId);
        return userRoleExts;
    }

    /**
     * 查询用户信息
     * @param username
     * @return
     */
    public User queryUserByUsername(String username) {
        UserParams userParams = new UserParams();
        userParams.setUsername(username);
        return userService.queryByCondition(userParams);
    }

    /**
     * 查询用户权限
     * @param username
     * @param ignoreSuffix
     * @param permissionTypes
     * @return
     */
    public Set <String> queryUserPermission(String username, boolean ignoreSuffix, List<PermissionTypeEnum> permissionTypes) {
        UserParams userParams = new UserParams();
        userParams.setUsername(username);
        User user = userService.queryByCondition(userParams);
        List <UserRoleExt> userRoleExtList = userRoleService.queryRolePermissionByUserId(user.getId());
        Set <String> permissionSet = new TreeSet <>();

        List<RolePermissionExt> permissionList = new ArrayList <>();
        if (CollectionUtils.isNotEmpty(userRoleExtList)) {
            for (UserRoleExt userRoleExt: userRoleExtList) {
                permissionList.addAll(userRoleExt.getRolePermissionExtList());
            }
        }

        for (RolePermissionExt rolePermissionExt: permissionList) {
            Permission permission = rolePermissionExt.getPermission();
            PermissionTypeEnum permissionType = PermissionTypeEnum.getEnumByCode(permission.getType());
            if (null == permissionType) {
                throw new IllegalArgumentException("user [" + username + "] with permission by error permission type");
            }
            if (StateEnum.VALID.getCode().equals(permission.getState())) {
                if (permissionTypes.contains(permissionType)) {
                    if (!ignoreSuffix) {
                        permissionSet.add(permissionType.getPermissionType().concat(permission.getPermission()));
                    } else {
                        permissionSet.add(permission.getPermission());
                    }
                }
            }
        }
        return permissionSet;
    }

    /**
     * 获取用户拥有角色对应的菜单的配置信息
     * @param userId
     * @return
     */
    public List<RouteConfigDTO> queryMenuRouterList(Long userId) {
        List<UserRoleExt> userRoleDataList = userRoleService.queryRoleMenuByUserId(userId);
        List<RoleMenuExt> roleMenuDataList = getRoleMenuDataList(userRoleDataList);
        List<Menu> rootMenuList = dealRoleMenu(1, 0L, roleMenuDataList);
        Set<Long> menuIdSet = new TreeSet <>();
        return dealMenuRouterList(rootMenuList, roleMenuDataList, menuIdSet);
    }

    /**
     * 处理菜单路由信息
     * @param menuDataList
     * @param roleMenuDataList
     * @return
     */
    private List<RouteConfigDTO> dealMenuRouterList(List<Menu> menuDataList, List<RoleMenuExt> roleMenuDataList, Set<Long> menuIdSet) {
        List<RouteConfigDTO> routerList = null;
        if (CollectionUtils.isNotEmpty(menuDataList)) {
            routerList = new ArrayList<>();
            for (Menu menu: menuDataList) {
                if (StateEnum.VALID.getCode().equals(menu.getState())) {
                    RouteConfigDTO routeConfigDTO = JSON.parseObject(menu.getParameter(), RouteConfigDTO.class);
                    routeConfigDTO.setPath(menu.getUrl());
                    List<Menu> subMenuList = dealRoleMenu(menu.getLevel() + 1, menu.getId(), roleMenuDataList);
                    if (CollectionUtils.isNotEmpty(subMenuList)) {
                        List <RouteConfigDTO> subChildren = dealMenuRouterList(subMenuList, roleMenuDataList, menuIdSet);
                        routeConfigDTO.setChildren(subChildren);
                    }
                    if (!menuIdSet.contains(menu.getId())) {
                        routerList.add(routeConfigDTO);
                        menuIdSet.add(menu.getId());
                    }

                }
            }
        }
        return routerList;
    }

    /**
     * 获取角色对应的所有菜单信息
     * @param userRoleDataList
     * @return
     */
    private List<RoleMenuExt> getRoleMenuDataList(List<UserRoleExt> userRoleDataList) {
        List<RoleMenuExt> roleMenuDataList = null;
        if (CollectionUtils.isNotEmpty(userRoleDataList)) {
            roleMenuDataList = new ArrayList<>();
            for (UserRoleExt userRoleExt: userRoleDataList) {
                roleMenuDataList.addAll(userRoleExt.getRoleMenuExtList());
            }
        }
        return roleMenuDataList;
    }

    /**
     * 获取满足当前层级的子菜单信息
     * @param level
     * @param parentId
     * @param roleMenuDataList
     * @return
     */
    private List<Menu> dealRoleMenu(int level, Long parentId, List<RoleMenuExt> roleMenuDataList) {
        List<Menu> subRoleMenuDataList = null;
        if (CollectionUtils.isNotEmpty(roleMenuDataList)) {
            subRoleMenuDataList = new ArrayList<>();
            for (RoleMenuExt roleMenuExt : roleMenuDataList) {
                if (roleMenuExt.getMenu() != null && roleMenuExt.getMenu().getLevel() == level && roleMenuExt.getMenu().getParentId().equals(parentId)) {
                    subRoleMenuDataList.add(roleMenuExt.getMenu());
                }
            }
        }
        return subRoleMenuDataList;
    }

    /**
     * 用户角色授权
     *
     * @param userAuthDTO
     * @return
     */
    public Boolean userAuth(UserAuthDTO userAuthDTO) {
        User user = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_USER_AUTH).setOperationParams(JSON.toJSONString(userAuthDTO));
        try {
            user = userService.queryById(userAuthDTO.getId());
            if (user == null) {
                throw new BizRuntimeException(AdminReturnCode.USER_NOT_EXISTS.getCode(), AdminReturnCode.USER_NOT_EXISTS.getMessage());
            }
            String roleName = "";
            if (CollectionUtils.isNotEmpty(userAuthDTO.getRoles())) {
                for (Long roleId : userAuthDTO.getRoles()) {
                    Role role = roleService.queryById(roleId);
                    if (role == null) {
                        throw new BizRuntimeException(AdminReturnCode.ROLE_NOT_EXISTS.getCode(), AdminReturnCode.ROLE_NOT_EXISTS.getMessage());
                    }
                    roleName.concat(",").concat(role.getName());
                }
            }
            updateUserRole(userAuthDTO, roleName);
            operationLog.setRemark(user.getUsername())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
            return true;
        } catch (Exception e) {
            operationLog.setRemark(user == null ? "" : user.getUsername())
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }

    private void updateUserRole(UserAuthDTO userAuthDTO, String roleName) {
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_MENU_UPDATE).setOperationParams(JSON.toJSONString(userAuthDTO));
        try {
            UserRoleParams userRoleParams = new UserRoleParams();
            userRoleParams.setUserId(userAuthDTO.getId());
            userRoleService.deleteByCondition(userRoleParams);
            // 当 roleIdList 为空则表示清空当前权限
            if (CollectionUtils.isNotEmpty(userAuthDTO.getRoles())) {
                List<UserRole> dataList = new ArrayList<>();
                for (Long roleId : userAuthDTO.getRoles()) {
                    UserRole userRole = new UserRole();
                    userRole.setCreateTime(new Date());
                    userRole.setRoleId(roleId);
                    userRole.setState(StateEnum.VALID.getCode());
                    userRole.setUserId(userAuthDTO.getId());
                    dataList.add(userRole);
                }
                userRoleService.saveListModel(dataList);
            }
            operationLog.setRemark(StringUtils.isBlank(roleName) ? "移除": roleName)
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
        } catch (Exception e) {
            operationLog.setRemark(userAuthDTO.getId() + "")
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }

    }

    /**
     * 更新用户
     *
     * @param id
     * @param userPostDTO
     * @return
     */
    public Boolean updateUser(Long id, UserPostDTO userPostDTO) {
        User userData = null;
        User updateParams = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_USER_UPDATE).setOperationParams(id + JSON.toJSONString(userPostDTO));
        try {
            userData = userService.queryById(id);
            if (userData == null) {
                throw new BizRuntimeException(AdminReturnCode.USER_NOT_EXISTS.getCode(), AdminReturnCode.USER_NOT_EXISTS.getMessage());
            }

            Organization orgData = organizationService.queryById(userPostDTO.getOrgId());
            if (orgData == null) {
                throw new BizRuntimeException(AdminReturnCode.ORG_NOT_EXISTS.getCode(), AdminReturnCode.ORG_NOT_EXISTS.getMessage());
            }
           /* OrganizationParams organizationParams = new OrganizationParams();
            organizationParams.setParentId(orgData.getId());
            List<Organization> subList = organizationService.queryListByCondition(organizationParams);
            if (CollectionUtils.isNotEmpty(subList)) {
                throw new BizRuntimeException(AdminReturnCode.ORG_ERROR.getCode(), AdminReturnCode.ORG_ERROR.getMessage());
            }*/

            updateParams = new User();
            updateParams.setId(id);
            updateParams.setRealName(userPostDTO.getRealName());
            updateParams.setEmail(userPostDTO.getEmail());
            updateParams.setMobile(userPostDTO.getMobile());
            updateParams.setPwdState(userPostDTO.getPwdState());
            updateParams.setAccountState(userPostDTO.getAccountState());
            updateParams.setModTime(new Date());
            updateParams.setOrgId(userPostDTO.getOrgId());
            Boolean result = userService.updateById(updateParams);
            operationLog.setRemark(userData.getUsername())
                    .setSnapshot(JSON.toJSONString(updateParams))
                    .setOriginalSnapshot(JSON.toJSONString(userData))
                    .setOperationResult(result ? BehaviorResult.SUCCESS.getCode() : BehaviorResult.FAILURE.getCode());

            return result;
        } catch (Exception e) {
            operationLog.setRemark(id + "")
                    .setSnapshot(JSON.toJSONString(updateParams))
                    .setOriginalSnapshot(JSON.toJSONString(userData))
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, true);
        }
    }

    /**
     * 查询用户分页列表信息
     *
     * @param pageNum
     * @param pageSize
     * @param username
     * @param orgId
     * @return
     */
    public PageModel<UserTableDTO> queryUser(Integer pageNum, Integer pageSize, String username, Long orgId) {
        UserParams request = new UserParams();
//        request.setUsername(username);
        request.setPatternName(username);
        request.setOrgId(orgId);
        request.setPageSize(pageSize);
        request.setPageNum(pageNum);
        PageModel<UserExt> pageData = userService.queryPageExt(request);
        PageModel<UserTableDTO> responsePageData = new PageModel<>();
        responsePageData.setTotalRows(0);
        if (pageData != null && CollectionUtils.isNotEmpty(pageData.getData())) {
            responsePageData.setTotalRows(pageData.getTotalRows());
            List<UserTableDTO> responseDataList = new ArrayList<>();
            for (UserExt userExt : pageData.getData()) {
                UserTableDTO tableDTO = new UserTableDTO();
                tableDTO.setUsername(userExt.getUsername());
                tableDTO.setState(userExt.getState());
                tableDTO.setId(userExt.getId());
                tableDTO.setAccountState(userExt.getAccountState());
                tableDTO.setEmail(userExt.getEmail());
                tableDTO.setMobile(userExt.getMobile());
                tableDTO.setPwdState(userExt.getPwdState());
                tableDTO.setRealName(userExt.getRealName());
                tableDTO.setOrgName(userExt.getOrgName());
                tableDTO.setOrgId(userExt.getOrgId());
                tableDTO.setCreateTime(userExt.getCreateTime());
                tableDTO.setModTime(userExt.getModTime());
                if (CollectionUtils.isNotEmpty(userExt.getRoleList())) {
                    List<String> roleList = new ArrayList<>();
                    List<Long> roleIdList = new ArrayList<>();
                    for (UserRoleExt userRoleExt : userExt.getRoleList()) {
                        roleList.add(userRoleExt.getRoleName());
                        roleIdList.add(userRoleExt.getRoleId());
                    }
                    tableDTO.setRoleList(roleList);
                    tableDTO.setRoleIdList(roleIdList);
                }
                responseDataList.add(tableDTO);
            }
            responsePageData.setData(responseDataList);
        }
        return responsePageData;
    }

    /**
     * 创建用户
     *
     * @param userPostDTO
     * @return
     */
    public Boolean createUser(UserPostDTO userPostDTO) {
        User user = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_USER_ADD).setOperationParams(JSON.toJSONString(userPostDTO));
        try {
            String username = userPostDTO.getUsername();
            user = new User();
            user.setUsername(username);

            user.setPwd(PwdUtil.encryptPwd(username, username));
            user.setRealName(userPostDTO.getRealName());
            user.setEmail(userPostDTO.getEmail());
            user.setMobile(userPostDTO.getMobile());
            user.setCreateTime(new Date());
            user.setOrgId(userPostDTO.getOrgId());
            user.setState(StateEnum.VALID.getCode());
            user.setPwdState(userPostDTO.getPwdState());
            user.setAccountState(userPostDTO.getAccountState());
            userService.saveModel(user);

            operationLog.setRemark(userPostDTO.getUsername())
                    .setSnapshot(JSON.toJSONString(user))
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
            return true;
        } catch (Exception e) {
            operationLog.setRemark(userPostDTO.getUsername())
                    .setSnapshot(JSON.toJSONString(user))
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, true);
        }

    }

    /**
     * 重置密码
     * @param userId
     * @return
     */
    public Boolean userPwdReset(Long userId) {
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_USER_PWD_RESET);
        try {
            User user = userService.queryById(userId);
            if (null == user) {
                logger.error("用户[{{}] - 重置密码 - 用户不存在", userId);
                throw new BizRuntimeException(AdminReturnCode.USER_NOT_EXISTS.getCode(), AdminReturnCode.USER_NOT_EXISTS.getMessage());
            }
            operationLog.setOperationParams(user.getUsername());

            User updateParams = new User();
            updateParams.setId(userId);
            updateParams.setPwd(PwdUtil.encryptPwd(user.getUsername(), user.getUsername()));
            updateParams.setPwdState(AccountPwdStateEnum.INIT.getCode());
            updateParams.setModTime(new Date());
            userService.updateById(updateParams);

            operationLog.setRemark(user.getUsername())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
            return true;
        } catch (Exception e) {
            operationLog.setRemark(userId + "")
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }

    }
}
