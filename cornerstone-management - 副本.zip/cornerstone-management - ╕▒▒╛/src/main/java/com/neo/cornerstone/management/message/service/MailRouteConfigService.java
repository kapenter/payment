package com.neo.cornerstone.management.message.service;

import com.neo.cornerstone.management.message.feign.MailRouteConfigFeign;
import com.neo.cornerstone.message.dto.request.MailAccountRouteConfigQueryDTO;
import com.neo.cornerstone.message.dto.request.MailRouteConfigRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRouteConfigRespDTO;
import com.neo.cornerstone.message.dto.response.MailRouteConfigRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-03 16:41
 **/
@Service
public class MailRouteConfigService  {


    @Autowired
    private MailRouteConfigFeign mailRouteConfigFeign;


    public PageResponseDTO<MailRouteConfigRespDTO> pageMailAccountRouteConfig(MailAccountRouteConfigQueryDTO mailAccountRouteConfigQueryDTO) {
        return mailRouteConfigFeign.pageMailAccountRouteConfig(mailAccountRouteConfigQueryDTO);
    }

    public OperationResponseDTO<Boolean> addMailAccountRouteConfig(MailRouteConfigRequestDTO mailRouteConfigRequestDTO) {
        return mailRouteConfigFeign.addMailAccountRouteConfig(mailRouteConfigRequestDTO);
    }

    public OperationResponseDTO<Boolean> updateMailAccountRouteConfig(MailRouteConfigRequestDTO mailRouteConfigRequestDTO) {
        return mailRouteConfigFeign.updateMailAccountRouteConfig(mailRouteConfigRequestDTO);
    }
}
