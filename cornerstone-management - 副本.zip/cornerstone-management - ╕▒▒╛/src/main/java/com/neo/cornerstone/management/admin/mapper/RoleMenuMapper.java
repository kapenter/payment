package com.neo.cornerstone.management.admin.mapper;

import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.RoleMenu;
import com.neo.cornerstone.management.admin.model.ext.RoleMenuExt;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * Title:TRoleMenuMapper<br/>
 * Description:(角色菜单配置mapper接口)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public interface RoleMenuMapper extends BaseMapper <RoleMenu> {

    RoleMenuExt queryByRoleId(@Param("roleId") Long roleId);
}
