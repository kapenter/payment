package com.neo.cornerstone.management.admin.model.params;

import java.util.Date;

/**
 * Title:TOrganization<br/>
 * Description:(组织架构mapper参数对象)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class OrganizationParams extends BaseParams {
    private static final long serialVersionUID = -5094812341479388277L;
    /**(名称)*/
    private String name;
    /**(父级)*/
    private Long parentId;
    /**(层级)*/
    private Integer level;
    /**(状态 1：有效 0： 无效)*/
    private Integer state;
    /**()*/
    private Date createTime;
    /**()*/
    private Date modTime;

    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Long getParentId(){
        return this.parentId;
    }
    public void setParentId(Long parentId){
        this.parentId = parentId;
    }
    public Integer getLevel(){
        return this.level;
    }
    public void setLevel(Integer level){
        this.level = level;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getModTime(){
        return this.modTime;
    }
    public void setModTime(Date modTime){
        this.modTime = modTime;
    }


}