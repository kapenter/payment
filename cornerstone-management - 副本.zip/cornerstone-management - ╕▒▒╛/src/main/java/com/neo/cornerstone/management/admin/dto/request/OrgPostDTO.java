package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/*******************************************************************************
 * Created on 2019/7/26 11:06
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class OrgPostDTO extends BaseObject {
    private static final long serialVersionUID = 3370274866281517146L;

    @NotNull(message = "父级关联组织不能为空")
    private Long parentId;
    @NotEmpty(message = "组织名称不能为空")
    @Length(max = 150, message = "组织名称长度不符")
    private String name;
    @NotNull(message = "状态不能为空")
    private Integer state;

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
