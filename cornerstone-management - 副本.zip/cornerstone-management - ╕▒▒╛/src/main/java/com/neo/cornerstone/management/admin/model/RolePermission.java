package com.neo.cornerstone.management.admin.model;

import com.neo.cornerstone.management.base.dto.BaseObject;

/**
 * Title:TRolePermission<br/>
 * Description:(角色权限配置实体类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public class RolePermission extends BaseModel {
    private static final long serialVersionUID = 7448060222561341109L;
    /**(角色ID)*/
    private Long roleId;
    /**(权限ID)*/
    private Long permissionId;
    /**(状态 1： 有效 0：无效)*/
    private Integer state;
    /**()*/
    private java.util.Date createTime;
    /**()*/
    private java.util.Date modTime;

    public Long getRoleId(){
        return this.roleId;
    }
    public void setRoleId(Long roleId){
        this.roleId = roleId;
    }
    public Long getPermissionId(){
        return this.permissionId;
    }
    public void setPermissionId(Long permissionId){
        this.permissionId = permissionId;
    }
    public Integer getState(){
        return this.state;
    }
    public void setState(Integer state){
        this.state = state;
    }
    public java.util.Date getCreateTime(){
        return this.createTime;
    }
    public void setCreateTime(java.util.Date createTime){
        this.createTime = createTime;
    }
    public java.util.Date getModTime(){
        return this.modTime;
    }
    public void setModTime(java.util.Date modTime){
        this.modTime = modTime;
    }

}