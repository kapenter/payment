package com.neo.cornerstone.management.admin.service.biz;

import com.alibaba.fastjson.JSON;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.admin.dto.request.RoleAuthDTO;
import com.neo.cornerstone.management.admin.dto.request.RolePostDTO;
import com.neo.cornerstone.management.admin.dto.response.*;
import com.neo.cornerstone.management.admin.enums.AdminReturnCode;
import com.neo.cornerstone.management.admin.enums.StateEnum;
import com.neo.cornerstone.management.admin.model.*;
import com.neo.cornerstone.management.admin.model.ext.MenuExt;
import com.neo.cornerstone.management.admin.model.params.*;
import com.neo.cornerstone.management.admin.service.common.*;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.BehaviorResult;
import com.neo.cornerstone.management.base.exception.BizRuntimeException;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.cornerstone.management.base.service.log.SendLogService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/*******************************************************************************
 * Created on 2019/7/18 18:38
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 *****************************************************************************
 * @author xn082184*/
@Service("roleBizService")
public class RoleBizService extends BaseService {

    @Autowired
    private RoleService roleService;
    @Autowired
    private UserRoleService userRoleService;
    @Autowired
    private RolePermissionService rolePermissionService;
    @Autowired
    private RoleMenuService roleMenuService;
    @Autowired
    private MenuService menuService;
    @Autowired
    private PermissionService permissionService;
    @Autowired
    private SendLogService sendLogService;

    public void roleAuth(Long roleId, RoleAuthDTO roleAuthDTO) {
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_ROLE_AUTH).setOperationParams("[" + roleId + "]-" + JSON.toJSONString(roleAuthDTO));
        try {
            Role role = roleService.queryById(roleId);
            if (null == role) {
                throw new BizRuntimeException(AdminReturnCode.ROLE_NOT_EXISTS.getCode(), AdminReturnCode.ROLE_NOT_EXISTS.getMessage());
            }

            List<RolePermission> rolePermissionList = null;
            Set <Long> roleMenuIdSet = null;
            if (CollectionUtils.isNotEmpty(roleAuthDTO.getPermissionIdList())) {
                rolePermissionList = new ArrayList <>();
                roleMenuIdSet = new TreeSet <>();
                for (Long permissionId: roleAuthDTO.getPermissionIdList()) {
                    Permission permission = permissionService.queryById(permissionId);
                    if (null == permission) {
                        throw new BizRuntimeException(AdminReturnCode.PERMISSION_NOT_EXISTS.getCode(), AdminReturnCode.PERMISSION_NOT_EXISTS.getMessage());
                    }
                    RolePermission rolePermission = new RolePermission();
                    rolePermission.setCreateTime(new Date());
                    rolePermission.setPermissionId(permissionId);
                    rolePermission.setRoleId(roleId);
                    rolePermission.setState(StateEnum.VALID.getCode());
                    rolePermissionList.add(rolePermission);
                    queryParentMenuId(permission.getMenuId(), roleMenuIdSet);
                }
            }
            deleteOldRoleMenuAndPermission(roleId);
            saveNewMenuAndPermission(roleId, rolePermissionList, roleMenuIdSet);

            operationLog.setRemark("targetId: " + roleId)
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
        } catch (Exception e) {
            operationLog.setRemark("targetId: " + roleId)
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }

    private void saveNewMenuAndPermission(Long roleId, List<RolePermission> rolePermissionList, Set <Long> roleMenuIdSet) {
        if (null != rolePermissionList && CollectionUtils.isNotEmpty(rolePermissionList)) {
            // 保存新的角色权限
            rolePermissionService.saveListModel(rolePermissionList);
        }
        if (null != roleMenuIdSet && !roleMenuIdSet.isEmpty()) {
            // 保存所有新的角色菜单
            List<RoleMenu> roleMenuList = new ArrayList <>();
            Iterator <Long> iterator = roleMenuIdSet.iterator();
            while (iterator.hasNext()) {
                Long menuId = iterator.next();
                RoleMenu roleMenu = new RoleMenu();
                roleMenu.setCreateTime(new Date());
                roleMenu.setMenuId(menuId);
                roleMenu.setRoleId(roleId);
                roleMenu.setState(StateEnum.VALID.getCode());
                roleMenuList.add(roleMenu);
            }
            roleMenuService.saveListModel(roleMenuList);
        }
    }

    private void deleteOldRoleMenuAndPermission(Long roleId) {
        // 清空旧的 角色对应的菜单
        RoleMenuParams roleMenuParams = new RoleMenuParams();
        roleMenuParams.setRoleId(roleId);
        roleMenuService.deleteByCondition(roleMenuParams);

        // 清空旧的 角色对应的权限
        RolePermissionParams rolePermissionParams = new RolePermissionParams();
        rolePermissionParams.setRoleId(roleId);
        rolePermissionService.deleteByCondition(rolePermissionParams);
    }

    /**
     * 找到当前menu的所有父级menu
     * @param menuId
     * @param roleMenuIdSet
     */
    public void queryParentMenuId(Long menuId, Set<Long> roleMenuIdSet) {
        if (!roleMenuIdSet.contains(menuId)) {
            Menu menu = menuService.queryById(menuId);
            roleMenuIdSet.add(menuId);
            if (menu.getParentId() != 0) {
                queryParentMenuId(menu.getParentId(), roleMenuIdSet);
            }
        }
    }

    /**
     * 查询角色- 权限 - 菜单信息 用于角色权限管理编辑
     * @param roleId
     * @return
     */
    public RolePermissionInfoDTO queryRolePermission(Long roleId) {
        RolePermissionInfoDTO rolePermissionInfoDTO = new RolePermissionInfoDTO();

        Role role = roleService.queryById(roleId);
        if (role == null) {
            throw new BizRuntimeException(AdminReturnCode.ROLE_NOT_EXISTS.getCode(), AdminReturnCode.ROLE_NOT_EXISTS.getMessage());
        }
        List<Long> permissionIdList = new ArrayList <>();
        RolePermissionParams rolePermissionParams = new RolePermissionParams();
        rolePermissionParams.setRoleId(roleId);
        List <RolePermission> rolePermissionList = rolePermissionService.queryListByCondition(rolePermissionParams);
        if (CollectionUtils.isNotEmpty(rolePermissionList)) {
            for (RolePermission rolePermission: rolePermissionList) {
                permissionIdList.add(rolePermission.getPermissionId());
            }
        }
        rolePermissionInfoDTO.setPermissionList(permissionIdList);
        rolePermissionInfoDTO.setRoleMenu(queryAllMenuData());
        return rolePermissionInfoDTO;
    }

    /**
     * 查询 与 构建 菜单相关信息
     * @return
     */
    private List<RoleMenuInfoDTO> queryAllMenuData() {
        MenuParams menuParams = new MenuParams();
        menuParams.setLevel(1);
        List <MenuExt> menuDataList = menuService.queryListByConditionExt(menuParams);
        List<RoleMenuInfoDTO> menuInfoDTOList = new ArrayList <>();
        if (CollectionUtils.isNotEmpty(menuDataList)) {
            for (MenuExt menu: menuDataList) {
                RoleMenuInfoDTO menuInfoDTO = dealMenuData(menu);
                menuInfoDTOList.add(menuInfoDTO);
            }
        }
        return menuInfoDTOList;
    }

    /**
     *
     * @param menu
     * @return
     */
    private RoleMenuInfoDTO dealMenuData(MenuExt menu) {
        RoleMenuInfoDTO menuInfo = new RoleMenuInfoDTO();
        menuInfo.setId(menu.getId());
        menuInfo.setLabel(menu.getName());
        menuInfo.setState(menu.getState());
        menuInfo.setParentId(menu.getParentId());
        menuInfo.setValue(menu.getId());

        if (CollectionUtils.isNotEmpty(menu.getPermissionList())) {
            List<PermissionBoxDTO> permissionList = new ArrayList <>();
            for (Permission permission : menu.getPermissionList()) {
                PermissionBoxDTO permissionBoxDTO = new PermissionBoxDTO();
                permissionBoxDTO.setLabel(permission.getName());
                permissionBoxDTO.setValue(permission.getId());
                permissionList.add(permissionBoxDTO);
            }
            menuInfo.setPermissionList(permissionList);
        }

        MenuParams menuParams = new MenuParams();
        menuParams.setParentId(menuInfo.getId());
        List <MenuExt> subMenuDataList = menuService.queryListByConditionExt(menuParams);
        if (CollectionUtils.isNotEmpty(subMenuDataList)) {
            List<RoleMenuInfoDTO> subMenuInfoList = new ArrayList <>();
            for (MenuExt subMenu: subMenuDataList) {
                subMenuInfoList.add(dealMenuData(subMenu));
            }
            menuInfo.setChildren(subMenuInfoList);
        }
        return menuInfo;
    }

    /**
     * 用于下拉列表 角色信息
     * @return
     */
    public List<RoleInfoDTO> queryRoleListForSelect() {
        List <Role> roleList = roleService.queryListByCondition(new RoleParams());
        List<RoleInfoDTO> responseDataList = new ArrayList <>();
        if (CollectionUtils.isNotEmpty(roleList)) {
            for (Role role: roleList) {
                RoleInfoDTO roleInfoDTO = new RoleInfoDTO();
                roleInfoDTO.setLabel(role.getName());
                roleInfoDTO.setValue(role.getId());
                responseDataList.add(roleInfoDTO);
            }
        }
        return responseDataList;
    }

    /**
     * 更新
     * @param id
     * @param rolePostDTO
     * @return
     */
    public Boolean updateRole(Long id, RolePostDTO rolePostDTO) {
        Role role = null;
        Role updateRole = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_ROLE_UPDATE).setOperationParams(JSON.toJSONString(rolePostDTO));
        try {
            role = roleService.queryById(id);
            if (role == null) {
                throw new BizRuntimeException(AdminReturnCode.ROLE_NOT_EXISTS.getCode(), AdminReturnCode.ROLE_NOT_EXISTS.getMessage());
            }
            updateRole = new Role();
            updateRole.setId(id);
            updateRole.setName(rolePostDTO.getName());
            updateRole.setState(rolePostDTO.getState());
            updateRole.setModTime(new Date());
            boolean result = roleService.updateById(updateRole);

            operationLog.setRemark(role.getName())
                    .setSnapshot(JSON.toJSONString(updateRole))
                    .setOriginalSnapshot(JSON.toJSONString(role))
                    .setOperationResult(result ? BehaviorResult.SUCCESS.getCode() : BehaviorResult.FAILURE.getCode());
            return result;
        } catch (Exception e) {
            operationLog.setRemark(role == null ? "" : role.getName())
                    .setSnapshot(JSON.toJSONString(updateRole))
                    .setOriginalSnapshot(JSON.toJSONString(role))
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }

    /**
     * 删除
     * @param id
     * @return
     */
    public boolean deleteRole(Long id) {
        Role role = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_ROLE_DELETE).setOperationParams(id + "");
        try {
            role = roleService.queryById(id);
            if (role == null) {
                throw new BizRuntimeException(AdminReturnCode.ROLE_NOT_EXISTS.getCode(), AdminReturnCode.ROLE_NOT_EXISTS.getMessage());
            }
            deleteRoleData(id);

            operationLog.setOriginalSnapshot(JSON.toJSONString(role))
                    .setRemark(role.getName())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
            return true;
        } catch (Exception e) {
            operationLog.setOriginalSnapshot(JSON.toJSONString(role))
                    .setRemark(role != null ? role.getName() : null)
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }

    }

    /**
     * 删除关联信息
     * @param id
     */
    private void deleteRoleData(Long id) {
        roleService.deleteById(id);
        // user

        UserRoleParams userRoleParams = new UserRoleParams();
        userRoleParams.setRoleId(id);
        //userRoleService.deleteByCondition(userRoleParams);
        List <UserRole> userRoleList = userRoleService.queryListByCondition(userRoleParams);
        if (CollectionUtils.isNotEmpty(userRoleList)) {
            throw new BizRuntimeException(AdminReturnCode.ROLE_REF_USER.getCode(), AdminReturnCode.ROLE_REF_USER.getMessage());
        }
    }

    /**
     * 查询角色分页列表信息
     * @param pageNum
     * @param pageSize
     * @param name
     * @return
     */
    public PageModel<RoleInfoDTO> queryRoles(Integer pageNum, Integer pageSize, String name) {
        RoleParams request = new RoleParams();
//        request.setName(name);
        request.setPatternName(name);
        request.setPageSize(pageSize);
        request.setPageNum(pageNum);
        PageModel<Role> rolePage = roleService.queryPage(request);

        PageModel<RoleInfoDTO> responsePageData = new PageModel<>();
        responsePageData.setTotalRows(0);
        if (rolePage != null && CollectionUtils.isNotEmpty(rolePage.getData())) {
            responsePageData.setTotalRows(rolePage.getTotalRows());
            List<RoleInfoDTO> responseDataList = new ArrayList<>();
            for (Role role: rolePage.getData()) {
                RoleInfoDTO infoDTO = new RoleInfoDTO();
                infoDTO.setState(role.getState());
                infoDTO.setName(role.getName());
                infoDTO.setId(role.getId());
                infoDTO.setCreateTime(role.getCreateTime());
                infoDTO.setModTime(role.getModTime());
                responseDataList.add(infoDTO);
            }
            responsePageData.setData(responseDataList);
        }
        return responsePageData;
    }

    /**
     * 添加
     * @param rolePostDTO
     * @return
     */
    public Boolean addRole(RolePostDTO rolePostDTO) {
        Role role = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_ROLE_ADD).setOperationParams(JSON.toJSONString(rolePostDTO));
        try {
            RoleParams roleParams = new RoleParams();
            roleParams.setName(rolePostDTO.getName());
            List<Role> roleList = roleService.queryListByCondition(roleParams);
            if (CollectionUtils.isNotEmpty(roleList)) {
                throw new BizRuntimeException(AdminReturnCode.ROLE_NAME_EXISTS.getCode(), AdminReturnCode.ROLE_NAME_EXISTS.getMessage());
            }

            role = new Role();
            role.setName(rolePostDTO.getName());
            role.setState(rolePostDTO.getState());
            role.setCreateTime(new Date());
            roleService.saveModel(role);

            operationLog.setSnapshot(JSON.toJSONString(role))
                    .setRemark(role.getName())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
            return true;
        } catch (Exception e) {
            operationLog.setSnapshot(JSON.toJSONString(role))
                    .setRemark(rolePostDTO.getName())
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }

    }
}
