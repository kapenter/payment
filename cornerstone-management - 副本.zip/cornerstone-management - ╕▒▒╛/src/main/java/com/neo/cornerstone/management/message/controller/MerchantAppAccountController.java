package com.neo.cornerstone.management.message.controller;

import com.neo.cornerstone.management.base.annotation.OperationLog;
import com.neo.cornerstone.management.base.constants.BaseUrl;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.service.MerchantAppAccountService;
import com.neo.cornerstone.merchant.serve.define.dto.MerchantAppDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountQueryDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountRequestDTO;
import com.neo.cornerstone.message.dto.request.MerchantAppAccountUpdateDTO;
import com.neo.cornerstone.message.dto.response.MerchantAppAccountRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-22 14:32
 **/
@RestController
@RequestMapping(BaseUrl.ROOT_URL)
public class MerchantAppAccountController extends BaseController {

    @Autowired
    private MerchantAppAccountService merchantAppAccountService;


    @RequestMapping(value = MessageURL.MESSAGE_MERCHANT_APP_ACCOUNT_LIST, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MERCHANT_APP_ACCOUNT_LIST)
    public PageModel<MerchantAppAccountRespDTO> pageAppAccount(@RequestBody @Validated MerchantAppAccountQueryDTO merchantAppAccountQueryDTO) {
        PageModel<MerchantAppAccountRespDTO> pageModel = new PageModel<>();
        PageResponseDTO<MerchantAppAccountRespDTO> merchantAppAccountRespDTOPageResponseDTO = merchantAppAccountService.pageMerchantAppAccount(merchantAppAccountQueryDTO);
        pageModel.setTotalRows(merchantAppAccountRespDTOPageResponseDTO.getTotalRow());
        List<MerchantAppDTO> merchantList=merchantAppAccountService.getMerchantAppList();
        List<MerchantAppAccountRespDTO>  list=merchantAppAccountRespDTOPageResponseDTO.getData();
        for(MerchantAppAccountRespDTO respDTO:list){
            for(MerchantAppDTO merchant:merchantList){
                if(merchant.getAppId().equals(respDTO.getAppId())){
                    respDTO.setMerchantName(merchant.getAppName());
                }
            }
        }
        pageModel.setData(merchantAppAccountRespDTOPageResponseDTO.getData());
        return ResponseUtils.buildSuccessPageResponse(pageModel);
    }

    /**
     * 获取商户应用信息---调用merchant服务
     *
     * @return
     */
    @RequestMapping(value = MessageURL.MERCHANT_APP_ACCOUNT_LIST, method = RequestMethod.GET)
    public BaseResponse<List<MerchantAppDTO>> listMerchantApp() {
        return ResponseUtils.buildSuccessResponse(merchantAppAccountService.getMerchantAppList());
    }


    /**
     * 新增商户应用账号配置
     *
     * @param merchantAppAccountRequestDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MERCHANT_APP_ACCOUNT_ADD, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MERCHANT_APP_ACCOUNT_ADD)
    public BaseResponse<Boolean> addMerchantAppAccount(@RequestBody @Validated MerchantAppAccountRequestDTO merchantAppAccountRequestDTO) {
        OperationResponseDTO<Boolean> operationResponseDTO= merchantAppAccountService.addMerchantAppAccount(merchantAppAccountRequestDTO);
        return ResponseUtils.getBooleanBaseResponse(operationResponseDTO);
    }

    /**
     * 修改商户应用账号配置
     *
     * @param merchantAppAccountUpdateDTO
     * @return
     */
    @RequestMapping(value = MessageURL.MESSAGE_MERCHANT_APP_ACCOUNT_UPDATE, method = RequestMethod.POST)
    @OperationLog(operation = OperationModule.MESSAGE_MERCHANT_APP_ACCOUNT_UPDATE)
    public BaseResponse<Boolean> updateMerchantAppAccount(@RequestBody @Validated MerchantAppAccountUpdateDTO merchantAppAccountUpdateDTO) {
        OperationResponseDTO<Boolean> operationResponseDTO= merchantAppAccountService.updateMerchantAppAccount(merchantAppAccountUpdateDTO);
        return ResponseUtils.getBooleanBaseResponse(operationResponseDTO);
    }
}
