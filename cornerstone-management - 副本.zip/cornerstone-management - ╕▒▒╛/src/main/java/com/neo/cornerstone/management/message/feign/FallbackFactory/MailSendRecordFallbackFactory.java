package com.neo.cornerstone.management.message.feign.FallbackFactory;

import com.neo.cornerstone.management.message.consts.BizCodeEnum;
import com.neo.cornerstone.management.message.feign.MailSendRecordFeign;
import com.neo.cornerstone.message.dto.request.MailSendRecordQueryDTO;
import com.neo.cornerstone.message.dto.response.MailSendRecordRespDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-09-09 16:08
 **/
@Component
@Slf4j
public class MailSendRecordFallbackFactory implements FallbackFactory<MailSendRecordFeign> {




    @Override
    public MailSendRecordFeign create(Throwable throwable) {
        return mailSendRecordQueryDTO -> {
            log.error("[fallback]---[消息管理]---[路由管理]---[发送记录]---[pageMailSendRecords]列表异常,msg:{},cause:",throwable.getMessage(),throwable);
            PageResponseDTO<MailSendRecordRespDTO> pageResponseDTO=new PageResponseDTO<>();
            pageResponseDTO.setReturnCode(BizCodeEnum.MAIL_PAGE_SEND_RECORD_FALLBACK_EXCEPTION.getCode());
            pageResponseDTO.setReturnMsg(BizCodeEnum.MAIL_PAGE_SEND_RECORD_FALLBACK_EXCEPTION.getMessage());
            return pageResponseDTO;
        };
    }
}
