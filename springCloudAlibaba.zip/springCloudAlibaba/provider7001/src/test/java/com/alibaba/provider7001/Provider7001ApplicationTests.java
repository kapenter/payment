package com.alibaba.provider7001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Provider7001ApplicationTests {

    @Test
    void contextLoads() {
    }

}
