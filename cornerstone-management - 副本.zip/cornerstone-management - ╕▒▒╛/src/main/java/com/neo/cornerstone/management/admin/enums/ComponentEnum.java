package com.neo.cornerstone.management.admin.enums;

/**
  * @ClassName ErrorCode
  * @Description ErrorCode
  * @Author xn024222
  * @Since 2019/1/2 18:57
  * @Version 1.0
  */
public enum ComponentEnum {

    LAYOUT("Layout", "菜单布局"),
    ;

    private String code;

    private String message;

    private ComponentEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public ComponentEnum getEnumByCode(String code) {
        for(ComponentEnum value : ComponentEnum.values()){
            if(value.getCode().equals(code)){
                return value;
            }
        }
        return null;
    }


}
