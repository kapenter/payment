package com.neo.cornerstone.management.base.model;

import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.dto.BaseObject;
import com.neo.cornerstone.management.base.enums.OperationResult;

import java.util.Date;

/*******************************************************************************
 * Created on 2019/8/26 18:22
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class OperationLog extends BaseObject {
    private String bizId;
    /**
     * 操作用户名
     */
    private String username;
    /**
     * 服务模块
     */
    private String moduleType;
    /**
     * 服务模块分类
     */
    private String subModuleType;
    /**
     * 操作结果
     * @see OperationResult
     */
    private Integer operationResult;
    /**
     * 操作行为内容描述
     */
    private String  operationContent;
    /**
     * 相关操作参数
     */
    private String operationParams;
    /**
     * 被操作记录的旧数据全部或者部分快照
     */
    private String originalSnapshot;
    /**
     * 新数据相关全部或者部分数据快照
     * e.g: 可用于记录一个对象更新时传入的对象
     */
    private String snapshot;
    /**
     * 相关备注与说明
     */
    private String remark;
    /**
     * 错误信息
     */
    private String error;
    /**
     * 操作相关ip
     */
    private String ip;

    /**
     * 相关数据是否加密
     */
    private Boolean encrypt;

    /**
     * 操作时间
     */
    private Date createTime;

    public static OperationLog init() {
        OperationLog operationLog = new OperationLog();
        operationLog.setCreateTime(new Date());
        return operationLog;
    }

    public static OperationLog init(OperationModule operationModule) {
        return init().setModuleType(operationModule.getModuleType())
                .setSubModuleType(operationModule.getSubModuleType())
                .setOperationContent(operationModule.getOperationContent());
    }

    public OperationLog setCreateTime(Date createTime) {
        this.createTime = createTime;
        return this;
    }

    public OperationLog setModuleType(String moduleType) {
        this.moduleType = moduleType;
        return this;
    }

    public OperationLog setSubModuleType(String subModuleType) {
        this.subModuleType = subModuleType;
        return this;
    }

    public OperationLog setOperationResult(Integer operationResult) {
        this.operationResult = operationResult;
        return this;
    }

    public OperationLog setOperationContent(String operationContent) {
        this.operationContent = operationContent;
        return this;
    }

    public OperationLog setUsername(String username) {
        this.username = username;
        return this;
    }

    public OperationLog setBizId(String bizId) {
        this.bizId = bizId;
        return this;
    }

    public OperationLog setOperationParams(String operationParams) {
        this.operationParams = operationParams;
        return this;
    }

    public OperationLog setOriginalSnapshot(String originalSnapshot) {
        this.originalSnapshot = originalSnapshot;
        return this;
    }

    public OperationLog setSnapshot(String snapshot) {
        this.snapshot = snapshot;
        return this;
    }

    public OperationLog setError(String error) {
        this.error = error;
        return this;
    }

    public OperationLog setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    public OperationLog setEncrypt(Boolean encrypt) {
        this.encrypt = encrypt;
        return this;
    }


    public String getBizId() {
        return bizId;
    }

    public String getOriginalSnapshot() {
        return originalSnapshot;
    }

    public String getSnapshot() {
        return snapshot;
    }

    public String getModuleType() {
        return moduleType;
    }

    public String getSubModuleType() {
        return subModuleType;
    }

    public String getOperationContent() {
        return operationContent;
    }

    public String getUsername() {
        return username;
    }

    public Integer getOperationResult() {
        return operationResult;
    }

    public String getOperationParams() {
        return operationParams;
    }

    public String getRemark() {
        return remark;
    }

    public String getError() {
        return error;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }


    public Date getCreateTime() {
        return createTime;
    }

    public Boolean getEncrypt() {
        return encrypt;
    }
}
