package com.neo.cornerstone.management.admin.configuration;

import com.neo.cornerstone.management.base.util.ContentUtil;
import com.neo.cornerstone.management.base.util.IpUtils;
import org.apache.shiro.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;

/*******************************************************************************
 * Created on 2019/8/29 17:05
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class MGTContentFilter implements Filter {

    private static Logger logger = LoggerFactory.getLogger(MGTContentFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        try {
            String ip = IpUtils.getRemoteIpAddr((HttpServletRequest) request);
            String url = ((HttpServletRequest) request).getRequestURI();
            logger.info("[{}] Content Filter Remote Ip :[{}]", url, ip);
            logger.info("Content Filter - [{}] - 访问[{}]", ip, url);
            ContentUtil.put(ContentUtil.REMOTE_IP, ip);

            chain.doFilter(request, response);
        } finally {
            ContentUtil.remove(ContentUtil.REMOTE_IP);
        }
    }

    @Override
    public void destroy() {

    }
}
