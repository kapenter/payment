package com.neo.cornerstone.management.admin.enums;

/**
 * @ClassName ErrorCode
 * @Description ErrorCode
 * @Author xn024222
 * @Since 2019/1/2 18:57
 * @Version 1.0
 */
public enum PermissionTypeEnum {

    URL(1, "URL类型权限", "URL:"), BUTTON(2, "按钮类型权限", "BUTTON:");

    private Integer type;

    private String message;

    private String permissionType;

    private PermissionTypeEnum(Integer type, String message, String permissionType) {
        this.type = type;
        this.message = message;
        this.permissionType = permissionType;
    }

    public static PermissionTypeEnum getEnumByCode(Integer type) {
        for (PermissionTypeEnum value : PermissionTypeEnum.values()) {
            if (value.getType().equals(type)) {
                return value;
            }
        }
        return null;
    }

    public Integer getType() {
        return type;
    }

    public String getMessage() {
        return message;
    }

    public String getPermissionType() {
        return permissionType;
    }}
