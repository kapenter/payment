package com.neo.cornerstone.management.payment.feign;

import com.neo.cornerstone.management.payment.fallback.MerchantChannelFallback;
import com.neo.payment.constant.AdminURL;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.merchant.ChannelConfigRowDTO;
import com.neo.payment.dto.admin.merchant.QueryPageRequestDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 商户渠道配置
 */
@FeignClient(value = "springcloud-5102-payment", fallback = MerchantChannelFallback.class)
public interface MerchantChannelFeign {

    @RequestMapping(value = AdminURL.QUERY_MERCHANT_CHANNEL_CONFIG_PAGE_LIST, method = RequestMethod.POST)
    PageResponseDTO<ChannelConfigRowDTO> queryPage(@RequestBody QueryPageRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.OPEN_MERCHANT_CHANNEL_CONFIG, method = RequestMethod.POST)
    ResponseDTO<String> openChannelConfig(@RequestBody Long id);

    @RequestMapping(value = AdminURL.CLOSE_MERCHANT_CHANNEL_CONFIG, method = RequestMethod.POST)
    ResponseDTO<String> closeChannelConfig(@RequestBody Long id);

}
