import java.time.ZonedDateTime;
/**
 * @author wsk
 * @date 2020/3/15 15:33
 */
public class T2 {
    public static void main(String[] args) {
        ZonedDateTime zbj = ZonedDateTime.now();
        System.out.println(zbj);
    }
}