package com.neo.cornerstone.management.admin.util;

import com.neo.cornerstone.management.admin.constants.GlobalConfig;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;

/*******************************************************************************
 * Created on 2019/8/26 11:11
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class PwdUtil {

    /**
     * 密码加密
     *
     * @param username
     * @param pwd
     * @return
     */
    public static String encryptPwd(String username, String pwd) {
        ByteSource salt = ByteSource.Util.bytes(username.substring(0, GlobalConfig.hashPreStringCount));
        SimpleHash hash = new SimpleHash(GlobalConfig.hashAlgorithmName, pwd, salt, GlobalConfig.hashIterations);
        return hash.toHex();
    }
}
