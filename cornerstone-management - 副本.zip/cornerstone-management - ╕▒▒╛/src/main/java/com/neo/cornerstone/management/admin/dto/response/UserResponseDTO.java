package com.neo.cornerstone.management.admin.dto.response;

public class UserResponseDTO {
}
