package com.neo.cornerstone.management.admin.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.neo.cornerstone.management.base.dto.BaseObject;

/*******************************************************************************
 * Created on 2019/7/30 17:53
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class PermissionBoxDTO extends BaseObject {
    private static final long serialVersionUID = -8410276176633467319L;
    private Long value;
    private String label;

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
