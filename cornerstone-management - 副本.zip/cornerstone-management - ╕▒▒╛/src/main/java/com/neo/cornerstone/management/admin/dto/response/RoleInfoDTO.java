package com.neo.cornerstone.management.admin.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.neo.cornerstone.management.base.dto.BaseObject;
import java.util.Date;
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class RoleInfoDTO extends BaseObject {
    private static final long serialVersionUID = -7056414818914291148L;

    private Long id;
    private String name;
    private Integer state;

    private Long value;
    private String label;
    private Date createTime;
    private Date modTime;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModTime() {
        return modTime;
    }

    public void setModTime(Date modTime) {
        this.modTime = modTime;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}
