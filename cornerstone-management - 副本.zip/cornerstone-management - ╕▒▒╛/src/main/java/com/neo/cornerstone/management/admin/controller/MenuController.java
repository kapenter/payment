package com.neo.cornerstone.management.admin.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.admin.dto.request.MenuPostDTO;
import com.neo.cornerstone.management.admin.dto.request.MenuUpdateDTO;
import com.neo.cornerstone.management.admin.dto.response.MenuInfoDTO;
import com.neo.cornerstone.management.admin.service.biz.MenuBizService;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.service.log.SendLogService;
import com.neo.cornerstone.management.base.util.ResponseUtils;

/*******************************************************************************
 * Created on 2019/7/25 16:03
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@RestController
public class MenuController extends BaseController {

    @Autowired
    private MenuBizService menuBizService;
    @Autowired
    private SendLogService sendLogService;

    /**
     * 获取所有菜单用于页面管理展示
     *
     * @return
     */
    @RequestMapping(value = Url.QUERY_ALL_MENU, method = RequestMethod.GET)
    public BaseResponse<List<MenuInfoDTO>> queryAllMenu() {
        List<MenuInfoDTO> menuData = menuBizService.queryAllMenu();
        return ResponseUtils.buildSuccessResponse(menuData);
    }

    /**
     * 添加菜单
     *
     * @param menuPostDTO
     * @return
     */
    @RequestMapping(value = Url.ADD_SUB_MENU, method = RequestMethod.POST)
    public BaseResponse<Long> addSubMenu(@RequestBody @Valid MenuPostDTO menuPostDTO) {
        Long id = menuBizService.addSubMenu(menuPostDTO);
        if (id != null) {
            return ResponseUtils.buildSuccessResponse(id);
        } else {
            return ResponseUtils.buildFailureResponse(null);
        }
    }

    /**
     * 删除菜单
     *
     * @param id
     * @return
     */
    @RequestMapping(value = Url.DELETE_MENU, method = RequestMethod.POST)
    public BaseResponse<Boolean> deleteMenu(@PathVariable("id") Long id) {
        menuBizService.deleteMenu(id);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 更新菜单
     *
     * @param id
     * @param menuUpdateDTO
     * @return
     */
    @RequestMapping(value = Url.UPDATE_MENU, method = RequestMethod.POST)
    public BaseResponse<Boolean> updaeMenu(@PathVariable("id") Long id,
            @RequestBody @Valid MenuUpdateDTO menuUpdateDTO) {
        Boolean result = menuBizService.updateMenu(id, menuUpdateDTO);
        if (result) {
            return ResponseUtils.buildSuccessResponse(true);
        } else {
            return ResponseUtils.buildFailureResponse(false, GlobalReturnCode.UPDATE_FAILURE.getCode(),
                    GlobalReturnCode.UPDATE_FAILURE.getMessage());
        }
    }
}
