package com.neo.cornerstone.management.merchant.controller;

import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import com.neo.cornerstone.management.merchant.constants.MerchantUrl;
import com.neo.cornerstone.management.merchant.service.AppAuthConfigClient;
import com.neo.cornerstone.merchant.serve.define.dto.AppAuthConfigDTO;
import com.neo.cornerstone.merchant.serve.define.dto.PageQueryParam;
import com.neo.cornerstone.merchant.serve.define.dto.PageResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @Description:商户权限
 * @Author: yanyiwei
 * @Date: 2019/08/26
 */
@Controller
public class AppAuthConfigController extends BaseController {

    @Autowired
    private AppAuthConfigClient appAuthConfigClient;

    /**
     * 商户权限分页
     * @param pageNum
     * @param pageSize
     * @return
     */
    @RequestMapping(value = MerchantUrl.PAGE_APP_AUTH_CONFIG)
    @ResponseBody
    public PageModel pageAppAuthConfig(Integer pageNum, Integer pageSize) {
        PageResponseDTO pageModel = appAuthConfigClient.pageAppAuthConfig(new PageQueryParam(pageNum, pageSize));
        PageModel<Object> objectPageModel = new PageModel<>();
        objectPageModel.setTotalRows(pageModel.getTotalRows());
        objectPageModel.setData(pageModel.getData());
        return ResponseUtils.buildSuccessPageResponse(objectPageModel);
    }

    /**
     * 商户权限添加
     * @param appAuthConfigDTO
     * @return
     */
    @RequestMapping(value = MerchantUrl.ADD_APP_AUTH_CONFIG)
    @ResponseBody
    public BaseResponse addAppAuthConfig(@RequestBody AppAuthConfigDTO appAuthConfigDTO) {
        appAuthConfigClient.addAppAuthConfig(appAuthConfigDTO);
        return ResponseUtils.buildSuccessResponse(null);
    }

    /**
     * 商户权限修改
     * @param appAuthConfigDTO
     * @return
     */
    @RequestMapping(value = MerchantUrl.UPDATE_APP_AUTH_CONFIG)
    @ResponseBody
    public BaseResponse updateAppAuthConfig(@RequestBody AppAuthConfigDTO appAuthConfigDTO) {
        appAuthConfigClient.updateAppAuthConfig(appAuthConfigDTO);
        return ResponseUtils.buildSuccessResponse(null);
    }
}
