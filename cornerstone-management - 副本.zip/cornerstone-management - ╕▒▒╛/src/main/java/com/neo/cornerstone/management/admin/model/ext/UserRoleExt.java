package com.neo.cornerstone.management.admin.model.ext;

import com.neo.cornerstone.management.admin.model.UserRole;

import java.util.List;

/*******************************************************************************
 * Created on 2019/7/30 11:53
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class UserRoleExt extends UserRole {
    private static final long serialVersionUID = -6333170834657050191L;

    private String roleName;

    private List<RoleMenuExt> roleMenuExtList;

    private List<RolePermissionExt> rolePermissionExtList;

    public List<RoleMenuExt> getRoleMenuExtList() {
        return roleMenuExtList;
    }

    public void setRoleMenuExtList(List<RoleMenuExt> roleMenuExtList) {
        this.roleMenuExtList = roleMenuExtList;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public List <RolePermissionExt> getRolePermissionExtList() {
        return rolePermissionExtList;
    }

    public void setRolePermissionExtList(List <RolePermissionExt> rolePermissionExtList) {
        this.rolePermissionExtList = rolePermissionExtList;
    }
}
