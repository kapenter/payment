package com.neo.cornerstone.management.admin.mapper;

import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.Organization;
import org.springframework.stereotype.Repository;

/**
 * Title:TOrganizationMapper<br/>
 * Description:(组织架构mapper接口)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public interface OrganizationMapper extends BaseMapper <Organization> {

}
