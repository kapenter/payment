package com.neo.cornerstone.management.admin.model.params;

import com.neo.cornerstone.management.base.dto.BaseObject;

import java.util.Date;

/**
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2018</p>
 *
 * @author Luo Shun
 * @version v1.0 2018/02/28
 */
public abstract class BaseParams extends BaseObject {
    private static final long serialVersionUID = 694062955034611920L;
    protected Long id;
    protected Integer pageSize;
    protected Integer pageNum;
    protected Integer offset;
    protected Integer limit;

    private Date startTime;
    private Date endTime;

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getOffset() {
        return (pageNum - 1) * pageSize;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
