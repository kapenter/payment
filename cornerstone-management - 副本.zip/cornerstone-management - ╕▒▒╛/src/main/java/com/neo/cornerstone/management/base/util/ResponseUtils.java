package com.neo.cornerstone.management.base.util;

import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.enums.GlobalReturnStatus;
import com.neo.cornerstone.message.constant.ErrorCode;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;

/*******************************************************************************
 * Created on 2019/7/18 18:44
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class ResponseUtils {

    public static <T> PageModel<T> buildSuccessPageResponse(PageModel pageModel) {
        pageModel.setStatus(GlobalReturnStatus.USCCESS.getStatus());
        pageModel.setReturnCode(GlobalReturnCode.SUCCESS.getCode());
        pageModel.setReturnMsg(GlobalReturnCode.SUCCESS.getMessage());
        return pageModel;
    }

    public static <T> BaseResponse<T> buildSuccessResponse(T data) {
        BaseResponse<T> response = new BaseResponse <>();
        response.setStatus(GlobalReturnStatus.USCCESS.getStatus());
        response.setReturnCode(GlobalReturnCode.SUCCESS.getCode());
        response.setReturnMsg(GlobalReturnCode.SUCCESS.getMessage());
        response.setData(data);
        return response;
    }

    public static <T> BaseResponse<T> buildFailureResponse(T data) {
        BaseResponse<T> response = new BaseResponse <>();
        response.setStatus(GlobalReturnStatus.FAILURE.getStatus());
        response.setReturnCode(GlobalReturnCode.FAILURE.getCode());
        response.setReturnMsg(GlobalReturnCode.FAILURE.getMessage());
        response.setData(data);
        return response;
    }

    public static <T> BaseResponse<T> buildFailureResponse(T data, String returnCode, String returnMsg) {
        BaseResponse<T> response = new BaseResponse <>();
        response.setStatus(GlobalReturnStatus.FAILURE.getStatus());
        response.setReturnCode(returnCode);
        response.setReturnMsg(returnMsg);
        response.setData(data);
        return response;
    }

    public static <T> BaseResponse<T> buildSuccessResponse(T data, String returnCode, String returnMsg) {
        BaseResponse<T> response = new BaseResponse <>();
        response.setStatus(GlobalReturnStatus.USCCESS.getStatus());
        response.setReturnCode(returnCode);
        response.setReturnMsg(returnMsg);
        response.setData(data);
        return response;
    }


    public static BaseResponse<Boolean> getBooleanBaseResponse(OperationResponseDTO<Boolean> operationResponseDTO) {
        if(operationResponseDTO.getReturnCode().equals(ErrorCode.TRADE_SUCCESS.getCode())){
            return buildSuccessResponse(operationResponseDTO.getData());
        }else{
            return buildFailureResponse(operationResponseDTO.getData(),operationResponseDTO.getReturnCode(),operationResponseDTO.getReturnMsg());
        }
    }
}
