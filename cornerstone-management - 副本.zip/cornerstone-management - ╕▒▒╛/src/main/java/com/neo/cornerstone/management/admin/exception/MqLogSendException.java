package com.neo.cornerstone.management.admin.exception;

import com.neo.cornerstone.management.base.exception.BaseRuntimeException;

/*******************************************************************************
 * Created on 2019/7/18 14:45
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class MqLogSendException extends BaseRuntimeException {

    public MqLogSendException(String code, String defaultMessage, Object... args) {
        super(code, defaultMessage, args);
    }

    public MqLogSendException(String code, String defaultMessage, Throwable cause, Object... args) {
        super(code, defaultMessage, cause, args);
    }

    public MqLogSendException(String defaultMessage, Throwable cause) {
        super(defaultMessage, cause);
    }

    public MqLogSendException(String defaultMessage) {
        super(defaultMessage);
    }
}
