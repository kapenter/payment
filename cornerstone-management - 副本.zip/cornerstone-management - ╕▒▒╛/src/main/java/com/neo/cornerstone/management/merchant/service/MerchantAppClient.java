package com.neo.cornerstone.management.merchant.service;

import com.neo.cornerstone.merchant.serve.define.facade.MerchantAppService;
import org.springframework.cloud.netflix.feign.FeignClient;

/**
* @Description:
* @Author: yanyiwei
* @Date: 2019/08/26
*/
@FeignClient(value = "springcloud-5103-merchant")
public interface MerchantAppClient  extends MerchantAppService {

}
