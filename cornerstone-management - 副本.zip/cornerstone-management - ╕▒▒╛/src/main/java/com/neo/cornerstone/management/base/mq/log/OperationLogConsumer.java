package com.neo.cornerstone.management.base.mq.log;

import com.neo.cornerstone.management.base.constants.GlobalConfigConstant;
import com.neo.msplatform.framework.utils.rocketmq.listener.impl.RocketMqMessageListener;
import com.neo.msplatform.framework.utils.rocketmq.service.impl.RocketmqMessageConsumeServiceAbstractImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

/**
 * Created by kyle on 2019/6/17.
 */
@Service("operationLogConsumer")
public class OperationLogConsumer extends RocketmqMessageConsumeServiceAbstractImpl {
    @Autowired
    private ApplicationContext applicationContext;
    @Override
    public String getTopic() {
        return GlobalConfigConstant.MANAGEMENT_LOG_TOPIC;
    }

    @Override
    public String getTags() {
        return GlobalConfigConstant.OPERATION_LOG_TAG;
    }

    @Override
    public String getConsumerGroup() {
        //不同的consumer使用不同的group ,否则tag接收异常
        return "5007-Operation-Consumer";
    }

    @Override
    public RocketMqMessageListener getMessageListenerConcurrently() {
        return (RocketMqMessageListener)applicationContext.getBean("operationLogListener");
    }
}
