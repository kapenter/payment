package com.neo.cornerstone.management.admin.model;

import com.baomidou.mybatisplus.annotations.IdType;
import com.baomidou.mybatisplus.annotations.TableId;
import com.neo.cornerstone.management.base.dto.BaseObject;


public class BaseModel extends BaseObject {
    private static final long serialVersionUID = 4002467543605482456L;

    @TableId(type = IdType.AUTO)
    protected Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
