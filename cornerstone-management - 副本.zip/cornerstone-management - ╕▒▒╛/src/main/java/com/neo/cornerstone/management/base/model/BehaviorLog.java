package com.neo.cornerstone.management.base.model;

import com.neo.cornerstone.message.entitty.BaseObject;

import java.util.Date;

/*******************************************************************************
 * Created on 2019/8/26 18:23
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class BehaviorLog extends BaseObject {
    private String bizId;
    /**
     * 操作用户名
     */
    private String username;

    /**
     * 访问URL
     */
    private String url;
    /**
     * 服务模块
     */
    private String subMenuType;
    /**
     * 所属菜单
     */
    private String menuType;
    /**
     * 操作行为内容描述
     */
    private String  operationContent;
    /**
     * 相关操作参数
     */
    private String operationParams;

    /**
     * 相关备注与说明
     */
    private String remark;
    /**
     * 操作相关ip
     */
    private String ip;

    /**
     * 操作时间
     */
    private Date createTime;

    public String getBizId() {
        return bizId;
    }

    public void setBizId(String bizId) {
        this.bizId = bizId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSubMenuType() {
        return subMenuType;
    }

    public void setSubMenuType(String subMenuType) {
        this.subMenuType = subMenuType;
    }

    public String getOperationContent() {
        return operationContent;
    }

    public void setOperationContent(String operationContent) {
        this.operationContent = operationContent;
    }

    public String getOperationParams() {
        return operationParams;
    }

    public void setOperationParams(String operationParams) {
        this.operationParams = operationParams;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getMenuType() {
        return menuType;
    }

    public void setMenuType(String menuType) {
        this.menuType = menuType;
    }
}
