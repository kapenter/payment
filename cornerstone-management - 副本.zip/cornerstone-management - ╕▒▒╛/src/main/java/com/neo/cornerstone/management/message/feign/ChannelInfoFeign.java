package com.neo.cornerstone.management.message.feign;

import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.feign.FallbackFactory.ChannelInfoFallbackFactory;
import com.neo.cornerstone.message.dto.request.ChannelInfoQueryDTO;
import com.neo.cornerstone.message.dto.request.ChannelInfoRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelInfoRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-22 15:12
 **/
@FeignClient(value = "springcloud-5101-message",fallbackFactory = ChannelInfoFallbackFactory.class)
public interface ChannelInfoFeign {

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_INFO_LIST,method = RequestMethod.POST)
    PageResponseDTO<ChannelInfoRespDTO>  pageChannelInfos(@RequestBody ChannelInfoQueryDTO channelInfoQueryDTO);


    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_INFO_ALL_LIST,method = RequestMethod.POST)
    List<ChannelInfoRespDTO> allChannelInfos();



    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_INFO_ADD,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> addChannelInfo(@RequestBody ChannelInfoRequestDTO channelInfoRequestDTO);

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_INFO_UPDATE,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> updateChannelInfo(ChannelInfoRequestDTO channelInfoRequestDTO);



}
