package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

public class PermissionUpdateDTO extends BaseObject {
    private static final long serialVersionUID = 8235314138802846687L;

    private Long id;
    @NotNull(message = "权限类型不能为空")
    private Integer type;
    @NotEmpty(message = "权限名称不能为空")
    @Length(max = 100, message = "权限名称超过长度")
    private String name;
    @NotEmpty(message = "权限不能为空")
    @Length(max = 150, message = "权限超过长度")
    private String permission;
    @NotNull(message = "关联菜单不能为空")
    private Long menuId;
    @NotNull(message = "状态不能为空")
    private Integer state;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPermission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public Long getMenuId() {
        return menuId;
    }

    public void setMenuId(Long menuId) {
        this.menuId = menuId;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}
