package com.neo.cornerstone.management.admin.mapper;

import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.RolePermission;
import com.neo.cornerstone.management.admin.model.ext.RolePermissionExt;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * Title:TRolePermissionMapper<br/>
 * Description:(角色权限配置mapper接口)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
public interface RolePermissionMapper extends BaseMapper <RolePermission> {
    /**
     * 查询角色对应权限信息
     * @param roleId
     * @return
     */
    RolePermissionExt queryByRoleId(@Param("roleId") Long roleId);
}
