package com.neo.cornerstone.management.admin.service.common;

import com.neo.cornerstone.management.admin.mapper.RoleMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.Role;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.RoleParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Title:TRoleServiceImpl<br/>
 * Description:(角色SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("roleService")
public class RoleService extends MysqlBaseServiceImpl <Role> {


    @Autowired
    private RoleMapper roleMapper;

    @Override
    public BaseMapper <Role> getBaseMapper() {
        return roleMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new RoleParams();
    }

    @Override
    public Role getObjectModel() {
        return new Role();
    }

}