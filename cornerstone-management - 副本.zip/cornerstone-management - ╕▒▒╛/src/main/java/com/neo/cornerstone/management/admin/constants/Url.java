package com.neo.cornerstone.management.admin.constants;

import com.neo.cornerstone.management.base.constants.BaseUrl;

/*******************************************************************************
 * Created on 2019/7/18 13:52
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public interface Url {

    /**
     * shiro认证 登录url
     */
    public static final String SHIRO_LOGIN = BaseUrl.ROOT_URL + "admin/shiro/login";

    /**
     * shiro认证 无权限url
     */
    public static final String SHIRO_NO_AUTH = BaseUrl.ROOT_URL + "admin/noAuth";

    public static final String QUERY_USER = BaseUrl.ROOT_URL + "admin/queryUser";

    /**
     * 登陆
     */
    public static final String USER_LOGIN = BaseUrl.ROOT_URL + "admin/login";

    /**
     * 未登录
     */
    public static final String USER_LOGIN_OFF = BaseUrl.ROOT_URL + "admin/login/off";

    /**
     * 登陆失败
     */
    public static final String USER_LOGIN_FAILURE = BaseUrl.ROOT_URL + "admin/login/failure";

    /**
     * 登陆
     */
    public static final String USER_LOGIN_SUCCESS = BaseUrl.ROOT_URL + "admin/login/success";

    /**
     * 退出登录
     */
    public static final String USER_LOGOUT = BaseUrl.ROOT_URL + "admin/logout";

    /**
     * 退出登录
     */
    public static final String USER_LOGOUT_SUCCESS = BaseUrl.ROOT_URL + "admin/logout/success";

    /**
     * 查询登录用户信息
     */
    public static final String QUERY_USER_INFO = BaseUrl.ROOT_URL + "admin/queryUserInfo";

    /**
     * 创建用户
     */
    public static final String ADD_USER = BaseUrl.ROOT_URL + "admin/createUser";

    /**
     * 用户修改密码
     */
    public static final String USER_MOD_PWD = BaseUrl.ROOT_URL + "admin/user/pwd/mod";

    /**
     * 查询用户组织
     */
    public static final String USER_QUERY_ORG = BaseUrl.ROOT_URL + "admin/user/queryOrg";

    /**
     * 查询用户组织
     */
    public static final String USER_QUERY_ROLES = BaseUrl.ROOT_URL + "admin/user/queryRoles";

    /**
     * 查询用户组织
     */
    public static final String USER_AUTH = BaseUrl.ROOT_URL + "admin/user/auth";

    /**
     * 重置用户密码
     */
    public static final String USER_RESET_PWD = BaseUrl.ROOT_URL + "admin/user/{id}/pwd/reset";

    /**
     * 更新用户
     */
    public static final String UPDATE_USER = BaseUrl.ROOT_URL + "admin/updateUser/{id}";

    /**
     * 查询所有菜单
     */
    public static final String QUERY_ALL_MENU = BaseUrl.ROOT_URL + "admin/queryAllMenu";

    /**
     * 添加菜单
     */
    public static final String ADD_SUB_MENU = BaseUrl.ROOT_URL + "admin/addMenu";

    /**
     * 删除菜单
     */
    public static final String DELETE_MENU = BaseUrl.ROOT_URL + "admin/deleteMenu/{id}";

    /**
     * 更新菜单
     */
    public static final String UPDATE_MENU = BaseUrl.ROOT_URL + "admin/updateMenu/{id}";

    /**
     * 查询所有组织
     */
    public static final String QUERY_ALL_ORG = BaseUrl.ROOT_URL + "admin/queryAllOrg";

    /**
     * 添加组织
     */
    public static final String ADD_SUB_ORG = BaseUrl.ROOT_URL + "admin/addOrg";

    /**
     * 删除组织
     */
    public static final String DELETE_ORG = BaseUrl.ROOT_URL + "admin/deleteOrg/{id}";

    /**
     * 更新组织
     */
    public static final String UPDATE_ORG = BaseUrl.ROOT_URL + "admin/updateOrg/{id}";

    /**
     * 查询权限
     */
    public static final String QUERY_PERMISSION = BaseUrl.ROOT_URL + "admin/queryPermission";

    /**
     * 添加权限
     */
    public static final String ADD_PERMISSION = BaseUrl.ROOT_URL + "admin/addPermission";

    /**
     * 删除权限
     */
    public static final String DELETE_PERMISSION = BaseUrl.ROOT_URL + "admin/deletePermission/{id}";

    /**
     * 更新权限
     */
    public static final String UPDATE_PERMISSION = BaseUrl.ROOT_URL + "admin/updatePermission/{id}";

    /**
     * 查询权限菜单
     */
    public static final String PERMISSION_MENU = BaseUrl.ROOT_URL + "admin/query/permission/menu";

    /**
     * 查询角色
     */
    public static final String QUERY_ROLE = BaseUrl.ROOT_URL + "admin/queryRoles";

    /**
     * 查询角色权限
     */
    public static final String QUERY_ROLE_PERMISSION = BaseUrl.ROOT_URL + "admin/role/permission/{roleId}";

    /**
     * 添加角色
     */
    public static final String ADD_ROLE = BaseUrl.ROOT_URL + "admin/addRole";

    /**
     * 删除角色
     */
    public static final String DELETE_ROLE = BaseUrl.ROOT_URL + "admin/deleteRole/{id}";

    /**
     * 更新角色
     */
    public static final String UPDATE_ROLE = BaseUrl.ROOT_URL + "admin/updateRole/{id}";

    /**
     * 角色权限编辑
     */
    public static final String ROLE_AUTH = BaseUrl.ROOT_URL + "admin/role/permission/auth/{id}";

    /**
     *
     */
    public static final String QUERY_OPERATION_LOG = BaseUrl.ROOT_URL + "admin/log/operation";
    public static final String QUERY_BEHAVIOR_LOG = BaseUrl.ROOT_URL + "admin/log/behavior";

    public static final String KAPTCHA_CODE = BaseUrl.ROOT_URL + "admin/kaptcha";



    /***************************消息管理模块***************************************************/


}


