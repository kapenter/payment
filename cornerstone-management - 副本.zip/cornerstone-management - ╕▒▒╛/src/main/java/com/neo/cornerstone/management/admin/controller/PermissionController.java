package com.neo.cornerstone.management.admin.controller;

import com.neo.cornerstone.management.admin.constants.Url;
import com.neo.cornerstone.management.admin.dto.request.PermissionPostDTO;
import com.neo.cornerstone.management.admin.dto.request.PermissionUpdateDTO;
import com.neo.cornerstone.management.admin.dto.response.MenuInfoDTO;
import com.neo.cornerstone.management.admin.dto.response.PermissionInfoDTO;
import com.neo.cornerstone.management.admin.service.biz.PermissionBizService;
import com.neo.cornerstone.management.base.controller.BaseController;
import com.neo.cornerstone.management.base.dto.BaseResponse;
import com.neo.cornerstone.management.base.dto.PageModel;
import com.neo.cornerstone.management.base.enums.GlobalReturnCode;
import com.neo.cornerstone.management.base.util.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/*******************************************************************************
 * Created on 2019/7/18 13:49
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Validated
@RestController
public class PermissionController extends BaseController {

    @Autowired
    private PermissionBizService permissionBizService;

    /**
     * 查询权限分页列表
     * @param pageNum
     * @param pageSize
     * @param name
     * @return
     */
    @RequestMapping(value = Url.QUERY_PERMISSION, method = RequestMethod.GET)
    public PageModel<PermissionInfoDTO> queryPermission(Integer pageNum, Integer pageSize, String name, Long menuId) {
        pageNum = pageNum == null || pageNum <0 ? 0 : pageNum;
        pageSize = pageSize == null || pageSize < 0 ? 10: pageSize;

        PageModel<PermissionInfoDTO> permissionPageData = permissionBizService.queryPermission(pageNum, pageSize, name, menuId);
        return ResponseUtils.buildSuccessPageResponse(permissionPageData);
    }

    /**
     * 用于权限页面 查询所有菜单信息
     * @return
     */
    @RequestMapping(value = Url.PERMISSION_MENU, method = RequestMethod.GET)
    public BaseResponse<List <MenuInfoDTO>> queryAllMenu() {
        List<MenuInfoDTO> menuData = permissionBizService.queryMenu();
        return ResponseUtils.buildSuccessResponse(menuData);
    }

    /**
     * 添加权限
     * @param permissionPostDTO
     * @return
     */
    @RequestMapping(value = Url.ADD_PERMISSION, method = RequestMethod.POST)
    public BaseResponse<Boolean> addPermission(@RequestBody @Valid PermissionPostDTO permissionPostDTO) {
        this.permissionBizService.addPermission(permissionPostDTO);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 删除权限
     * @param id
     * @return
     */
    @RequestMapping(value = Url.DELETE_PERMISSION, method = RequestMethod.POST)
    public BaseResponse<Boolean> deleteOrg(@PathVariable("id") Long id) {
        permissionBizService.deletePermission(id);
        return ResponseUtils.buildSuccessResponse(true);
    }

    /**
     * 更新权限
     * @param id
     * @param permissionUpdateDTO
     * @return
     */
    @RequestMapping(value = Url.UPDATE_PERMISSION, method = RequestMethod.POST)
    public BaseResponse<Boolean> updatePermission(@PathVariable("id") Long id, @RequestBody @Valid PermissionUpdateDTO permissionUpdateDTO) {
        Boolean result = permissionBizService.updatePermission(id, permissionUpdateDTO);

        if (result) {
            return ResponseUtils.buildSuccessResponse(true);
        } else {
            return ResponseUtils.buildFailureResponse(false, GlobalReturnCode.UPDATE_FAILURE.getCode(), GlobalReturnCode.UPDATE_FAILURE.getMessage());
        }
    }

}
