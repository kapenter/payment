package com.neo.cornerstone.management.admin.service.biz;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.neo.cornerstone.management.admin.dto.request.OrgPostDTO;
import com.neo.cornerstone.management.admin.dto.request.OrgUpdateDTO;
import com.neo.cornerstone.management.admin.dto.response.OrgInfoDTO;
import com.neo.cornerstone.management.admin.enums.AdminReturnCode;
import com.neo.cornerstone.management.admin.enums.StateEnum;
import com.neo.cornerstone.management.admin.model.Organization;
import com.neo.cornerstone.management.admin.model.User;
import com.neo.cornerstone.management.admin.model.params.OrganizationParams;
import com.neo.cornerstone.management.admin.model.params.UserParams;
import com.neo.cornerstone.management.admin.service.common.OrganizationService;
import com.neo.cornerstone.management.admin.service.common.RoleMenuService;
import com.neo.cornerstone.management.admin.service.common.UserService;
import com.neo.cornerstone.management.base.constants.OperationModule;
import com.neo.cornerstone.management.base.enums.BehaviorResult;
import com.neo.cornerstone.management.base.exception.BizRuntimeException;
import com.neo.cornerstone.management.base.model.OperationLog;
import com.neo.cornerstone.management.base.service.BaseService;
import com.neo.cornerstone.management.base.service.log.SendLogService;

/*******************************************************************************
 * Created on 2019/7/25 16:04
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
@Service("orgBizService")
public class OrgBizService extends BaseService {

    @Autowired
    private OrganizationService organizationService;
    @Autowired
    private RoleMenuService roleMenuService;
    @Autowired
    private UserService userService;
    @Autowired
    private SendLogService sendLogService;


    /**
     * 编辑
     * @param id
     * @param orgUpdateDTO
     */
    public Boolean updateOrg(Long id, OrgUpdateDTO orgUpdateDTO) {
        Organization organization = null;
        Organization updateOrgParams = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_ORG_UPDATE).setOperationParams("[" + id + "]-" + JSON.toJSONString(orgUpdateDTO));

        try {
            organization = organizationService.queryById(id);
            if (organization == null) {
                throw new BizRuntimeException(AdminReturnCode.ORG_NOT_EXISTS.getCode(), AdminReturnCode.ORG_NOT_EXISTS.getMessage());
            }

            OrganizationParams queryParam = new OrganizationParams();
            queryParam.setParentId(organization.getParentId());
            queryParam.setName(orgUpdateDTO.getName());
            List<Organization> dataList = organizationService.queryListByCondition(queryParam);

            if (CollectionUtils.isNotEmpty(dataList)) {
                if (dataList.size() > 1 || !dataList.get(0).getId().equals(organization.getId())) {
                    throw new BizRuntimeException(AdminReturnCode.ORG_LEVEL_EXISTS.getCode(),
                            AdminReturnCode.ORG_LEVEL_EXISTS.getMessage());
                }
            }

            updateOrgParams = new Organization();
            updateOrgParams.setId(id);
            updateOrgParams.setName(orgUpdateDTO.getName());
            updateOrgParams.setModTime(new Date());
            updateOrgParams.setState(orgUpdateDTO.getState().equals(StateEnum.VALID.getCode()) ? StateEnum.VALID.getCode(): StateEnum.INVALID.getCode());
            boolean result = organizationService.updateById(updateOrgParams);

            operationLog.setSnapshot(JSON.toJSONString(updateOrgParams))
                    .setOriginalSnapshot(JSON.toJSONString(organization))
                    .setRemark(organization.getName())
                    .setOperationResult(result ? BehaviorResult.SUCCESS.getCode() : BehaviorResult.FAILURE.getCode());

            return result;
        } catch (Exception e) {
            operationLog.setSnapshot(JSON.toJSONString(updateOrgParams))
                    .setOriginalSnapshot(JSON.toJSONString(organization))
                    .setError(e.getMessage())
                    .setRemark(organization == null ? "" : organization.getName())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
    }


    /**
     * 删除
     * @param id
     * @return
     */
    public boolean deleteOrg(Long id) {
        Organization organization = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_ORG_DELETE).setOperationParams(id + "");
        try {
            organization = organizationService.queryById(id);
            if (organization == null) {
                throw new BizRuntimeException(AdminReturnCode.ORG_NOT_EXISTS.getCode(), AdminReturnCode.ORG_NOT_EXISTS.getMessage());
            }
            deleteOrgData(id);

            operationLog.setOriginalSnapshot(JSON.toJSONString(organization))
                    .setRemark(organization.getName())
                    .setOperationResult(BehaviorResult.SUCCESS.getCode());
        } catch (Exception e) {
            operationLog.setOriginalSnapshot(JSON.toJSONString(organization))
                    .setRemark(organization != null ? organization.getName() : null)
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }
        return true;
    }

    /**
     * 删除组织 部门关联信息
     * @param id
     */
    private void deleteOrgData(Long id) {

        UserParams userParams = new UserParams();
        userParams.setOrgId(id);
        List <User> userList = userService.queryListByCondition(userParams);
        if (CollectionUtils.isNotEmpty(userList)) {
            throw new BizRuntimeException(AdminReturnCode.ORG_REF_USER.getCode(), AdminReturnCode.ORG_REF_USER.getMessage());
        }
        // 组织
        organizationService.deleteById(id);

        // 关联用户
//        userService.removeOrg(id);

        OrganizationParams organizationParams = new OrganizationParams();
        organizationParams.setParentId(id);
        List<Organization> subOrgDataList = organizationService.queryListByCondition(organizationParams);
        if (CollectionUtils.isNotEmpty(subOrgDataList)) {
            for (Organization org: subOrgDataList) {
                deleteOrgData(org.getId());
            }
        }
    }

    /**
     * 添加
     * @param orgPostDTO
     * @return
     */
    public Long addSubOrg(OrgPostDTO orgPostDTO) {
        Organization organization = null;
        OperationLog operationLog = OperationLog.init(OperationModule.ADMIN_ORG_ADD).setOperationParams(JSON.toJSONString(orgPostDTO));
        try {
            // 校验
            Organization organizationData = organizationService.queryById(orgPostDTO.getParentId());
            if (organizationData == null && orgPostDTO.getParentId() != 0) {
                throw new BizRuntimeException(AdminReturnCode.ORG_PARENT_ERROR.getCode(), AdminReturnCode.ORG_PARENT_ERROR.getMessage());
            }

            OrganizationParams queryParam = new OrganizationParams();
            queryParam.setParentId(orgPostDTO.getParentId());
            queryParam.setName(orgPostDTO.getName());
            List <Organization> dataList = organizationService.queryListByCondition(queryParam);
            if (CollectionUtils.isNotEmpty(dataList)) {
                throw new BizRuntimeException(AdminReturnCode.ORG_LEVEL_EXISTS.getCode(),
                        AdminReturnCode.ORG_LEVEL_EXISTS.getMessage());
            }

            // 添加
            organization = new Organization();
            organization.setParentId(orgPostDTO.getParentId());
            organization.setLevel( organizationData == null ? 1: organizationData.getLevel() + 1);
            organization.setName(orgPostDTO.getName());
            organization.setParentId( organizationData == null ? 0 : organizationData.getId());
            organization.setState(orgPostDTO.getState().equals(StateEnum.VALID.getCode()) ? StateEnum.VALID.getCode(): StateEnum.INVALID.getCode());
            organization.setCreateTime(new Date());
            Long id = organizationService.saveModel(organization);

            operationLog.setSnapshot(JSON.toJSONString(organization))
                    .setRemark(organization.getName())
                    .setOperationResult(id == null ? BehaviorResult.FAILURE.getCode() : BehaviorResult.SUCCESS.getCode());
            return id;
        } catch (Exception e) {
            operationLog.setSnapshot(JSON.toJSONString(organization))
                    .setRemark(orgPostDTO.getName())
                    .setError(e.getMessage())
                    .setOperationResult(BehaviorResult.ERROR.getCode());
            throw  e;
        } finally {
            sendLogService.sendOperationLog(operationLog, false);
        }

    }

    /**
     * 查询所有组织与部门信息
     * @return
     */
    public List<OrgInfoDTO> queryAllOrg() {
        OrganizationParams organizationParams = new OrganizationParams();
        organizationParams.setLevel(1);
        List <Organization> orgDataList = organizationService.queryListByCondition(organizationParams);
        List<OrgInfoDTO> orgInfoDataList = new ArrayList <>();
        if (CollectionUtils.isNotEmpty(orgDataList)) {
            for (Organization org: orgDataList) {
                OrgInfoDTO orgInfoDTO = dealOrgData(org);
                orgInfoDataList.add(orgInfoDTO);
            }
        }
        // 根
        OrgInfoDTO root = new OrgInfoDTO();
        root.setId(0L);
        root.setValue(0L);
        root.setLabel("组织目录");
        root.setState(StateEnum.VALID.getCode());
        root.setChildren(orgInfoDataList);

        List<OrgInfoDTO> allList = new ArrayList<>();
        allList.add(root);
        return allList;
    }

    private OrgInfoDTO dealOrgData(Organization org) {
        OrgInfoDTO orgInfoDTO = new OrgInfoDTO();
        orgInfoDTO.setId(org.getId());
        orgInfoDTO.setLevel(org.getLevel());
        orgInfoDTO.setLabel(org.getName());
        orgInfoDTO.setState(org.getState());
        orgInfoDTO.setParentId(org.getParentId());
        orgInfoDTO.setValue(org.getId());

        OrganizationParams organizationParams = new OrganizationParams();
        organizationParams.setParentId(org.getId());
        List <Organization> orgDataList = organizationService.queryListByCondition(organizationParams);
        if (CollectionUtils.isNotEmpty(orgDataList)) {
            List<OrgInfoDTO> orgInfoDataList = new ArrayList <>();
            for (Organization organization: orgDataList) {
                orgInfoDataList.add(dealOrgData(organization));
            }
            orgInfoDTO.setChildren(orgInfoDataList);
        }
        return orgInfoDTO;
    }
}
