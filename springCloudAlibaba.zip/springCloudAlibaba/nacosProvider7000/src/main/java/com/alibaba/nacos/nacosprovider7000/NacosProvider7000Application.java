package com.alibaba.nacos.nacosprovider7000;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class NacosProvider7000Application {

    public static void main(String[] args) {
        SpringApplication.run(NacosProvider7000Application.class, args);
    }

}
