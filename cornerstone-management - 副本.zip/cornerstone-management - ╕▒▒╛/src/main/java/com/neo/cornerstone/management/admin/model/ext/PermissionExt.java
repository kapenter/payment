package com.neo.cornerstone.management.admin.model.ext;

import com.neo.cornerstone.management.admin.model.Permission;

/*******************************************************************************
 * Created on 2019/7/29 17:06
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class PermissionExt extends Permission {
    private static final long serialVersionUID = 8096610001583844846L;

    private String menuName;

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }
}
