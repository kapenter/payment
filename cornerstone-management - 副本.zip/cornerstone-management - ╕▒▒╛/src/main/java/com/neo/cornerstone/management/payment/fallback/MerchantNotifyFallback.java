/*******************************************************************************
 * Create on 2019/9/2 17:39
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.fallback;

import com.neo.cornerstone.management.payment.feign.MerchantNotifyFeign;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.best.BestPaymentRowDTO;
import com.neo.payment.dto.admin.best.QueryBestPageRequestDTO;
import com.neo.payment.dto.admin.best.QuotaPaymentRowDTO;
import com.neo.payment.dto.admin.best.SetBestFailRequestDTO;
import com.neo.payment.dto.admin.notify.NotifyRecordRowDTO;
import com.neo.payment.dto.admin.notify.QueryTradePageRequestDTO;
import com.neo.payment.dto.admin.notify.TradeNotifyRowDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Component
public class MerchantNotifyFallback implements MerchantNotifyFeign {
    private static Logger logger = LoggerFactory.getLogger(MerchantNotifyFallback.class);

    @Override
    public PageResponseDTO<TradeNotifyRowDTO> queryTradePage(QueryTradePageRequestDTO requestDTO) {
        logger.error("[分页查询商户交易通知] [fallback] 查询商户交易通知列表失败，调用远程服务失败");
        return PageResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> sendNotify(String notifyOrder) {
        logger.error("[发送商户通知] [fallback] 发送商户交易通知失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<List<NotifyRecordRowDTO>> queryRecordList(String notifyOrder) {
        logger.error("[查询商户通知记录] [fallback] 查询商户通知记录失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败", Collections.emptyList());
    }

}
