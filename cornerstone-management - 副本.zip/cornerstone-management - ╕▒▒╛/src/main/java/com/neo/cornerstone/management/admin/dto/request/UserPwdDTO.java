package com.neo.cornerstone.management.admin.dto.request;

import com.neo.cornerstone.management.base.dto.BaseObject;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

/*******************************************************************************
 * Created on 2019/8/19 11:09
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class UserPwdDTO extends BaseObject {
    private static final long serialVersionUID = 7034848022353155050L;

    @NotEmpty(message = "密码不能为空")
    @Length(max = 2048, message = "密码格式不对")
    private String password;
    @NotEmpty(message = "确认密码不能为空")
    @Length(max = 2048, message = "确认密码格式不对")
    private String confirmPwd;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPwd() {
        return confirmPwd;
    }

    public void setConfirmPwd(String confirmPwd) {
        this.confirmPwd = confirmPwd;
    }
}
