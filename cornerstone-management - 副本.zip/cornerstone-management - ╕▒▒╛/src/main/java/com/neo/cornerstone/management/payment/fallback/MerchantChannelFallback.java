/*******************************************************************************
 * Create on 2019/9/2 17:39
 * Copyright (c) 2014 深圳市小牛电子商务有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛电子商务有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.neo.cornerstone.management.payment.fallback;

import com.neo.cornerstone.management.payment.feign.MerchantChannelFeign;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.merchant.ChannelConfigRowDTO;
import com.neo.payment.dto.admin.merchant.QueryPageRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @Author：xn082697
 * @Version 2.0.0
 */
@Component
public class MerchantChannelFallback implements MerchantChannelFeign {
    private static Logger logger = LoggerFactory.getLogger(MerchantChannelFallback.class);

    @Override
    public PageResponseDTO<ChannelConfigRowDTO> queryPage(QueryPageRequestDTO requestDTO) {
        logger.error("[分页查询商户渠道配置] [fallback] 查询商户渠道配置列表失败，调用远程服务失败");
        return PageResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> openChannelConfig(Long id) {
        logger.error("[开启商户渠道配置] [fallback] 开启商户渠道配置列表失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }

    @Override
    public ResponseDTO<String> closeChannelConfig(Long id) {
        logger.error("[禁用商户渠道配置] [fallback] 禁用商户渠道配置列表失败，调用远程服务失败");
        return ResponseDTO.buildErrorResponse("调用远程服务失败");
    }
}
