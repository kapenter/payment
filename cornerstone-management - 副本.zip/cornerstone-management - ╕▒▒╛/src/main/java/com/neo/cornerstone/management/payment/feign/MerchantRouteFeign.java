package com.neo.cornerstone.management.payment.feign;

import com.neo.cornerstone.management.payment.fallback.MerchantRouteFallback;
import com.neo.payment.constant.AdminURL;
import com.neo.payment.dto.PageResponseDTO;
import com.neo.payment.dto.ResponseDTO;
import com.neo.payment.dto.admin.route.QueryPageRequestDTO;
import com.neo.payment.dto.admin.route.RouteConfigRowDTO;
import com.neo.payment.dto.admin.route.UpdateConfigRequestDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * 商户渠道配置
 */
@FeignClient(value = "springcloud-5102-payment", fallback = MerchantRouteFallback.class)
public interface MerchantRouteFeign {

    @RequestMapping(value = AdminURL.QUERY_MERCHANT_ROUTE_CONFIG_PAGE_LIST, method = RequestMethod.POST)
    PageResponseDTO<RouteConfigRowDTO> queryPage(@RequestBody QueryPageRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.MERCHANT_ROUTE_CONFIG_MODIFY, method = RequestMethod.POST)
    ResponseDTO<String> updateConfig(@RequestBody UpdateConfigRequestDTO requestDTO);

    @RequestMapping(value = AdminURL.OPEN_MERCHANT_ROUTE_CONFIG, method = RequestMethod.POST)
    ResponseDTO<String> openConfig(@RequestBody List<Integer> list);

    @RequestMapping(value = AdminURL.CLOSE_MERCHANT_ROUTE_CONFIG, method = RequestMethod.POST)
    ResponseDTO<String> closeConfig(@RequestBody List<Integer> list);

    @RequestMapping(value = AdminURL.MERCHANT_ROUTE_CONFIG_FLUSH_ALL, method = RequestMethod.GET)
    ResponseDTO<String> flushAll();

    @RequestMapping(value = AdminURL.MERCHANT_ROUTE_CONFIG_FLUSH, method = RequestMethod.GET)
    ResponseDTO<String> flushCache(@RequestBody List<Integer> list);

}
