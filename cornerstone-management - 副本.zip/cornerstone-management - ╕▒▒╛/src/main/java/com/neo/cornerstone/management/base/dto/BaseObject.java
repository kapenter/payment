package com.neo.cornerstone.management.base.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/*******************************************************************************
 * Created on 2019/6/17 17:34
 * Copyright (c) 2014 深圳市小牛在线互联网信息咨询有限公司版权所有. 粤ICP备13089339号
 * 注意：本内容仅限于深圳市小牛在线互联网信息咨询有限公司内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
public class BaseObject implements Serializable {

    private static final long serialVersionUID = 5994395286970638433L;

    public BaseObject() {
    }

    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other, new String[0]);
    }

    @Override public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, new String[0]);
    }

    @Override public String toString() {
        return ToStringBuilder
                .reflectionToString(this, org.apache.commons.lang3.builder.ToStringStyle.MULTI_LINE_STYLE);
    }
}
