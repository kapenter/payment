package com.neo.cornerstone.management.message.feign;

import com.neo.cornerstone.management.message.consts.MessageURL;
import com.neo.cornerstone.management.message.feign.FallbackFactory.ChannelAccountRouteConfigFallbackFactory;
import com.neo.cornerstone.message.dto.request.AccountRouteQueryDTO;
import com.neo.cornerstone.message.dto.request.AccountRouteRequestDTO;
import com.neo.cornerstone.message.dto.response.ChannelAccountRouteConfigRespDTO;
import com.neo.cornerstone.message.entitty.OperationResponseDTO;
import com.neo.cornerstone.message.entitty.PageResponseDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @program: cornerstone-management-jcweb
 * @description:
 * @author: xn086532
 * @create: 2019-08-28 14:06
 **/
@FeignClient(value = "springcloud-5101-message",fallbackFactory = ChannelAccountRouteConfigFallbackFactory.class)
public interface ChannelAccountRouteConfigFeign {

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_ROUTE_LIST,method = RequestMethod.POST)
    PageResponseDTO<ChannelAccountRouteConfigRespDTO> pageChannelAccountsRoute(@RequestBody AccountRouteQueryDTO accountRouteQueryDTO);

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_ROUTE_ADD,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> addChannelAccountRoute(@RequestBody AccountRouteRequestDTO accountRouteRequestDTO);

    @RequestMapping(value = MessageURL.MESSAGE_CHANNEL_ACCOUNT_ROUTE_UPDATE,method = RequestMethod.POST)
    OperationResponseDTO<Boolean> updateChannelAccountRoute(AccountRouteRequestDTO accountRouteRequestDTO);

}
