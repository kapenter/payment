package com.neo.cornerstone.management.admin.service.common;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.neo.cornerstone.management.admin.constants.GlobalConfig;
import com.neo.cornerstone.management.admin.mapper.PermissionMapper;
import com.neo.cornerstone.management.admin.mapper.base.BaseMapper;
import com.neo.cornerstone.management.admin.model.Permission;
import com.neo.cornerstone.management.admin.model.ext.PermissionExt;
import com.neo.cornerstone.management.admin.model.params.BaseParams;
import com.neo.cornerstone.management.admin.model.params.PermissionParams;
import com.neo.cornerstone.management.admin.service.MysqlBaseServiceImpl;
import com.neo.cornerstone.management.base.dto.PageModel;

/**
 * Title:TPermissionServiceImpl<br/>
 * Description:(权限SERVICE实现类)<br/>
 * Copyright: Copyright © 2019<br/>
 * Company: --<br/>
 * @author luoshun
 * @version v1.0 2019-07-18
 */
@Service("permissionService")
public class PermissionService extends MysqlBaseServiceImpl <Permission> {

    private static final String PRE_PERMISSION_KEY = "permission_";
    private static final String PRE_PERMISSION_SINGLE = PRE_PERMISSION_KEY + "single_";
    private static final String PRE_PERMISSION_LISET = PRE_PERMISSION_KEY + "list_";

    @Autowired
    private StringRedisTemplate clusterStringRedisTemplate;

    @Autowired
    private PermissionMapper permissionMapper;

    @Override
    public BaseMapper <Permission> getBaseMapper() {
        return permissionMapper;
    }

    @Override
    public BaseParams getParamsDTO() {
        return new PermissionParams();
    }

    @Override
    public Permission getObjectModel() {
        return new Permission();
    }

    public PageModel <PermissionExt> queryPageExt(BaseParams params) {
        if (params.getPageNum() < 0) {
            params.setPageNum(0);
        }

        PageModel<PermissionExt> pageModel = new PageModel<>();

        List <PermissionExt> resultList = permissionMapper.queryPageListExt(params);
        if (CollectionUtils.isNotEmpty(resultList)) {
            pageModel.setData(resultList);
            pageModel.setTotalRows(permissionMapper.queryPageCountListExt(params));
        }
        return pageModel;
    }

    /**
     * 查询所有权限信息
     * @return
     */
    public List<Permission> queryAllPermissionByCache() {
        String redisData = clusterStringRedisTemplate.opsForValue().get(PRE_PERMISSION_LISET);
        if (null != redisData) {
            return JSONObject.parseArray(redisData, Permission.class);
        }

        PermissionParams permissionParams = new PermissionParams();
        List <Permission> permissionList = permissionMapper.queryListByCondition(permissionParams);
        if (CollectionUtils.isNotEmpty(permissionList)) {
            clusterStringRedisTemplate.opsForValue().set(PRE_PERMISSION_LISET, JSON.toJSONString(permissionList),
                    GlobalConfig.commonRedisTime, TimeUnit.HOURS);
        }
        return permissionList;
    }

    @Override
    public Permission queryById(Long id) {
        String redisPermission = clusterStringRedisTemplate.opsForValue().get(PRE_PERMISSION_SINGLE + id);
        if (null != redisPermission) {
            return JSON.parseObject(redisPermission, Permission.class);
        }
        Permission permission = super.queryById(id);
        if (null != permission) {
            clusterStringRedisTemplate.opsForValue().set(PRE_PERMISSION_SINGLE + id, JSON.toJSONString(permission),
                    GlobalConfig.commonRedisTime, TimeUnit.HOURS);
        }
        return permission;
    }

    @Override
    public Boolean updateById(Permission params) {
        clusterStringRedisTemplate.delete(PRE_PERMISSION_SINGLE + params.getId());
        clusterStringRedisTemplate.delete(PRE_PERMISSION_LISET);
        return super.updateById(params);
    }

    @Override
    public Boolean deleteById(Long id) {
        clusterStringRedisTemplate.delete(PRE_PERMISSION_SINGLE + id);
        clusterStringRedisTemplate.delete(PRE_PERMISSION_LISET);
        return super.deleteById(id);
    }

    @Override
    public int deleteByCondition(BaseParams params) {
        clusterStringRedisTemplate.delete(PRE_PERMISSION_KEY);
        return super.deleteByCondition(params);
    }
}