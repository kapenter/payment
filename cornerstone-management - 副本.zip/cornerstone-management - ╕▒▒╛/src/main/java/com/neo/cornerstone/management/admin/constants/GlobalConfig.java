package com.neo.cornerstone.management.admin.constants;

public interface GlobalConfig {

    public static int hashIterations = 2;
    public static String hashAlgorithmName = "MD5";
    public static int hashPreStringCount = 3;

    public static int commonRedisTime = 24;

}
